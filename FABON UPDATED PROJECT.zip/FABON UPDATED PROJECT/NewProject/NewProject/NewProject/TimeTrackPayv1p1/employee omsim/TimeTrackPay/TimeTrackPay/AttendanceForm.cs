﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class AttendanceForm : Form
    {
        public AttendanceForm()
        {
            InitializeComponent();
            GridView();
        }

        private void GridView()
        {
            List<GridData> grid = new List<GridData>();
            grid.Add(new GridData("12-02-2014", "7:58 AM", "4:10 PM", "8:10"));
            grid.Add(new GridData("12-03-2014", "7:58 AM", "4:10 PM", "8:10"));
            grid.Add(new GridData("12-04-2014", "7:58 AM", "4:10 PM", "8:10"));
            grid.Add(new GridData("12-05-2014", "7:58 AM", "4:10 PM", "8:10"));
            grid.Add(new GridData("12-06-2014", "7:58 AM", "4:10 PM", "8:10"));
            grid.Add(new GridData("12-07-2014", "7:58 AM", "4:10 PM", "8:10"));


            foreach (GridData d in grid)
            {
                int rowIndex = dataGridView1.Rows.Add();
                DataGridViewRow row = dataGridView1.Rows[rowIndex];
                row.Cells[0].Value = d.Data;
                row.Cells[1].Value = d.TimeIn;
                row.Cells[2].Value = d.TimeOut;
                row.Cells[3].Value = d.TotalHours;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            leaveRequest leaveRequest = new leaveRequest();
            leaveRequest.Show();
        }

        private void btnRequestLeave_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void AttendanceForm_Load(object sender, EventArgs e)
        {
            AdjustDataGridHeight();
        }
        private void AdjustDataGridHeight()
        {
            var height = dataGridView1.ColumnHeadersHeight;
            foreach (DataGridViewRow dr in dataGridView1.Rows)
            {
                height += dr.Height;
            }
            dataGridView1.Height = height;
        }

        private void btnRequestLeave_MouseClick(object sender, MouseEventArgs e)
        {
            leaveRequest leaveRequest = new leaveRequest();
            leaveRequest.Show();
        }
    }
}
