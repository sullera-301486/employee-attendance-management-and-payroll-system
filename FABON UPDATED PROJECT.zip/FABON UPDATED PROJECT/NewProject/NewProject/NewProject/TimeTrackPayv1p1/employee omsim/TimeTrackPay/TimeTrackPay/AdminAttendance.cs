﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using roundedRectangle;
using System.Xml;
using System.Security.Policy;

namespace TimeTrackPay
{
    public partial class AdminAttendance : Form
    {
        private Panel employeePanel;

        public AdminAttendance()
        {
            InitializeComponent();

            employeePanel = new Panel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true // Allow scrolling if there are many profiles
            };
            this.Controls.Add(employeePanel);

        }

        private void AdminAttendance_Load(object sender, EventArgs e)
        {

            LoadEmployeeProfiles();
            cbMonth.Items.AddRange(new string[]
            {
                "January","February","March","April","May","June","July","August","September",
                "October","November","December"
            });
            cbMonth.SelectedIndexChanged += MonthAttendance_SelectedIndexChanged;
            cbYear.Items.AddRange(new string[] { "2022", "2023", "2024" });
            LoadEmployeeProfiles();
        }
        private void MonthAttendance_SelectedIndexChanged(object sender, EventArgs e)
        {
            MonthAttendance.Text = cbMonth.SelectedItem.ToString();
        }


        private void LoadEmployeeProfiles()
        {
            

            // Set the connection string to your database
            string connectionString = "Server=LAPTOP-DLKIA2TF\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Query to fetch employee data
                    string query = "SELECT EmployeeID, FullName, Position FROM Employee";
                    SqlCommand command = new SqlCommand(query, connection);

                    SqlDataReader reader = command.ExecuteReader();
                    int panelX = 10; // Start position X for the first panel
                    int panelY = 140; // Start position Y for the first row
                    int panelWidth = 200;
                    int panelHeight = 200;
                    int padding = 20;
                    
                    int maxProfilesPerRow = 4; // Number of profiles per row
                    int profileCountInRow = 0; // Keep track of the number of profiles in the current row
                    employeePanel.Controls.Clear();

                    while (reader.Read())
                    {
                        string employeeId = reader["EmployeeID"].ToString();
                        // Clone the profile template panel
                        FabonPanel employeeProfilePanel = new FabonPanel
                        {
                            Size = new Size(panelWidth, panelHeight),
                            Location = new Point(panelX, panelY),
                            BorderStyle = BorderStyle.FixedSingle,
                            GradientBottomColor = Color.White,
                            GradientTopColor = Color.White,

                            
                        };


                        // Set the employee name label
                        Label AttendanceNameInPanel = new Label
                        {
                            Text = $"{reader["FullName"]}",
                            Location = new Point(60, 120),
                            Width = panelWidth - 20,
                            BackColor = Color.Transparent
                        };
                        employeeProfilePanel.Controls.Add(AttendanceNameInPanel);

                        // Set the profile picture
                        PictureBox ProfileForUsers = new PictureBox
                        {
                            Image = Properties.Resources.UserProfileLogo, // Set a default image or use a condition for different images
                            SizeMode = PictureBoxSizeMode.StretchImage,
                            Size = new Size(100, 100),
                            Location = new Point(50, 10),
                            BackColor = Color.Transparent
                            

                            
                        };
                        employeeProfilePanel.Controls.Add(ProfileForUsers);


                        // Create a "View Profile" button
                        button viewProfileButton = new button
                        {
                            Text = "View Profile",
                            Location = new Point(10, 140), // Position of the button
                            Width = panelWidth - 20,
                            BorderRadius = 12,
                            BackColor = Color.White,
                            BorderSize = 2,
                            TextColor = Color.Black
                        };

                         employeeId = reader["EmployeeID"].ToString();
                        // Attach click event handler to the button
                        viewProfileButton.Click += (sender, e) =>
                        {
                            ShowEmployeeDetails(employeeId);

                        };

                        employeeProfilePanel.Controls.Add(viewProfileButton);
                        employeeProfilePanel.Controls.Add(ProfileForUsers);
                        employeeProfilePanel.Controls.Add(AttendanceNameInPanel);
                        employeeProfilePanel.Controls.Add(viewProfileButton);

                        employeePanel.Controls.Add(employeeProfilePanel);
                        // Update position for the next profile panel
                        panelX += panelWidth + padding; // Move to the right

                        // If 4 profiles have been added in the current row, move to the next row
                        profileCountInRow++;
                        if (profileCountInRow >= maxProfilesPerRow)
                        {
                            panelX = 10; // Reset X position for the next row
                            panelY += panelHeight + padding; // Move down to the next row
                            profileCountInRow = 0; // Reset the profile count for the new row
                        }
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }


      


        // This method will open a new form with the employee's details
        private void ShowEmployeeDetails(string employeeId)
        {
            EmployeeDetailsForm detailsForm = new EmployeeDetailsForm(employeeId);
            detailsForm.Show();
        }
    

        private void viewProfileButton_Click(object sender, EventArgs e)
        {
  
        }
    }
}

