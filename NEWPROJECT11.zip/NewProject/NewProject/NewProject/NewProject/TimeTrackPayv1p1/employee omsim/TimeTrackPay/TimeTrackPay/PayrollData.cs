﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeTrackPay
{
    internal class PayrollData
    {
        public string Earnings { get; set; }
        public string Amounts { get; set; }
        public string Deductions { get; set; }
        public string Amount { get; set; }

        public PayrollData(string earning, string amts, string deduc, string amt)
        {
            this.Earnings = earning;
            this.Amounts = amt;
            this.Deductions = deduc;
            this.Amount = amts;
        }
    }
}
