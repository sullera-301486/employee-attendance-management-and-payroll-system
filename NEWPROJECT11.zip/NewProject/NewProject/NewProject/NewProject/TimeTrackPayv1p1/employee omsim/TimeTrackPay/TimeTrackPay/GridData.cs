﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeTrackPay
{
    internal class GridData
    {
        public string Data { get; set; }
        public string TimeIn { get; set; }
        public string TimeOut { get; set; }
        public string TotalHours { get; set; }

        public GridData (string data, string tI, string tO, string tH)
        {
            this.Data = data;
            this.TimeIn = tI;
            this.TimeOut = tO;
            this.TotalHours = tH;
        }

        
    }
}
