﻿namespace TimeTrackPay
{
    partial class ProfileForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.fabonPanel5 = new roundedRectangle.FabonPanel();
            this.label23 = new System.Windows.Forms.Label();
            this.fabonPanel4 = new roundedRectangle.FabonPanel();
            this.label22 = new System.Windows.Forms.Label();
            this.fabonPanel3 = new roundedRectangle.FabonPanel();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.fabonPanel6 = new roundedRectangle.FabonPanel();
            this.fabonPanel7 = new roundedRectangle.FabonPanel();
            this.fabonPanel1 = new roundedRectangle.FabonPanel();
            this.fabonPanel8 = new roundedRectangle.FabonPanel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.fabonPanel5.SuspendLayout();
            this.fabonPanel4.SuspendLayout();
            this.fabonPanel3.SuspendLayout();
            this.fabonPanel6.SuspendLayout();
            this.fabonPanel7.SuspendLayout();
            this.fabonPanel1.SuspendLayout();
            this.fabonPanel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Inter", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(228, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Profile Details";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Location = new System.Drawing.Point(16, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(406, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Your personal profile information is displayed below";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(604, 112);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(131, 19);
            this.label16.TabIndex = 15;
            this.label16.Text = "October 15, 2024";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(589, 148);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(93, 19);
            this.label15.TabIndex = 14;
            this.label15.Text = "Deactivated";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(594, 182);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(64, 19);
            this.label14.TabIndex = 13;
            this.label14.Text = "Angono";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(290, 182);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(165, 19);
            this.label13.TabIndex = 12;
            this.label13.Text = "Deloritos@yahoo.com";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(290, 148);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(98, 19);
            this.label12.TabIndex = 11;
            this.label12.Text = "09191919191";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(310, 112);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(145, 19);
            this.label11.TabIndex = 10;
            this.label11.Text = "Center of the earth";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gray;
            this.label10.Location = new System.Drawing.Point(525, 182);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 19);
            this.label10.TabIndex = 9;
            this.label10.Text = "Address:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gray;
            this.label9.Location = new System.Drawing.Point(525, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 19);
            this.label9.TabIndex = 8;
            this.label9.Text = "Birthday:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gray;
            this.label8.Location = new System.Drawing.Point(525, 148);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 19);
            this.label8.TabIndex = 7;
            this.label8.Text = "Status:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(233, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 19);
            this.label5.TabIndex = 6;
            this.label5.Text = "Phone:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gray;
            this.label7.Location = new System.Drawing.Point(233, 182);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 19);
            this.label7.TabIndex = 5;
            this.label7.Text = "Email:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gray;
            this.label6.Location = new System.Drawing.Point(233, 112);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 19);
            this.label6.TabIndex = 4;
            this.label6.Text = "Position:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Inter", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gray;
            this.label4.Location = new System.Drawing.Point(233, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(163, 23);
            this.label4.TabIndex = 2;
            this.label4.Text = "Human Resource";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Inter", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(231, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(334, 33);
            this.label3.TabIndex = 1;
            this.label3.Text = "Franz Louies C. Deloritos";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::TimeTrackPay.Properties.Resources.ProfileLogoForm;
            this.pictureBox1.Location = new System.Drawing.Point(30, 35);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(171, 171);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // fabonPanel5
            // 
            this.fabonPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel5.BorderRadius = 20;
            this.fabonPanel5.Controls.Add(this.label23);
            this.fabonPanel5.ForeColor = System.Drawing.Color.White;
            this.fabonPanel5.GradientAngle = 90F;
            this.fabonPanel5.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel5.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel5.Location = new System.Drawing.Point(622, 128);
            this.fabonPanel5.Name = "fabonPanel5";
            this.fabonPanel5.Size = new System.Drawing.Size(205, 50);
            this.fabonPanel5.TabIndex = 8;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(80, 16);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(52, 19);
            this.label23.TabIndex = 5;
            this.label23.Text = "1 Year";
            // 
            // fabonPanel4
            // 
            this.fabonPanel4.BackColor = System.Drawing.Color.White;
            this.fabonPanel4.BorderRadius = 20;
            this.fabonPanel4.Controls.Add(this.label22);
            this.fabonPanel4.ForeColor = System.Drawing.Color.White;
            this.fabonPanel4.GradientAngle = 90F;
            this.fabonPanel4.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel4.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel4.Location = new System.Drawing.Point(348, 128);
            this.fabonPanel4.Name = "fabonPanel4";
            this.fabonPanel4.Size = new System.Drawing.Size(205, 50);
            this.fabonPanel4.TabIndex = 7;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(40, 16);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(126, 19);
            this.label22.TabIndex = 5;
            this.label22.Text = "August 28, 2023";
            // 
            // fabonPanel3
            // 
            this.fabonPanel3.BackColor = System.Drawing.Color.White;
            this.fabonPanel3.BorderRadius = 20;
            this.fabonPanel3.Controls.Add(this.label21);
            this.fabonPanel3.ForeColor = System.Drawing.Color.White;
            this.fabonPanel3.GradientAngle = 90F;
            this.fabonPanel3.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel3.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel3.Location = new System.Drawing.Point(60, 128);
            this.fabonPanel3.Name = "fabonPanel3";
            this.fabonPanel3.Size = new System.Drawing.Size(205, 50);
            this.fabonPanel3.TabIndex = 6;
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(79, 16);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 19);
            this.label21.TabIndex = 9;
            this.label21.Text = "1015";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Inter SemiBold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.label20.Location = new System.Drawing.Point(400, 76);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(105, 25);
            this.label20.TabIndex = 5;
            this.label20.Text = "Hire Date";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Inter SemiBold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.label19.Location = new System.Drawing.Point(662, 76);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(127, 25);
            this.label19.TabIndex = 4;
            this.label19.Text = "Worked For";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Inter SemiBold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.label18.Location = new System.Drawing.Point(99, 76);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(137, 25);
            this.label18.TabIndex = 3;
            this.label18.Text = "Employee ID";
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Inter SemiBold", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(327, 15);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(263, 35);
            this.label17.TabIndex = 0;
            this.label17.Text = "Basic Information";
            // 
            // fabonPanel6
            // 
            this.fabonPanel6.BackColor = System.Drawing.Color.Black;
            this.fabonPanel6.BorderRadius = 50;
            this.fabonPanel6.Controls.Add(this.fabonPanel7);
            this.fabonPanel6.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel6.GradientAngle = 90F;
            this.fabonPanel6.GradientBottomColor = System.Drawing.Color.Silver;
            this.fabonPanel6.GradientTopColor = System.Drawing.Color.Silver;
            this.fabonPanel6.Location = new System.Drawing.Point(19, 82);
            this.fabonPanel6.Name = "fabonPanel6";
            this.fabonPanel6.Size = new System.Drawing.Size(894, 263);
            this.fabonPanel6.TabIndex = 4;
            // 
            // fabonPanel7
            // 
            this.fabonPanel7.BackColor = System.Drawing.Color.Black;
            this.fabonPanel7.BorderRadius = 50;
            this.fabonPanel7.Controls.Add(this.label16);
            this.fabonPanel7.Controls.Add(this.pictureBox1);
            this.fabonPanel7.Controls.Add(this.label15);
            this.fabonPanel7.Controls.Add(this.label3);
            this.fabonPanel7.Controls.Add(this.label14);
            this.fabonPanel7.Controls.Add(this.label4);
            this.fabonPanel7.Controls.Add(this.label13);
            this.fabonPanel7.Controls.Add(this.label6);
            this.fabonPanel7.Controls.Add(this.label12);
            this.fabonPanel7.Controls.Add(this.label7);
            this.fabonPanel7.Controls.Add(this.label11);
            this.fabonPanel7.Controls.Add(this.label5);
            this.fabonPanel7.Controls.Add(this.label10);
            this.fabonPanel7.Controls.Add(this.label8);
            this.fabonPanel7.Controls.Add(this.label9);
            this.fabonPanel7.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel7.GradientAngle = 90F;
            this.fabonPanel7.GradientBottomColor = System.Drawing.Color.White;
            this.fabonPanel7.GradientTopColor = System.Drawing.Color.White;
            this.fabonPanel7.Location = new System.Drawing.Point(3, 3);
            this.fabonPanel7.Name = "fabonPanel7";
            this.fabonPanel7.Size = new System.Drawing.Size(888, 257);
            this.fabonPanel7.TabIndex = 5;
            // 
            // fabonPanel1
            // 
            this.fabonPanel1.BackColor = System.Drawing.Color.Black;
            this.fabonPanel1.BorderRadius = 50;
            this.fabonPanel1.Controls.Add(this.fabonPanel8);
            this.fabonPanel1.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel1.GradientAngle = 90F;
            this.fabonPanel1.GradientBottomColor = System.Drawing.Color.Silver;
            this.fabonPanel1.GradientTopColor = System.Drawing.Color.Silver;
            this.fabonPanel1.Location = new System.Drawing.Point(19, 369);
            this.fabonPanel1.Name = "fabonPanel1";
            this.fabonPanel1.Size = new System.Drawing.Size(894, 209);
            this.fabonPanel1.TabIndex = 5;
            // 
            // fabonPanel8
            // 
            this.fabonPanel8.BackColor = System.Drawing.Color.Brown;
            this.fabonPanel8.BorderRadius = 50;
            this.fabonPanel8.Controls.Add(this.fabonPanel5);
            this.fabonPanel8.Controls.Add(this.label17);
            this.fabonPanel8.Controls.Add(this.fabonPanel4);
            this.fabonPanel8.Controls.Add(this.label18);
            this.fabonPanel8.Controls.Add(this.fabonPanel3);
            this.fabonPanel8.Controls.Add(this.label19);
            this.fabonPanel8.Controls.Add(this.label20);
            this.fabonPanel8.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel8.GradientAngle = 90F;
            this.fabonPanel8.GradientBottomColor = System.Drawing.Color.White;
            this.fabonPanel8.GradientTopColor = System.Drawing.Color.White;
            this.fabonPanel8.Location = new System.Drawing.Point(3, 3);
            this.fabonPanel8.Name = "fabonPanel8";
            this.fabonPanel8.Size = new System.Drawing.Size(888, 203);
            this.fabonPanel8.TabIndex = 6;
            // 
            // ProfileForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(930, 640);
            this.Controls.Add(this.fabonPanel1);
            this.Controls.Add(this.fabonPanel6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ProfileForm";
            this.Text = "ProfileForm";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.fabonPanel5.ResumeLayout(false);
            this.fabonPanel5.PerformLayout();
            this.fabonPanel4.ResumeLayout(false);
            this.fabonPanel4.PerformLayout();
            this.fabonPanel3.ResumeLayout(false);
            this.fabonPanel3.PerformLayout();
            this.fabonPanel6.ResumeLayout(false);
            this.fabonPanel7.ResumeLayout(false);
            this.fabonPanel7.PerformLayout();
            this.fabonPanel1.ResumeLayout(false);
            this.fabonPanel8.ResumeLayout(false);
            this.fabonPanel8.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private roundedRectangle.FabonPanel fabonPanel4;
        private roundedRectangle.FabonPanel fabonPanel3;
        private roundedRectangle.FabonPanel fabonPanel5;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private roundedRectangle.FabonPanel fabonPanel6;
        private roundedRectangle.FabonPanel fabonPanel7;
        private roundedRectangle.FabonPanel fabonPanel1;
        private roundedRectangle.FabonPanel fabonPanel8;
    }
}