﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class DashboardAdmin : Form
    {
        public DashboardAdmin()
        {
            InitializeComponent();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void btnMoreInfoAdminAttendance_Click(object sender, EventArgs e)
        {
            loadform(new AdminAttendance());
        }

        public void loadform(Form form)
        {
            foreach (Control control in this.DashboardPanel.Controls.OfType<Control>().ToList())
            {
                this.DashboardPanel.Controls.Remove(control);
                control.Dispose();
            }

            form.TopLevel = false;
            form.Dock = DockStyle.Fill;
            this.DashboardPanel.Controls.Add(form);
            this.DashboardPanel.Tag = form;

            form.Show();
        }

        private void btnMoreInfoPayrollRecords_Click(object sender, EventArgs e)
        { 
            loadform(new AdminAttendance());
            
        }

        private void btnMoreInfoAdminAttendance_Click_1(object sender, EventArgs e)
        {
            loadform(new AdminAttendance());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            loadform(new AdminAttendance());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            loadform(new AdminAttendance());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loadform(new AdminAttendance());
        }
    }
}
