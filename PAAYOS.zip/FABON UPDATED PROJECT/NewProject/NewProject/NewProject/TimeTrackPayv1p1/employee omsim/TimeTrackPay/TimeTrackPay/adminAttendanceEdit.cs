﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class adminAttendanceEdit : Form
    {
        public adminAttendanceEdit()
        {
            InitializeComponent();
        }

        private void adminAttendanceDelete_Load(object sender, EventArgs e)
        {

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            adminAttendanceNew attendanceNew = new adminAttendanceNew();
            attendanceNew.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            adminAttendanceDelete attendanceDelete = new adminAttendanceDelete();
            attendanceDelete.Show();
        }
    }
}
