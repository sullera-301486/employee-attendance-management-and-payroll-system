﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class DashboardEmployee : Form
    {
        public DashboardEmployee()
        {
            InitializeComponent();
        }

        private void DashboardEmployee_Load(object sender, EventArgs e)
        {

        }

        private void button_Click(object sender, EventArgs e)
        {
            foreach (var btn in this.Controls.OfType<button>())
                btn.BackColor = Color.FromArgb(34, 100, 102);
            button Buttons = (button)sender;
            Buttons.BackColor = Color.FromArgb(82, 85, 76);

        }

        private void btnAttendance_Click(object sender, EventArgs e)
        {
            loadform(new AttendanceForm());
        }
        private void btnLeave_Click(object sender, EventArgs e)
        {

        }
        private void btnPayroll_Click(object sender, EventArgs e)
        {
            loadform(new PayrollForm());
        }
        private void btnProfile_Click(object sender, EventArgs e)
        {
            loadform(new ProfileForm());
        }
        private void btnDashboard_Click(object sender, EventArgs e)
        {
            loadform(new DashboardForm());
        }

        public void loadform(object Form)
        {
            if (this.fabonPanel1.Controls.Count > 0)
                this.fabonPanel1.Controls.RemoveAt(0);
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.fabonPanel1.Controls.Add(f);
            this.fabonPanel1.Tag = f;
            f.Show();
        }
    }
}
