﻿namespace TimeTrackPay
{
    partial class DashboardEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLeave = new TimeTrackPay.button();
            this.btnProfile = new TimeTrackPay.button();
            this.btnPayroll = new TimeTrackPay.button();
            this.btnAttendance = new TimeTrackPay.button();
            this.btnDashboard = new TimeTrackPay.button();
            this.fabonPanel1 = new roundedRectangle.FabonPanel();
            this.SuspendLayout();
            // 
            // btnLeave
            // 
            this.btnLeave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.btnLeave.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.btnLeave.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnLeave.BorderRadius = 0;
            this.btnLeave.BorderSize = 0;
            this.btnLeave.FlatAppearance.BorderSize = 0;
            this.btnLeave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLeave.ForeColor = System.Drawing.Color.White;
            this.btnLeave.Image = global::TimeTrackPay.Properties.Resources.LeaveLogo;
            this.btnLeave.Location = new System.Drawing.Point(0, 434);
            this.btnLeave.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLeave.Name = "btnLeave";
            this.btnLeave.Size = new System.Drawing.Size(113, 71);
            this.btnLeave.TabIndex = 5;
            this.btnLeave.TextColor = System.Drawing.Color.White;
            this.btnLeave.UseVisualStyleBackColor = false;
            this.btnLeave.Click += new System.EventHandler(this.btnLeave_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.btnProfile.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.btnProfile.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnProfile.BorderRadius = 0;
            this.btnProfile.BorderSize = 0;
            this.btnProfile.FlatAppearance.BorderSize = 0;
            this.btnProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProfile.ForeColor = System.Drawing.Color.White;
            this.btnProfile.Image = global::TimeTrackPay.Properties.Resources.ProfileLogo;
            this.btnProfile.Location = new System.Drawing.Point(0, 358);
            this.btnProfile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(113, 71);
            this.btnProfile.TabIndex = 4;
            this.btnProfile.TextColor = System.Drawing.Color.White;
            this.btnProfile.UseVisualStyleBackColor = false;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnPayroll
            // 
            this.btnPayroll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.btnPayroll.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.btnPayroll.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnPayroll.BorderRadius = 0;
            this.btnPayroll.BorderSize = 0;
            this.btnPayroll.FlatAppearance.BorderSize = 0;
            this.btnPayroll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPayroll.ForeColor = System.Drawing.Color.White;
            this.btnPayroll.Image = global::TimeTrackPay.Properties.Resources.PayrollLogo;
            this.btnPayroll.Location = new System.Drawing.Point(0, 282);
            this.btnPayroll.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPayroll.Name = "btnPayroll";
            this.btnPayroll.Size = new System.Drawing.Size(113, 71);
            this.btnPayroll.TabIndex = 3;
            this.btnPayroll.TextColor = System.Drawing.Color.White;
            this.btnPayroll.UseVisualStyleBackColor = false;
            this.btnPayroll.Click += new System.EventHandler(this.btnPayroll_Click);
            // 
            // btnAttendance
            // 
            this.btnAttendance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.btnAttendance.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.btnAttendance.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnAttendance.BorderRadius = 0;
            this.btnAttendance.BorderSize = 0;
            this.btnAttendance.FlatAppearance.BorderSize = 0;
            this.btnAttendance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAttendance.ForeColor = System.Drawing.Color.White;
            this.btnAttendance.Image = global::TimeTrackPay.Properties.Resources.AttendanceLogo;
            this.btnAttendance.Location = new System.Drawing.Point(0, 206);
            this.btnAttendance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAttendance.Name = "btnAttendance";
            this.btnAttendance.Size = new System.Drawing.Size(113, 71);
            this.btnAttendance.TabIndex = 2;
            this.btnAttendance.TextColor = System.Drawing.Color.White;
            this.btnAttendance.UseVisualStyleBackColor = false;
            this.btnAttendance.Click += new System.EventHandler(this.btnAttendance_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(85)))), ((int)(((byte)(76)))));
            this.btnDashboard.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(85)))), ((int)(((byte)(76)))));
            this.btnDashboard.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnDashboard.BorderRadius = 0;
            this.btnDashboard.BorderSize = 0;
            this.btnDashboard.FlatAppearance.BorderSize = 0;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.ForeColor = System.Drawing.Color.White;
            this.btnDashboard.Image = global::TimeTrackPay.Properties.Resources.DashboardLogo;
            this.btnDashboard.Location = new System.Drawing.Point(0, 129);
            this.btnDashboard.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(113, 71);
            this.btnDashboard.TabIndex = 1;
            this.btnDashboard.TextColor = System.Drawing.Color.White;
            this.btnDashboard.UseVisualStyleBackColor = false;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            // 
            // fabonPanel1
            // 
            this.fabonPanel1.BackColor = System.Drawing.Color.White;
            this.fabonPanel1.BorderRadius = 90;
            this.fabonPanel1.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel1.GradientAngle = 90F;
            this.fabonPanel1.GradientBottomColor = System.Drawing.Color.White;
            this.fabonPanel1.GradientTopColor = System.Drawing.Color.White;
            this.fabonPanel1.Location = new System.Drawing.Point(111, 31);
            this.fabonPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fabonPanel1.Name = "fabonPanel1";
            this.fabonPanel1.Size = new System.Drawing.Size(1467, 756);
            this.fabonPanel1.TabIndex = 0;
            // 
            // DashboardEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.ClientSize = new System.Drawing.Size(1515, 846);
            this.Controls.Add(this.btnLeave);
            this.Controls.Add(this.btnProfile);
            this.Controls.Add(this.btnPayroll);
            this.Controls.Add(this.btnAttendance);
            this.Controls.Add(this.btnDashboard);
            this.Controls.Add(this.fabonPanel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "DashboardEmployee";
            this.Text = "Dashboard Employee";
            this.Load += new System.EventHandler(this.DashboardEmployee_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private roundedRectangle.FabonPanel fabonPanel1;
        private button btnDashboard;
        private button btnAttendance;
        private button btnPayroll;
        private button btnProfile;
        private button btnLeave;
    }
}