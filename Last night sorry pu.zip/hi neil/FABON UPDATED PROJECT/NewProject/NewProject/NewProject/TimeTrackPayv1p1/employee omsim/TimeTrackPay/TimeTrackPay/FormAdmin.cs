﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class FormAdmin : Form
    {
        private int adminID;
        SqlConnection Con = new SqlConnection(@"Server=DESKTOP-JMR591K\SQLEXPRESS; Database=dbEmployee; Integrated Security = True");
        public FormAdmin(int id)
        {
            InitializeComponent();
            adminID = id;
            LoadAdminData(); // Call LoadAdminData method when the form loads
        }

        private void LoadAdminData()
        {
            string query = "SELECT FullName FROM Admin WHERE AdminID = @AdminID";

            using (SqlCommand command = new SqlCommand(query, Con))
            {
                command.Parameters.AddWithValue("@AdminID", adminID);

                try
                {
                    Con.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        // Display fetched data in the label
                        label11.Text = reader["FullName"].ToString(); // Ensure column name is correct
                    }
                    else
                    {
                        MessageBox.Show("Admin not found.");
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

        private void MainPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            btnDashboard.BackColor = Color.FromArgb(82, 85, 76);
            btnPayroll.BackColor = Color.FromArgb(34, 100, 102);

            btnAttendance.BackColor = Color.FromArgb(34, 100, 102);
            btnLeave.BackColor = Color.FromArgb(34, 100, 102);
            loadform(new DashboardAdmin());
        }

        private void btnAttendance_Click(object sender, EventArgs e)
        {
            btnAttendance.BackColor = Color.FromArgb(82, 85, 76);
            btnPayroll.BackColor = Color.FromArgb(34, 100, 102);
           
            btnDashboard.BackColor = Color.FromArgb(34, 100, 102);
            btnLeave.BackColor = Color.FromArgb(34, 100, 102);
            loadform(new AdminAttendance());
        }

        private void btnPayroll_Click(object sender, EventArgs e)
        {
            btnPayroll.BackColor = Color.FromArgb(82, 85, 76);
            btnAttendance.BackColor = Color.FromArgb(34, 100, 102);
            
            btnDashboard.BackColor = Color.FromArgb(34, 100, 102);
            btnLeave.BackColor = Color.FromArgb(34, 100, 102);
            loadform(new PayrollAdmin());
        }

        private void btnLeave_Click(object sender, EventArgs e)
        {
            btnLeave.BackColor = Color.FromArgb(82, 85, 76);
            btnPayroll.BackColor = Color.FromArgb(34, 100, 102);
            
            btnDashboard.BackColor = Color.FromArgb(34, 100, 102);
            btnAttendance.BackColor = Color.FromArgb(34, 100, 102);
            LeaveMessageForm L = new LeaveMessageForm(adminID);
            L.Show();
        }

        public void loadform(object Form)
        {
            if (this.MainPanelAdmin.Controls.Count > 0)
                this.MainPanelAdmin.Controls.RemoveAt(0);
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.MainPanelAdmin.Controls.Add(f);
            this.MainPanelAdmin.Tag = f;
            f.Show();
        }

        private void FormAdmin_Load(object sender, EventArgs e)
        {
            loadform(new DashboardAdmin());
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            NotificationForm nf = new NotificationForm();
            nf.Show();
        }
    }
}
