﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class EmployeeDashboardForm : Form
    {
        string connectionString = "Server=DESKTOP-JMR591K\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";
        private SqlConnection Con;
        private int employeeID;

        public EmployeeDashboardForm(int id)
        {
            employeeID = id;
            InitializeComponent();
            Con = new SqlConnection(connectionString); // Initialize the connection
            LoadEmployeeData(); // Call LoadEmployeeData method when the form loads
        }

        private void LoadEmployeeData()
        {
            string query = "SELECT FullName FROM Employee WHERE EmployeeID = @EmployeeID";

            using (SqlCommand command = new SqlCommand(query, Con))
            {
                command.Parameters.AddWithValue("@EmployeeID", employeeID);

                try
                {
                    Con.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        // Display fetched data in the label
                        Employeelbl.Text = reader["FullName"].ToString(); // Ensure label name is correct
                    }
                    else
                    {
                        MessageBox.Show("Employee not found.");
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

        public void loadform(Form form)
        {
            foreach (Control control in this.EmployeeDashboard.Controls.OfType<Control>().ToList())
            {
                this.EmployeeDashboard.Controls.Remove(control);
                control.Dispose();
            }

            form.TopLevel = false;
            form.Dock = DockStyle.Fill;
            this.EmployeeDashboard.Controls.Add(form);
            this.EmployeeDashboard.Tag = form;

            form.Show();
        }

        private void btnMoreInfoEmployeePay_Click(object sender, EventArgs e)
        {
            loadform(new PayrollForm(employeeID));
        }

        private void btnMoreInfoEmployeeAtt_Click(object sender, EventArgs e)
        {
            loadform(new AttendanceForm(employeeID));
        }
    }
}
