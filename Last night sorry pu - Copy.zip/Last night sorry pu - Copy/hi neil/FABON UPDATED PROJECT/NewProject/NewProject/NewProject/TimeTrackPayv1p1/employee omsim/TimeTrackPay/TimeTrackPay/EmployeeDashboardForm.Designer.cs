﻿namespace TimeTrackPay
{
    partial class EmployeeDashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EmployeeDashboard = new System.Windows.Forms.Panel();
            this.fabonPanel2 = new roundedRectangle.FabonPanel();
            this.Employeelbl = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.fabonPanel6 = new roundedRectangle.FabonPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.fabonPanel3 = new roundedRectangle.FabonPanel();
            this.btnMoreInfoEmployeeAtt = new TimeTrackPay.button();
            this.label5 = new System.Windows.Forms.Label();
            this.fabonPanel4 = new roundedRectangle.FabonPanel();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.fabonPanel7 = new roundedRectangle.FabonPanel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.fabonPanel5 = new roundedRectangle.FabonPanel();
            this.btnMoreInfoEmployeePay = new TimeTrackPay.button();
            this.label6 = new System.Windows.Forms.Label();
            this.EmployeeDashboard.SuspendLayout();
            this.fabonPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.fabonPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.fabonPanel3.SuspendLayout();
            this.fabonPanel4.SuspendLayout();
            this.fabonPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.fabonPanel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // EmployeeDashboard
            // 
            this.EmployeeDashboard.Controls.Add(this.fabonPanel2);
            this.EmployeeDashboard.Controls.Add(this.label5);
            this.EmployeeDashboard.Controls.Add(this.fabonPanel4);
            this.EmployeeDashboard.Controls.Add(this.label6);
            this.EmployeeDashboard.Location = new System.Drawing.Point(2, 1);
            this.EmployeeDashboard.Name = "EmployeeDashboard";
            this.EmployeeDashboard.Size = new System.Drawing.Size(1239, 897);
            this.EmployeeDashboard.TabIndex = 0;
            // 
            // fabonPanel2
            // 
            this.fabonPanel2.BackColor = System.Drawing.Color.White;
            this.fabonPanel2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel2.BorderRadius = 70;
            this.fabonPanel2.BorderSize = 0;
            this.fabonPanel2.Controls.Add(this.Employeelbl);
            this.fabonPanel2.Controls.Add(this.pictureBox2);
            this.fabonPanel2.Controls.Add(this.label2);
            this.fabonPanel2.Controls.Add(this.label1);
            this.fabonPanel2.Controls.Add(this.fabonPanel6);
            this.fabonPanel2.Controls.Add(this.fabonPanel3);
            this.fabonPanel2.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel2.GradientAngle = 90F;
            this.fabonPanel2.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.fabonPanel2.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.fabonPanel2.Location = new System.Drawing.Point(38, 144);
            this.fabonPanel2.Margin = new System.Windows.Forms.Padding(4);
            this.fabonPanel2.Name = "fabonPanel2";
            this.fabonPanel2.Size = new System.Drawing.Size(443, 382);
            this.fabonPanel2.TabIndex = 8;
            // 
            // Employeelbl
            // 
            this.Employeelbl.AutoSize = true;
            this.Employeelbl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.Employeelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Employeelbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.Employeelbl.Location = new System.Drawing.Point(212, 239);
            this.Employeelbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Employeelbl.Name = "Employeelbl";
            this.Employeelbl.Size = new System.Drawing.Size(135, 20);
            this.Employeelbl.TabIndex = 6;
            this.Employeelbl.Text = "Franz Louies C.";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.pictureBox2.Image = global::TimeTrackPay.Properties.Resources.UserLogo;
            this.pictureBox2.Location = new System.Drawing.Point(40, 177);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.pictureBox2.Size = new System.Drawing.Size(137, 117);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(212, 87);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 26);
            this.label2.TabIndex = 3;
            this.label2.Text = "Attendance";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(211, 55);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 26);
            this.label1.TabIndex = 2;
            this.label1.Text = "Employee";
            // 
            // fabonPanel6
            // 
            this.fabonPanel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.fabonPanel6.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel6.BorderRadius = 30;
            this.fabonPanel6.BorderSize = 0;
            this.fabonPanel6.Controls.Add(this.pictureBox1);
            this.fabonPanel6.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel6.GradientAngle = 90F;
            this.fabonPanel6.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel6.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel6.Location = new System.Drawing.Point(40, 32);
            this.fabonPanel6.Margin = new System.Windows.Forms.Padding(4);
            this.fabonPanel6.Name = "fabonPanel6";
            this.fabonPanel6.Size = new System.Drawing.Size(119, 116);
            this.fabonPanel6.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.pictureBox1.Image = global::TimeTrackPay.Properties.Resources.AttendanceLogoMed;
            this.pictureBox1.Location = new System.Drawing.Point(23, 21);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(80, 70);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // fabonPanel3
            // 
            this.fabonPanel3.BackColor = System.Drawing.Color.White;
            this.fabonPanel3.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel3.BorderRadius = 0;
            this.fabonPanel3.BorderSize = 0;
            this.fabonPanel3.Controls.Add(this.btnMoreInfoEmployeeAtt);
            this.fabonPanel3.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel3.GradientAngle = 90F;
            this.fabonPanel3.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel3.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel3.Location = new System.Drawing.Point(0, 302);
            this.fabonPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.fabonPanel3.Name = "fabonPanel3";
            this.fabonPanel3.Size = new System.Drawing.Size(443, 80);
            this.fabonPanel3.TabIndex = 0;
            // 
            // btnMoreInfoEmployeeAtt
            // 
            this.btnMoreInfoEmployeeAtt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.btnMoreInfoEmployeeAtt.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.btnMoreInfoEmployeeAtt.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnMoreInfoEmployeeAtt.BorderRadius = 0;
            this.btnMoreInfoEmployeeAtt.BorderSize = 0;
            this.btnMoreInfoEmployeeAtt.FlatAppearance.BorderSize = 0;
            this.btnMoreInfoEmployeeAtt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMoreInfoEmployeeAtt.ForeColor = System.Drawing.Color.White;
            this.btnMoreInfoEmployeeAtt.Image = global::TimeTrackPay.Properties.Resources.infoButton;
            this.btnMoreInfoEmployeeAtt.Location = new System.Drawing.Point(0, 0);
            this.btnMoreInfoEmployeeAtt.Margin = new System.Windows.Forms.Padding(4);
            this.btnMoreInfoEmployeeAtt.Name = "btnMoreInfoEmployeeAtt";
            this.btnMoreInfoEmployeeAtt.Size = new System.Drawing.Size(443, 80);
            this.btnMoreInfoEmployeeAtt.TabIndex = 0;
            this.btnMoreInfoEmployeeAtt.TextColor = System.Drawing.Color.White;
            this.btnMoreInfoEmployeeAtt.UseVisualStyleBackColor = false;
            this.btnMoreInfoEmployeeAtt.Click += new System.EventHandler(this.btnMoreInfoEmployeeAtt_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Inter", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(31, 24);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(182, 39);
            this.label5.TabIndex = 10;
            this.label5.Text = "Dashboard";
            // 
            // fabonPanel4
            // 
            this.fabonPanel4.BackColor = System.Drawing.Color.White;
            this.fabonPanel4.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel4.BorderRadius = 70;
            this.fabonPanel4.BorderSize = 0;
            this.fabonPanel4.Controls.Add(this.label9);
            this.fabonPanel4.Controls.Add(this.label8);
            this.fabonPanel4.Controls.Add(this.fabonPanel7);
            this.fabonPanel4.Controls.Add(this.pictureBox3);
            this.fabonPanel4.Controls.Add(this.fabonPanel5);
            this.fabonPanel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.fabonPanel4.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel4.GradientAngle = 90F;
            this.fabonPanel4.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.fabonPanel4.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.fabonPanel4.Location = new System.Drawing.Point(552, 144);
            this.fabonPanel4.Margin = new System.Windows.Forms.Padding(4);
            this.fabonPanel4.Name = "fabonPanel4";
            this.fabonPanel4.Size = new System.Drawing.Size(443, 382);
            this.fabonPanel4.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(231, 94);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 26);
            this.label9.TabIndex = 7;
            this.label9.Text = "Payroll";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(231, 55);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 26);
            this.label8.TabIndex = 7;
            this.label8.Text = "Employee";
            // 
            // fabonPanel7
            // 
            this.fabonPanel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.fabonPanel7.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel7.BorderRadius = 30;
            this.fabonPanel7.BorderSize = 0;
            this.fabonPanel7.Controls.Add(this.pictureBox4);
            this.fabonPanel7.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel7.GradientAngle = 90F;
            this.fabonPanel7.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel7.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel7.Location = new System.Drawing.Point(40, 32);
            this.fabonPanel7.Margin = new System.Windows.Forms.Padding(4);
            this.fabonPanel7.Name = "fabonPanel7";
            this.fabonPanel7.Size = new System.Drawing.Size(119, 116);
            this.fabonPanel7.TabIndex = 2;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.pictureBox4.Image = global::TimeTrackPay.Properties.Resources.PayrollLogoBig;
            this.pictureBox4.Location = new System.Drawing.Point(25, 21);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(85, 70);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.pictureBox3.Image = global::TimeTrackPay.Properties.Resources.HistoryLogo;
            this.pictureBox3.Location = new System.Drawing.Point(25, 177);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.pictureBox3.Size = new System.Drawing.Size(133, 117);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // fabonPanel5
            // 
            this.fabonPanel5.BackColor = System.Drawing.Color.White;
            this.fabonPanel5.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel5.BorderRadius = 0;
            this.fabonPanel5.BorderSize = 0;
            this.fabonPanel5.Controls.Add(this.btnMoreInfoEmployeePay);
            this.fabonPanel5.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel5.GradientAngle = 90F;
            this.fabonPanel5.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel5.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel5.Location = new System.Drawing.Point(0, 302);
            this.fabonPanel5.Margin = new System.Windows.Forms.Padding(4);
            this.fabonPanel5.Name = "fabonPanel5";
            this.fabonPanel5.Size = new System.Drawing.Size(443, 80);
            this.fabonPanel5.TabIndex = 0;
            // 
            // btnMoreInfoEmployeePay
            // 
            this.btnMoreInfoEmployeePay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.btnMoreInfoEmployeePay.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.btnMoreInfoEmployeePay.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnMoreInfoEmployeePay.BorderRadius = 0;
            this.btnMoreInfoEmployeePay.BorderSize = 0;
            this.btnMoreInfoEmployeePay.FlatAppearance.BorderSize = 0;
            this.btnMoreInfoEmployeePay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMoreInfoEmployeePay.ForeColor = System.Drawing.Color.White;
            this.btnMoreInfoEmployeePay.Image = global::TimeTrackPay.Properties.Resources.infoButton;
            this.btnMoreInfoEmployeePay.Location = new System.Drawing.Point(0, 0);
            this.btnMoreInfoEmployeePay.Margin = new System.Windows.Forms.Padding(4);
            this.btnMoreInfoEmployeePay.Name = "btnMoreInfoEmployeePay";
            this.btnMoreInfoEmployeePay.Size = new System.Drawing.Size(443, 80);
            this.btnMoreInfoEmployeePay.TabIndex = 1;
            this.btnMoreInfoEmployeePay.TextColor = System.Drawing.Color.White;
            this.btnMoreInfoEmployeePay.UseVisualStyleBackColor = false;
            this.btnMoreInfoEmployeePay.Click += new System.EventHandler(this.btnMoreInfoEmployeePay_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.label6.Location = new System.Drawing.Point(38, 72);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(533, 19);
            this.label6.TabIndex = 11;
            this.label6.Text = "Welcome to Employee Attendance Manangement and Payroll System";
            // 
            // EmployeeDashboardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(1240, 898);
            this.Controls.Add(this.EmployeeDashboard);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "EmployeeDashboardForm";
            this.Text = "EmployeeDashboardForm";
            this.EmployeeDashboard.ResumeLayout(false);
            this.EmployeeDashboard.PerformLayout();
            this.fabonPanel2.ResumeLayout(false);
            this.fabonPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.fabonPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.fabonPanel3.ResumeLayout(false);
            this.fabonPanel4.ResumeLayout(false);
            this.fabonPanel4.PerformLayout();
            this.fabonPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.fabonPanel5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel EmployeeDashboard;
        private roundedRectangle.FabonPanel fabonPanel2;
        private System.Windows.Forms.Label Employeelbl;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private roundedRectangle.FabonPanel fabonPanel6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private roundedRectangle.FabonPanel fabonPanel3;
        private button btnMoreInfoEmployeeAtt;
        private System.Windows.Forms.Label label5;
        private roundedRectangle.FabonPanel fabonPanel4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private roundedRectangle.FabonPanel fabonPanel7;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private roundedRectangle.FabonPanel fabonPanel5;
        private button btnMoreInfoEmployeePay;
        private System.Windows.Forms.Label label6;
    }
}