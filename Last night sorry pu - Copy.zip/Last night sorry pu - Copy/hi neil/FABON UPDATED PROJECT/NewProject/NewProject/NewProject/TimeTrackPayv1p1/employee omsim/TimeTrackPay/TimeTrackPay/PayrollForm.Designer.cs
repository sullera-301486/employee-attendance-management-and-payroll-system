﻿namespace TimeTrackPay
{
    partial class PayrollForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.fabonPanel2 = new roundedRectangle.FabonPanel();
            this.fabonPanel3 = new roundedRectangle.FabonPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.payrollBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dbEmployeeDataSet5 = new TimeTrackPay.dbEmployeeDataSet5();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.EmployeeName = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.fabonPanel1 = new roundedRectangle.FabonPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.payrollTableAdapter = new TimeTrackPay.dbEmployeeDataSet5TableAdapters.PayrollTableAdapter();
            this.payrollIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grossPayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IncomeTax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sSSDeductionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.philHealthDeductionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pagIbigDeductionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalDeductionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.netPayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fabonPanel2.SuspendLayout();
            this.fabonPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.payrollBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbEmployeeDataSet5)).BeginInit();
            this.fabonPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(36, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 46);
            this.label5.TabIndex = 12;
            this.label5.Text = "Payroll";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.label6.Location = new System.Drawing.Point(39, 57);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(652, 25);
            this.label6.TabIndex = 13;
            this.label6.Text = "Review Your Detailed Payroll Information, Including Salary and Deductions";
            // 
            // fabonPanel2
            // 
            this.fabonPanel2.BackColor = System.Drawing.Color.White;
            this.fabonPanel2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel2.BorderRadius = 30;
            this.fabonPanel2.BorderSize = 0;
            this.fabonPanel2.Controls.Add(this.fabonPanel3);
            this.fabonPanel2.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel2.GradientAngle = 90F;
            this.fabonPanel2.GradientBottomColor = System.Drawing.Color.Gray;
            this.fabonPanel2.GradientTopColor = System.Drawing.Color.Gray;
            this.fabonPanel2.Location = new System.Drawing.Point(45, 113);
            this.fabonPanel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fabonPanel2.Name = "fabonPanel2";
            this.fabonPanel2.Size = new System.Drawing.Size(1167, 724);
            this.fabonPanel2.TabIndex = 15;
            // 
            // fabonPanel3
            // 
            this.fabonPanel3.BackColor = System.Drawing.Color.White;
            this.fabonPanel3.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel3.BorderRadius = 30;
            this.fabonPanel3.BorderSize = 0;
            this.fabonPanel3.Controls.Add(this.dataGridView1);
            this.fabonPanel3.Controls.Add(this.label9);
            this.fabonPanel3.Controls.Add(this.label8);
            this.fabonPanel3.Controls.Add(this.EmployeeName);
            this.fabonPanel3.Controls.Add(this.label4);
            this.fabonPanel3.Controls.Add(this.label3);
            this.fabonPanel3.Controls.Add(this.label2);
            this.fabonPanel3.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel3.GradientAngle = 90F;
            this.fabonPanel3.GradientBottomColor = System.Drawing.Color.White;
            this.fabonPanel3.GradientTopColor = System.Drawing.Color.White;
            this.fabonPanel3.Location = new System.Drawing.Point(3, 2);
            this.fabonPanel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fabonPanel3.Name = "fabonPanel3";
            this.fabonPanel3.Size = new System.Drawing.Size(1163, 718);
            this.fabonPanel3.TabIndex = 12;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.payrollIDDataGridViewTextBoxColumn,
            this.employeeIDDataGridViewTextBoxColumn,
            this.grossPayDataGridViewTextBoxColumn,
            this.IncomeTax,
            this.sSSDeductionDataGridViewTextBoxColumn,
            this.philHealthDeductionDataGridViewTextBoxColumn,
            this.pagIbigDeductionDataGridViewTextBoxColumn,
            this.totalDeductionDataGridViewTextBoxColumn,
            this.netPayDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.payrollBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(21, 159);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(1115, 463);
            this.dataGridView1.TabIndex = 6;
            // 
            // payrollBindingSource
            // 
            this.payrollBindingSource.DataMember = "Payroll";
            this.payrollBindingSource.DataSource = this.dbEmployeeDataSet5;
            // 
            // dbEmployeeDataSet5
            // 
            this.dbEmployeeDataSet5.DataSetName = "dbEmployeeDataSet5";
            this.dbEmployeeDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(195, 80);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(255, 29);
            this.label9.TabIndex = 5;
            this.label9.Text = "December 1 - 15, 2024";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(195, 46);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 29);
            this.label8.TabIndex = 4;
            this.label8.Text = "1015";
            // 
            // EmployeeName
            // 
            this.EmployeeName.AutoSize = true;
            this.EmployeeName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeName.Location = new System.Drawing.Point(241, 14);
            this.EmployeeName.Name = "EmployeeName";
            this.EmployeeName.Size = new System.Drawing.Size(330, 29);
            this.EmployeeName.TabIndex = 3;
            this.EmployeeName.Text = "DELORITOS, Franz Louies S.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gray;
            this.label4.Location = new System.Drawing.Point(16, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 29);
            this.label4.TabIndex = 2;
            this.label4.Text = "Pay Period";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(16, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(162, 29);
            this.label3.TabIndex = 1;
            this.label3.Text = "Employee ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gray;
            this.label2.Location = new System.Drawing.Point(16, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(206, 29);
            this.label2.TabIndex = 0;
            this.label2.Text = "Employee Name";
            // 
            // fabonPanel1
            // 
            this.fabonPanel1.BackColor = System.Drawing.Color.White;
            this.fabonPanel1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel1.BorderRadius = 40;
            this.fabonPanel1.BorderSize = 0;
            this.fabonPanel1.Controls.Add(this.label1);
            this.fabonPanel1.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel1.GradientAngle = 90F;
            this.fabonPanel1.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.fabonPanel1.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.fabonPanel1.Location = new System.Drawing.Point(883, 39);
            this.fabonPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fabonPanel1.Name = "fabonPanel1";
            this.fabonPanel1.Size = new System.Drawing.Size(229, 39);
            this.fabonPanel1.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(17, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 29);
            this.label1.TabIndex = 11;
            this.label1.Text = "December 2024";
            // 
            // payrollTableAdapter
            // 
            this.payrollTableAdapter.ClearBeforeFill = true;
            // 
            // payrollIDDataGridViewTextBoxColumn
            // 
            this.payrollIDDataGridViewTextBoxColumn.DataPropertyName = "PayrollID";
            this.payrollIDDataGridViewTextBoxColumn.HeaderText = "PayrollID";
            this.payrollIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.payrollIDDataGridViewTextBoxColumn.Name = "payrollIDDataGridViewTextBoxColumn";
            this.payrollIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.payrollIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            this.employeeIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // grossPayDataGridViewTextBoxColumn
            // 
            this.grossPayDataGridViewTextBoxColumn.DataPropertyName = "GrossPay";
            this.grossPayDataGridViewTextBoxColumn.HeaderText = "GrossPay";
            this.grossPayDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.grossPayDataGridViewTextBoxColumn.Name = "grossPayDataGridViewTextBoxColumn";
            this.grossPayDataGridViewTextBoxColumn.Width = 125;
            // 
            // IncomeTax
            // 
            this.IncomeTax.DataPropertyName = "PayrollID";
            this.IncomeTax.HeaderText = "IncomeTax";
            this.IncomeTax.MinimumWidth = 6;
            this.IncomeTax.Name = "IncomeTax";
            this.IncomeTax.ReadOnly = true;
            this.IncomeTax.Width = 125;
            // 
            // sSSDeductionDataGridViewTextBoxColumn
            // 
            this.sSSDeductionDataGridViewTextBoxColumn.DataPropertyName = "SSSDeduction";
            this.sSSDeductionDataGridViewTextBoxColumn.HeaderText = "SSSDeduction";
            this.sSSDeductionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sSSDeductionDataGridViewTextBoxColumn.Name = "sSSDeductionDataGridViewTextBoxColumn";
            this.sSSDeductionDataGridViewTextBoxColumn.Width = 125;
            // 
            // philHealthDeductionDataGridViewTextBoxColumn
            // 
            this.philHealthDeductionDataGridViewTextBoxColumn.DataPropertyName = "PhilHealthDeduction";
            this.philHealthDeductionDataGridViewTextBoxColumn.HeaderText = "PhilHealthDeduction";
            this.philHealthDeductionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.philHealthDeductionDataGridViewTextBoxColumn.Name = "philHealthDeductionDataGridViewTextBoxColumn";
            this.philHealthDeductionDataGridViewTextBoxColumn.Width = 125;
            // 
            // pagIbigDeductionDataGridViewTextBoxColumn
            // 
            this.pagIbigDeductionDataGridViewTextBoxColumn.DataPropertyName = "PagIbigDeduction";
            this.pagIbigDeductionDataGridViewTextBoxColumn.HeaderText = "PagIbigDeduction";
            this.pagIbigDeductionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.pagIbigDeductionDataGridViewTextBoxColumn.Name = "pagIbigDeductionDataGridViewTextBoxColumn";
            this.pagIbigDeductionDataGridViewTextBoxColumn.Width = 125;
            // 
            // totalDeductionDataGridViewTextBoxColumn
            // 
            this.totalDeductionDataGridViewTextBoxColumn.DataPropertyName = "TotalDeduction";
            this.totalDeductionDataGridViewTextBoxColumn.HeaderText = "TotalDeduction";
            this.totalDeductionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.totalDeductionDataGridViewTextBoxColumn.Name = "totalDeductionDataGridViewTextBoxColumn";
            this.totalDeductionDataGridViewTextBoxColumn.Width = 125;
            // 
            // netPayDataGridViewTextBoxColumn
            // 
            this.netPayDataGridViewTextBoxColumn.DataPropertyName = "NetPay";
            this.netPayDataGridViewTextBoxColumn.HeaderText = "NetPay";
            this.netPayDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.netPayDataGridViewTextBoxColumn.Name = "netPayDataGridViewTextBoxColumn";
            this.netPayDataGridViewTextBoxColumn.Width = 125;
            // 
            // PayrollForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(1240, 898);
            this.Controls.Add(this.fabonPanel2);
            this.Controls.Add(this.fabonPanel1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "PayrollForm";
            this.Text = "PayrollForm";
            this.Load += new System.EventHandler(this.PayrollForm_Load);
            this.fabonPanel2.ResumeLayout(false);
            this.fabonPanel3.ResumeLayout(false);
            this.fabonPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.payrollBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbEmployeeDataSet5)).EndInit();
            this.fabonPanel1.ResumeLayout(false);
            this.fabonPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label EmployeeName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private roundedRectangle.FabonPanel fabonPanel3;
        private roundedRectangle.FabonPanel fabonPanel2;
        private System.Windows.Forms.Label label1;
        private roundedRectangle.FabonPanel fabonPanel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView1;
        private dbEmployeeDataSet5 dbEmployeeDataSet5;
        private System.Windows.Forms.BindingSource payrollBindingSource;
        private dbEmployeeDataSet5TableAdapters.PayrollTableAdapter payrollTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn payrollIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn grossPayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn IncomeTax;
        private System.Windows.Forms.DataGridViewTextBoxColumn sSSDeductionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn philHealthDeductionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pagIbigDeductionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalDeductionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn netPayDataGridViewTextBoxColumn;
    }
}