﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace TimeTrackPay
{
    public partial class LeaveMessageForm : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,     // x-coordinate of upper-left corner
            int nTopRect,      // y-coordinate of upper-left corner
            int nRightRect,    // x-coordinate of lower-right corner
            int nBottomRect,   // y-coordinate of lower-right corner
            int nWidthEllipse, // height of ellipse
            int nHeightEllipse // width of ellipse
        );

        private int employeeID;
        string connectionString = "Server=LAPTOP-PVCP8MJI\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";

        public LeaveMessageForm(int id)
        {
            employeeID = id;
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.None;
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20));
        }

        private void LeaveMessageForm_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnYes_Paint(object sender, PaintEventArgs e)
        {
            
            
        }

        private void btnYes_MouseClick(object sender, MouseEventArgs e)
        {
            Application.Exit();
        }

        private void btnNo_MouseClick(object sender, MouseEventArgs e)
        {
            this.Close();
        }

        private void UpdateTimeOut()
        {
            string query = "UPDATE AttendanceEmployee SET TimeOut = @TimeOut WHERE EmployeeID = @EmployeeID AND Date = @Date";

            using (SqlConnection Con = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, Con))
            {
                command.Parameters.AddWithValue("@EmployeeID", employeeID);
                command.Parameters.AddWithValue("@Date", DateTime.Now.Date);
                command.Parameters.AddWithValue("@TimeOut", DateTime.Now);

                try
                {
                    Con.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("TimeOut updated successfully."); // Success message
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while updating TimeOut: " + ex.Message);
                }
            }
        }
    }
}
