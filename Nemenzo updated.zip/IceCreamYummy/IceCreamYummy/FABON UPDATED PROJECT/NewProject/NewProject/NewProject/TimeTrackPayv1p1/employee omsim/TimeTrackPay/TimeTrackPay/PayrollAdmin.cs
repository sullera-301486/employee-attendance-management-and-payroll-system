﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class PayrollAdmin : Form
    {
        public PayrollAdmin()
        {
            InitializeComponent();
        }

        private void PayrollAdmin_Load(object sender, EventArgs e)
        {
            loadform(new PayrollLogsForm());
        }
       
        public void loadform(object Form)
        {
            if (this.PayrollPanel.Controls.Count > 0)
                this.PayrollPanel.Controls.RemoveAt(0);
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.PayrollPanel.Controls.Add(f);
            this.PayrollPanel.Tag = f;
            f.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            label2.ForeColor = Color.Black;
            label3.ForeColor = Color.Gray;

            loadform(new PayrollLogsForm());

        }

        private void label3_Click(object sender, EventArgs e)
        {
            label2.ForeColor = Color.Gray;
            label3.ForeColor = Color.Black;
            loadform(new NewPayForm());
        }

        private void PayrollPanel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
