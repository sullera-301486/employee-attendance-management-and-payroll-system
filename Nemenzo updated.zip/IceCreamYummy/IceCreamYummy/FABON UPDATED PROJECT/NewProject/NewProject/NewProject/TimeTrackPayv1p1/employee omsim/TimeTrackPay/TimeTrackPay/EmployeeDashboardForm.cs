﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class EmployeeDashboardForm : Form
    {
        string connectionString = "Server=DESKTOP-JMR591K\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";
        private SqlConnection Con;
        private int employeeID;

        public EmployeeDashboardForm(int id)
        {
            InitializeComponent();
            employeeID = id;
            Con = new SqlConnection(connectionString); // Initialize the connection
            LoadEmployeeData(); // Call LoadEmployeeData method when the form loads
        }

        private void LoadEmployeeData()
        {
            string query = "SELECT FullName FROM Employee WHERE EmployeeID = @EmployeeID";

            using (SqlCommand command = new SqlCommand(query, Con))
            {
                command.Parameters.AddWithValue("@EmployeeID", employeeID);

                try
                {
                    Con.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        // Display fetched data in the label
                        Employeelbl.Text = reader["FullName"].ToString(); // Ensure label name is correct
                    }
                    else
                    {
                        MessageBox.Show("Employee not found.");
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }
    }
}
