﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class DashboardEmployee : Form
    {
        private int employeeID;
        SqlConnection Con = new SqlConnection(@"Server=DESKTOP-JMR591K\SQLEXPRESS; Database=dbEmployee; Integrated Security=True");

        public DashboardEmployee(int id)
        {
            InitializeComponent();
            employeeID = id;
            MessageBox.Show("Employee ID: " + employeeID); // Debugging step to confirm employeeID is passed correctly
            LoadData(); // Call LoadData method when the form loads
        }

        private void LoadData()
        {
            string query = "SELECT FullName FROM Employee WHERE EmployeeID = @EmployeeID";

            using (SqlCommand command = new SqlCommand(query, Con))
            {
                command.Parameters.AddWithValue("@EmployeeID", employeeID);

                try
                {
                    Con.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        // Display fetched data in the label
                        EmployeeName.Text = reader["FullName"].ToString(); // Ensure column name is correct

                        // Debugging Information
                        MessageBox.Show("FullName: " + reader["FullName"].ToString());
                    }
                    else
                    {
                        MessageBox.Show("Employee not found.");
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

        // Event handlers and other methods
        private void btnAttendance_Click(object sender, EventArgs e)
        {
            btnAttendance.BackColor = Color.FromArgb(82, 85, 76);
            btnPayroll.BackColor = Color.FromArgb(34, 100, 102);
            btnProfile.BackColor = Color.FromArgb(34, 100, 102);
            btnDashboard.BackColor = Color.FromArgb(34, 100, 102);
            btnLeave.BackColor = Color.FromArgb(34, 100, 102);
  
        }

        private void btnLeave_Click(object sender, EventArgs e)
        {
            btnLeave.BackColor = Color.FromArgb(82, 85, 76);
            btnPayroll.BackColor = Color.FromArgb(34, 100, 102);
            btnProfile.BackColor = Color.FromArgb(34, 100, 102);
            btnDashboard.BackColor = Color.FromArgb(34, 100, 102);
            btnAttendance.BackColor = Color.FromArgb(34, 100, 102);
            LeaveMessageForm L = new LeaveMessageForm(employeeID); // Pass employeeID to LeaveMessageForm
            L.Show();
        }

        private void btnPayroll_Click(object sender, EventArgs e)
        {
            btnPayroll.BackColor = Color.FromArgb(82, 85, 76);
            btnAttendance.BackColor = Color.FromArgb(34, 100, 102);
            btnProfile.BackColor = Color.FromArgb(34, 100, 102);
            btnDashboard.BackColor = Color.FromArgb(34, 100, 102);
            btnLeave.BackColor = Color.FromArgb(34, 100, 102);
            loadform(new PayrollForm(employeeID)); // Pass employeeID to PayrollForm
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            btnProfile.BackColor = Color.FromArgb(82, 85, 76);
            btnPayroll.BackColor = Color.FromArgb(34, 100, 102);
            btnAttendance.BackColor = Color.FromArgb(34, 100, 102);
            btnDashboard.BackColor = Color.FromArgb(34, 100, 102);
            btnLeave.BackColor = Color.FromArgb(34, 100, 102);
            loadform(new ProfileForm(employeeID)); // Pass employeeID to ProfileForm
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            btnDashboard.BackColor = Color.FromArgb(82, 85, 76);
            btnPayroll.BackColor = Color.FromArgb(34, 100, 102);
            btnProfile.BackColor = Color.FromArgb(34, 100, 102);
            btnAttendance.BackColor = Color.FromArgb(34, 100, 102);
            btnLeave.BackColor = Color.FromArgb(34, 100, 102);
            loadform(new EmployeeDashboardForm(employeeID)); // Pass employeeID to EmployeeDashboardForm
        }

        public void loadform(object Form)
        {
            if (this.MainPanel.Controls.Count > 0)
                this.MainPanel.Controls.RemoveAt(0);
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.MainPanel.Controls.Add(f);
            this.MainPanel.Tag = f;
            f.Show();
        }
    }
}
