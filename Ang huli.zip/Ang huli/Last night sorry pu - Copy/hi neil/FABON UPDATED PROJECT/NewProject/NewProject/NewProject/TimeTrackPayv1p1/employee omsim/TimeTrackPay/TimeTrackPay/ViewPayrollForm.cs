﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class ViewPayrollForm : Form
    {
        public ViewPayrollForm()
        {
            InitializeComponent();
        }

        public void SetData(string id, string name)
        {
            // Set the data to the labels or text boxes
            label5.Text = name;
            label6.Text = id;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
