﻿namespace TimeTrackPay
{
    partial class NewPayForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new TimeTrackPay.button();
            this.fabonPanel3 = new roundedRectangle.FabonPanel();
            this.ncnemrnzoPanel = new roundedRectangle.FabonPanel();
            this.NetPay = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.totalDeduction = new System.Windows.Forms.Label();
            this.income = new System.Windows.Forms.Label();
            this.PagibigDeduc = new System.Windows.Forms.Label();
            this.PhilDeduc = new System.Windows.Forms.Label();
            this.SSSDeduc = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.compute = new TimeTrackPay.button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.fabonPanel1 = new roundedRectangle.FabonPanel();
            this.fabonPanel2 = new roundedRectangle.FabonPanel();
            this.textBoxAdminid = new System.Windows.Forms.TextBox();
            this.ad = new System.Windows.Forms.Label();
            this.textBoxPayriod = new System.Windows.Forms.TextBox();
            this.pa = new System.Windows.Forms.Label();
            this.textboxemployeeid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.fabonPanel3.SuspendLayout();
            this.ncnemrnzoPanel.SuspendLayout();
            this.fabonPanel1.SuspendLayout();
            this.fabonPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.button2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.button2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.button2.BorderRadius = 5;
            this.button2.BorderSize = 0;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(632, 326);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 40);
            this.button2.TabIndex = 10;
            this.button2.Text = "Submit";
            this.button2.TextColor = System.Drawing.Color.White;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // fabonPanel3
            // 
            this.fabonPanel3.BackColor = System.Drawing.Color.White;
            this.fabonPanel3.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel3.BorderRadius = 30;
            this.fabonPanel3.BorderSize = 0;
            this.fabonPanel3.Controls.Add(this.ncnemrnzoPanel);
            this.fabonPanel3.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel3.GradientAngle = 90F;
            this.fabonPanel3.GradientBottomColor = System.Drawing.Color.Silver;
            this.fabonPanel3.GradientTopColor = System.Drawing.Color.Silver;
            this.fabonPanel3.Location = new System.Drawing.Point(327, 5);
            this.fabonPanel3.Name = "fabonPanel3";
            this.fabonPanel3.Size = new System.Drawing.Size(506, 286);
            this.fabonPanel3.TabIndex = 9;
            // 
            // ncnemrnzoPanel
            // 
            this.ncnemrnzoPanel.BackColor = System.Drawing.Color.White;
            this.ncnemrnzoPanel.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.ncnemrnzoPanel.BorderRadius = 30;
            this.ncnemrnzoPanel.BorderSize = 0;
            this.ncnemrnzoPanel.Controls.Add(this.NetPay);
            this.ncnemrnzoPanel.Controls.Add(this.label13);
            this.ncnemrnzoPanel.Controls.Add(this.totalDeduction);
            this.ncnemrnzoPanel.Controls.Add(this.income);
            this.ncnemrnzoPanel.Controls.Add(this.PagibigDeduc);
            this.ncnemrnzoPanel.Controls.Add(this.PhilDeduc);
            this.ncnemrnzoPanel.Controls.Add(this.SSSDeduc);
            this.ncnemrnzoPanel.Controls.Add(this.textBox4);
            this.ncnemrnzoPanel.Controls.Add(this.label10);
            this.ncnemrnzoPanel.Controls.Add(this.compute);
            this.ncnemrnzoPanel.Controls.Add(this.label9);
            this.ncnemrnzoPanel.Controls.Add(this.label8);
            this.ncnemrnzoPanel.Controls.Add(this.label7);
            this.ncnemrnzoPanel.Controls.Add(this.label6);
            this.ncnemrnzoPanel.Controls.Add(this.label4);
            this.ncnemrnzoPanel.ForeColor = System.Drawing.Color.Black;
            this.ncnemrnzoPanel.GradientAngle = 90F;
            this.ncnemrnzoPanel.GradientBottomColor = System.Drawing.Color.White;
            this.ncnemrnzoPanel.GradientTopColor = System.Drawing.Color.White;
            this.ncnemrnzoPanel.Location = new System.Drawing.Point(3, 3);
            this.ncnemrnzoPanel.Name = "ncnemrnzoPanel";
            this.ncnemrnzoPanel.Size = new System.Drawing.Size(500, 283);
            this.ncnemrnzoPanel.TabIndex = 0;
            // 
            // NetPay
            // 
            this.NetPay.AutoSize = true;
            this.NetPay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetPay.Location = new System.Drawing.Point(200, 251);
            this.NetPay.Name = "NetPay";
            this.NetPay.Size = new System.Drawing.Size(35, 16);
            this.NetPay.TabIndex = 17;
            this.NetPay.Text = "0.00";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(30, 251);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 16);
            this.label13.TabIndex = 16;
            this.label13.Text = "Net Pay";
            // 
            // totalDeduction
            // 
            this.totalDeduction.AutoSize = true;
            this.totalDeduction.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalDeduction.Location = new System.Drawing.Point(200, 217);
            this.totalDeduction.Name = "totalDeduction";
            this.totalDeduction.Size = new System.Drawing.Size(35, 16);
            this.totalDeduction.TabIndex = 15;
            this.totalDeduction.Text = "0.00";
            // 
            // income
            // 
            this.income.AutoSize = true;
            this.income.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.income.Location = new System.Drawing.Point(200, 162);
            this.income.Name = "income";
            this.income.Size = new System.Drawing.Size(35, 16);
            this.income.TabIndex = 14;
            this.income.Text = "0.00";
            // 
            // PagibigDeduc
            // 
            this.PagibigDeduc.AutoSize = true;
            this.PagibigDeduc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PagibigDeduc.Location = new System.Drawing.Point(200, 128);
            this.PagibigDeduc.Name = "PagibigDeduc";
            this.PagibigDeduc.Size = new System.Drawing.Size(35, 16);
            this.PagibigDeduc.TabIndex = 13;
            this.PagibigDeduc.Text = "0.00";
            // 
            // PhilDeduc
            // 
            this.PhilDeduc.AutoSize = true;
            this.PhilDeduc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhilDeduc.Location = new System.Drawing.Point(200, 92);
            this.PhilDeduc.Name = "PhilDeduc";
            this.PhilDeduc.Size = new System.Drawing.Size(35, 16);
            this.PhilDeduc.TabIndex = 12;
            this.PhilDeduc.Text = "0.00";
            this.PhilDeduc.Click += new System.EventHandler(this.PhilDeduc_Click);
            // 
            // SSSDeduc
            // 
            this.SSSDeduc.AutoSize = true;
            this.SSSDeduc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SSSDeduc.Location = new System.Drawing.Point(200, 54);
            this.SSSDeduc.Name = "SSSDeduc";
            this.SSSDeduc.Size = new System.Drawing.Size(35, 16);
            this.SSSDeduc.TabIndex = 11;
            this.SSSDeduc.Text = "0.00";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(161, 10);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(141, 26);
            this.textBox4.TabIndex = 10;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(30, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 16);
            this.label10.TabIndex = 6;
            this.label10.Text = "Basic Salary";
            // 
            // compute
            // 
            this.compute.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.compute.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.compute.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.compute.BorderRadius = 5;
            this.compute.BorderSize = 0;
            this.compute.FlatAppearance.BorderSize = 0;
            this.compute.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.compute.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.compute.ForeColor = System.Drawing.Color.White;
            this.compute.Location = new System.Drawing.Point(302, 189);
            this.compute.Name = "compute";
            this.compute.Size = new System.Drawing.Size(83, 26);
            this.compute.TabIndex = 6;
            this.compute.Text = "Compute";
            this.compute.TextColor = System.Drawing.Color.White;
            this.compute.UseVisualStyleBackColor = false;
            this.compute.Click += new System.EventHandler(this.compute_Click_1);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(24, 217);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(117, 16);
            this.label9.TabIndex = 5;
            this.label9.Text = "Total Deduction";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(30, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(135, 16);
            this.label8.TabIndex = 4;
            this.label8.Text = "Pagibig Deduction";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(30, 92);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(152, 16);
            this.label7.TabIndex = 3;
            this.label7.Text = "PhilHealth Deduction";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(30, 54);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "SSS Deduction";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(30, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "Income Tax";
            // 
            // fabonPanel1
            // 
            this.fabonPanel1.BackColor = System.Drawing.Color.White;
            this.fabonPanel1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel1.BorderRadius = 30;
            this.fabonPanel1.BorderSize = 0;
            this.fabonPanel1.Controls.Add(this.fabonPanel2);
            this.fabonPanel1.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel1.GradientAngle = 90F;
            this.fabonPanel1.GradientBottomColor = System.Drawing.Color.Silver;
            this.fabonPanel1.GradientTopColor = System.Drawing.Color.Silver;
            this.fabonPanel1.Location = new System.Drawing.Point(22, 2);
            this.fabonPanel1.Name = "fabonPanel1";
            this.fabonPanel1.Size = new System.Drawing.Size(285, 417);
            this.fabonPanel1.TabIndex = 8;
            // 
            // fabonPanel2
            // 
            this.fabonPanel2.BackColor = System.Drawing.Color.White;
            this.fabonPanel2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel2.BorderRadius = 30;
            this.fabonPanel2.BorderSize = 0;
            this.fabonPanel2.Controls.Add(this.textBoxAdminid);
            this.fabonPanel2.Controls.Add(this.ad);
            this.fabonPanel2.Controls.Add(this.textBoxPayriod);
            this.fabonPanel2.Controls.Add(this.pa);
            this.fabonPanel2.Controls.Add(this.textboxemployeeid);
            this.fabonPanel2.Controls.Add(this.label1);
            this.fabonPanel2.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel2.GradientAngle = 90F;
            this.fabonPanel2.GradientBottomColor = System.Drawing.Color.White;
            this.fabonPanel2.GradientTopColor = System.Drawing.Color.White;
            this.fabonPanel2.Location = new System.Drawing.Point(3, 3);
            this.fabonPanel2.Name = "fabonPanel2";
            this.fabonPanel2.Size = new System.Drawing.Size(279, 411);
            this.fabonPanel2.TabIndex = 0;
            // 
            // textBoxAdminid
            // 
            this.textBoxAdminid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAdminid.Location = new System.Drawing.Point(17, 165);
            this.textBoxAdminid.Name = "textBoxAdminid";
            this.textBoxAdminid.Size = new System.Drawing.Size(244, 26);
            this.textBoxAdminid.TabIndex = 9;
            this.textBoxAdminid.TextChanged += new System.EventHandler(this.textBoxAdminid_TextChanged);
            // 
            // ad
            // 
            this.ad.AutoSize = true;
            this.ad.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ad.Location = new System.Drawing.Point(13, 131);
            this.ad.Name = "ad";
            this.ad.Size = new System.Drawing.Size(95, 24);
            this.ad.TabIndex = 8;
            this.ad.Text = "Admin ID";
            // 
            // textBoxPayriod
            // 
            this.textBoxPayriod.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPayriod.Location = new System.Drawing.Point(17, 284);
            this.textBoxPayriod.Name = "textBoxPayriod";
            this.textBoxPayriod.Size = new System.Drawing.Size(244, 26);
            this.textBoxPayriod.TabIndex = 7;
            this.textBoxPayriod.TextChanged += new System.EventHandler(this.textBoxPayriod_TextChanged);
            // 
            // pa
            // 
            this.pa.AutoSize = true;
            this.pa.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pa.Location = new System.Drawing.Point(13, 254);
            this.pa.Name = "pa";
            this.pa.Size = new System.Drawing.Size(111, 24);
            this.pa.TabIndex = 4;
            this.pa.Text = "Pay Period";
            // 
            // textboxemployeeid
            // 
            this.textboxemployeeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textboxemployeeid.Location = new System.Drawing.Point(17, 57);
            this.textboxemployeeid.Name = "textboxemployeeid";
            this.textboxemployeeid.Size = new System.Drawing.Size(244, 26);
            this.textboxemployeeid.TabIndex = 3;
            this.textboxemployeeid.TextChanged += new System.EventHandler(this.textboxemployeeid_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employee ID";
            // 
            // NewPayForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(250)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(855, 421);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.fabonPanel3);
            this.Controls.Add(this.fabonPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "NewPayForm";
            this.Text = "NewPayForm";
            this.Load += new System.EventHandler(this.NewPayForm_Load);
            this.fabonPanel3.ResumeLayout(false);
            this.ncnemrnzoPanel.ResumeLayout(false);
            this.ncnemrnzoPanel.PerformLayout();
            this.fabonPanel1.ResumeLayout(false);
            this.fabonPanel2.ResumeLayout(false);
            this.fabonPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private button button2;
        private System.Windows.Forms.Label pa;
        private System.Windows.Forms.TextBox textboxemployeeid;
        private System.Windows.Forms.Label label1;
        private roundedRectangle.FabonPanel fabonPanel2;
        private roundedRectangle.FabonPanel fabonPanel1;
        private System.Windows.Forms.TextBox textBoxPayriod;
        private button compute;
        private roundedRectangle.FabonPanel fabonPanel3;
        private roundedRectangle.FabonPanel ncnemrnzoPanel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxAdminid;
        private System.Windows.Forms.Label ad;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label PhilDeduc;
        private System.Windows.Forms.Label SSSDeduc;
        private System.Windows.Forms.Label totalDeduction;
        private System.Windows.Forms.Label income;
        private System.Windows.Forms.Label PagibigDeduc;
        private System.Windows.Forms.Label NetPay;
        private System.Windows.Forms.Label label13;
    }
}