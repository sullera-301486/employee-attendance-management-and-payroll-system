﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace TimeTrackPay
{
    public partial class adminAttendanceEdit : Form
    {
        SqlConnection Con;
        string connectionString = "Server=DESKTOP-JMR591K\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";
        public adminAttendanceEdit()
        {
            InitializeComponent();
        }

        private void adminAttendanceDelete_Load(object sender, EventArgs e)
        {

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            adminAttendanceNew attendanceNew = new adminAttendanceNew();
            attendanceNew.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            int employeeID = Convert.ToInt32(txtEmployee.Text);
            var dateCreate = txtDate.Text;
            var dateTimeIn = DateTime.Parse(txtTimeIn.Text);
            var dateTimeOut = DateTime.Parse(txtTimeOut.Text);
            bool onTime = now.TimeOfDay < new TimeSpan(7, 0, 0);
            double totalHours = (dateTimeOut - dateTimeIn).TotalHours;
            string query = "INSERT INTO AttendanceEmployee (EmployeeID, Date, TimeIn, TimeOut, TotalHours, IsLate, OnTime) " +
                "VALUES (@EmployeeID, @Date, @TimeIN, @TimeOut, @OnTime, @IsLate, @TotalHours)";

            using (SqlConnection Con = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, Con))
            {
                command.Parameters.AddWithValue("@EmployeeID", employeeID);
                command.Parameters.AddWithValue("@Date", dateCreate);
                command.Parameters.AddWithValue("@TimeIN", dateTimeIn);
                command.Parameters.AddWithValue("@TimeOut", dateTimeOut);
                command.Parameters.AddWithValue("@OnTime", onTime ? 1 : 0);
                command.Parameters.AddWithValue("@IsLate", onTime ? 0 : 1);
                command.Parameters.AddWithValue("@TotalHours", totalHours);

                try
                {
                    Con.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Attendance updated successfully."); // Success message
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while updating TimeOut: " + ex.Message);
                }
                Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            adminAttendanceDelete attendanceDelete = new adminAttendanceDelete();
            attendanceDelete.Show();
        }
    }
}
