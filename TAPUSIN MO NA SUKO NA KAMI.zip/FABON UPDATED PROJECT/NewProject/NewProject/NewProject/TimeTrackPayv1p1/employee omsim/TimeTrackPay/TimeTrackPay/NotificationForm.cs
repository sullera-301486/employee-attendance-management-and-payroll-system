﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class NotificationForm : Form
    {
        public NotificationForm()
        {
            InitializeComponent();
            NotifView();
        }

        private void NotifView()
        {
            List<NotificationData> notif = new List<NotificationData>();
            notif.Add(new NotificationData("Charles Macaraig"));
            notif.Add(new NotificationData("Ej Sullera"));
            notif.Add(new NotificationData("Marcus Verzo"));
            notif.Add(new NotificationData("Franz Deloritos"));
            notif.Add(new NotificationData("Karl Angelo Fabon"));
            notif.Add(new NotificationData("Neil Nemenzo"));

            foreach (NotificationData n in notif)
            {
                int rowIndex = dataGridView1.Rows.Add();
                DataGridViewRow row = dataGridView1.Rows[rowIndex];
                row.Cells[0].Value = n.Name;
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Ensure a valid row is selected
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                // Create an instance of the detail form
                LeaveRequestApproval lra = new LeaveRequestApproval();

                // Pass the data to the detail form
                lra.notifData(selectedRow.Cells[0].Value.ToString());

                // Show the detail form
                lra.ShowDialog();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
