﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class PayrollForm : Form
    {
        private int employeeID;
        string connectionString = "Server=DESKTOP-JMR591K\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";
        private SqlConnection Con;

        public PayrollForm(int id)
        {
            InitializeComponent();
            employeeID = id;
            Con = new SqlConnection(connectionString); // Initialize the connection
            LoadEmployeeData(); // Call LoadEmployeeData method to fetch and display employee details
            PayrollView();
        }

        private void PayrollForm_Load(object sender, EventArgs e)
        {
            AdjustDataGridHeights();
        }

        private void AdjustDataGridHeights()
        {
            var height = dataGridView1.ColumnHeadersHeight;
            foreach (DataGridViewRow dr in dataGridView1.Rows)
            {
                height += dr.Height;
            }
            dataGridView1.Height = height;
        }

        private void LoadEmployeeData()
        {
            string query = "SELECT FullName, EmployeeID FROM Employee WHERE EmployeeID = @EmployeeID";

            using (SqlCommand command = new SqlCommand(query, Con))
            {
                command.Parameters.AddWithValue("@EmployeeID", employeeID);

                try
                {
                    Con.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        // Display fetched data in the labels
                        EmployeeName.Text = reader["FullName"].ToString();
                        Employeeid.Text = reader["EmployeeID"].ToString();

                        // Debugging Information
                        MessageBox.Show("FullName: " + reader["FullName"].ToString());
                        MessageBox.Show("EmployeeID: " + reader["EmployeeID"].ToString());
                    }
                    else
                    {
                        MessageBox.Show("Employee not found.");
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

        private void PayrollView()
        {
            List<PayrollData> pd = new List<PayrollData>();
            pd.Add(new PayrollData("Basic Salary", "25,000.00", "income TAX", "500.00"));
            pd.Add(new PayrollData("Gross Pay", "25,000.00", "Pag-IBIG", "100.00"));
            pd.Add(new PayrollData(" ", " ", "PhilHealth", "150.00"));
            pd.Add(new PayrollData(" ", " ", "SSS", "250.00"));
            pd.Add(new PayrollData(" ", " ", "Total Deductions", "1,000.00"));
            pd.Add(new PayrollData("Net Pay", "24,000.00", " ", " "));

            foreach (PayrollData d in pd)
            {
                int rowIndex = dataGridView1.Rows.Add();
                DataGridViewRow row = dataGridView1.Rows[rowIndex];
                row.Cells[0].Value = d.Earnings;
                row.Cells[1].Value = d.Amount;
                row.Cells[2].Value = d.Deductions;
                row.Cells[3].Value = d.Amounts;
            }
        }
    }
}
