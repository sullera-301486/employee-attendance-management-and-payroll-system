﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TimeTrackPay
{
    public partial class NewPayForm : Form
    {
        public NewPayForm()
        {
            InitializeComponent();
            PayrollView();
        }

        private void NewPayForm_Load(object sender, EventArgs e)
        {
            AdjustDataGridHeights();
        }
        private void AdjustDataGridHeights()
        {
            var height = dataGridView1.ColumnHeadersHeight;
            foreach (DataGridViewRow dr in dataGridView1.Rows)
            {
                height += dr.Height;
            }
            dataGridView1.Height = height;
        }
        private void PayrollView()
        {
            List<PayrollData> pd = new List<PayrollData>();
            pd.Add(new PayrollData("Basic Salary", "25,000.00", "income TAX", "500.00"));
            pd.Add(new PayrollData("Gross Pay", "25,000.00", "Pag-IBIG", "100.00"));
            pd.Add(new PayrollData(" ", " ", "PhilHealth", "150.00"));
            pd.Add(new PayrollData(" ", " ", "SSS", "250.00"));
            pd.Add(new PayrollData(" ", " ", "Total Deductions", "1,000.00"));
            pd.Add(new PayrollData("Net Pay", "24,000.00", " ", " "));

            foreach (PayrollData d in pd)
            {
                int rowIndex = dataGridView1.Rows.Add();
                DataGridViewRow row = dataGridView1.Rows[rowIndex];
                row.Cells[0].Value = d.Earnings;
                row.Cells[1].Value = d.Amount;
                row.Cells[2].Value = d.Deductions;
                row.Cells[3].Value = d.Amounts;
            }
        }
    }
}
