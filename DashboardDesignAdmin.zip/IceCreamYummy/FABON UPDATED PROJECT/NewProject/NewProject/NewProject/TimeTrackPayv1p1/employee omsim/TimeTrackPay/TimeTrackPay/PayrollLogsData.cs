﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeTrackPay
{
    internal class PayrollLogsData
    {
        public string EmployeeID { get; set; }
        public string Employee { get; set; }
        public string PaymentData { get; set; }
        public string StartingDate { get; set; }
        public string TotalHours1 { get; set; }
        public string GrossPay { get; set; }

        public PayrollLogsData(string empID, string emp, string pd, string sd, string th1, string gp)
        {
            this.EmployeeID = empID;
            this.Employee = emp;
            this.PaymentData = pd;
            this.StartingDate = sd;
            this.TotalHours1 = th1;
            this.GrossPay = gp;
        }
    }
}
