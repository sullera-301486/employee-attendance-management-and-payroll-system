﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TimeTrackPay
{
    public partial class LoginInfo : Form
    {
        LoginPage loginPage;
        DashboardEmployee dashboardEmployee;
        public LoginInfo()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Server=LAPTOP-DLKIA2TF\SQLEXPRESS; Database=dbEmployee; Integrated Security = True");
        public static string user;

        Bitmap buttonLargeEventEnter = Properties.Resources.LoginButtonLargeHover;
        Bitmap buttonLargeEventLeave = Properties.Resources.LoginButtonLarge;

        private void label2_Click(object sender, EventArgs e)
        {
            if (loginPage == null)
            {
                loginPage = new LoginPage();   //Create LoginPage
                loginPage.FormClosed += loginPage_FormClosed;  //Add eventhandler to cleanup
            }

            loginPage.Show(this);  //Show Form 
            Hide();
        }

        void loginPage_FormClosed(object sender, FormClosedEventArgs e)
        {
            loginPage = null;  //If form is closed make sure reference is set to null
            Hide();
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.Image = buttonLargeEventEnter;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.Image = buttonLargeEventLeave;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (textBox2.UseSystemPasswordChar == false)
            {
                textBox2.UseSystemPasswordChar = true;
            } else if (textBox2.UseSystemPasswordChar == true)
            {
                textBox2.UseSystemPasswordChar = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Missing Information!!");
            }
            else
            {
                // Try to authenticate as Admin
                string query = "select count(*) from Admin where AdminID=@AdminID and AdminPassword=@Password";
                SqlDataAdapter sda = new SqlDataAdapter(query, Con);
                sda.SelectCommand.Parameters.AddWithValue("@AdminID", textBox1.Text);
                sda.SelectCommand.Parameters.AddWithValue("@Password", textBox2.Text);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                // If the Admin authentication succeeds
                if (dt.Rows[0][0].ToString() == "1")
                {
                    user = textBox1.Text;
                    FormAdmin F1 = new FormAdmin();  // Create dashboard for employee
                    F1.Show();
                    this.Hide();
                }
                else
                {
                    // Try to authenticate as Employee if Admin fails
                    query = "select count(*) from Employee where EmployeeId=@EmployeeId and EmployeePassword=@Password";
                    sda = new SqlDataAdapter(query, Con);
                    sda.SelectCommand.Parameters.AddWithValue("@EmployeeId", textBox1.Text);
                    sda.SelectCommand.Parameters.AddWithValue("@Password", textBox2.Text);
                    dt = new DataTable();
                    sda.Fill(dt);

                    // If the Employee authentication succeeds
                    if (dt.Rows[0][0].ToString() == "1")
                    {
                        user = textBox1.Text;
                        DashboardEmployee f2 = new DashboardEmployee();  // Create dashboard for employee
                        f2.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Wrong UserName or Password!");
                    }
                }



                Con.Close();
            }


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void LoginInfo_Load(object sender, EventArgs e)
        {

        }
    }
}
