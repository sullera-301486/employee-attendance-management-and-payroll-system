﻿namespace TimeTrackPay
{
    partial class ProfileForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.fabonPanel4 = new roundedRectangle.FabonPanel();
            this.fabonPanel12 = new roundedRectangle.FabonPanel();
            this.fabonPanel15 = new roundedRectangle.FabonPanel();
            this.IDemployee = new System.Windows.Forms.Label();
            this.fabonPanel14 = new roundedRectangle.FabonPanel();
            this.WorkedForEmployee = new System.Windows.Forms.Label();
            this.fabonPanel13 = new roundedRectangle.FabonPanel();
            this.HireDateEmployee = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.fabonPanel3 = new roundedRectangle.FabonPanel();
            this.fabonPanel11 = new roundedRectangle.FabonPanel();
            this.EmployeeAddress = new System.Windows.Forms.Label();
            this.EmployeeBday = new System.Windows.Forms.Label();
            this.EmployeeEmail = new System.Windows.Forms.Label();
            this.PhoneNumber = new System.Windows.Forms.Label();
            this.EmployeePosition = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.NameEmployee = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.fabonPanel4.SuspendLayout();
            this.fabonPanel12.SuspendLayout();
            this.fabonPanel15.SuspendLayout();
            this.fabonPanel14.SuspendLayout();
            this.fabonPanel13.SuspendLayout();
            this.fabonPanel3.SuspendLayout();
            this.fabonPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Inter", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(228, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Profile Details";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Location = new System.Drawing.Point(16, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(406, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Your personal profile information is displayed below";
            // 
            // fabonPanel4
            // 
            this.fabonPanel4.BackColor = System.Drawing.Color.White;
            this.fabonPanel4.BorderRadius = 30;
            this.fabonPanel4.Controls.Add(this.fabonPanel12);
            this.fabonPanel4.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel4.GradientAngle = 90F;
            this.fabonPanel4.GradientBottomColor = System.Drawing.Color.Black;
            this.fabonPanel4.GradientTopColor = System.Drawing.Color.Black;
            this.fabonPanel4.Location = new System.Drawing.Point(20, 370);
            this.fabonPanel4.Name = "fabonPanel4";
            this.fabonPanel4.Size = new System.Drawing.Size(873, 206);
            this.fabonPanel4.TabIndex = 6;
            // 
            // fabonPanel12
            // 
            this.fabonPanel12.BackColor = System.Drawing.Color.White;
            this.fabonPanel12.BorderRadius = 30;
            this.fabonPanel12.Controls.Add(this.fabonPanel15);
            this.fabonPanel12.Controls.Add(this.fabonPanel14);
            this.fabonPanel12.Controls.Add(this.fabonPanel13);
            this.fabonPanel12.Controls.Add(this.label19);
            this.fabonPanel12.Controls.Add(this.label18);
            this.fabonPanel12.Controls.Add(this.label17);
            this.fabonPanel12.Controls.Add(this.label16);
            this.fabonPanel12.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel12.GradientAngle = 90F;
            this.fabonPanel12.GradientBottomColor = System.Drawing.Color.White;
            this.fabonPanel12.GradientTopColor = System.Drawing.Color.White;
            this.fabonPanel12.Location = new System.Drawing.Point(3, 3);
            this.fabonPanel12.Name = "fabonPanel12";
            this.fabonPanel12.Size = new System.Drawing.Size(867, 200);
            this.fabonPanel12.TabIndex = 5;
            // 
            // fabonPanel15
            // 
            this.fabonPanel15.BackColor = System.Drawing.Color.White;
            this.fabonPanel15.BorderRadius = 30;
            this.fabonPanel15.Controls.Add(this.IDemployee);
            this.fabonPanel15.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel15.GradientAngle = 90F;
            this.fabonPanel15.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel15.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel15.Location = new System.Drawing.Point(562, 124);
            this.fabonPanel15.Name = "fabonPanel15";
            this.fabonPanel15.Size = new System.Drawing.Size(217, 45);
            this.fabonPanel15.TabIndex = 17;
            // 
            // IDemployee
            // 
            this.IDemployee.AutoSize = true;
            this.IDemployee.BackColor = System.Drawing.Color.Transparent;
            this.IDemployee.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IDemployee.ForeColor = System.Drawing.Color.White;
            this.IDemployee.Location = new System.Drawing.Point(98, 12);
            this.IDemployee.Name = "IDemployee";
            this.IDemployee.Size = new System.Drawing.Size(29, 19);
            this.IDemployee.TabIndex = 14;
            this.IDemployee.Text = "24";
            // 
            // fabonPanel14
            // 
            this.fabonPanel14.BackColor = System.Drawing.Color.White;
            this.fabonPanel14.BorderRadius = 30;
            this.fabonPanel14.Controls.Add(this.WorkedForEmployee);
            this.fabonPanel14.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel14.GradientAngle = 90F;
            this.fabonPanel14.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel14.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel14.Location = new System.Drawing.Point(321, 124);
            this.fabonPanel14.Name = "fabonPanel14";
            this.fabonPanel14.Size = new System.Drawing.Size(217, 45);
            this.fabonPanel14.TabIndex = 17;
            // 
            // WorkedForEmployee
            // 
            this.WorkedForEmployee.AutoSize = true;
            this.WorkedForEmployee.BackColor = System.Drawing.Color.Transparent;
            this.WorkedForEmployee.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WorkedForEmployee.ForeColor = System.Drawing.Color.White;
            this.WorkedForEmployee.Location = new System.Drawing.Point(78, 12);
            this.WorkedForEmployee.Name = "WorkedForEmployee";
            this.WorkedForEmployee.Size = new System.Drawing.Size(65, 19);
            this.WorkedForEmployee.TabIndex = 13;
            this.WorkedForEmployee.Text = "2 years";
            // 
            // fabonPanel13
            // 
            this.fabonPanel13.BackColor = System.Drawing.Color.White;
            this.fabonPanel13.BorderRadius = 30;
            this.fabonPanel13.Controls.Add(this.HireDateEmployee);
            this.fabonPanel13.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel13.GradientAngle = 90F;
            this.fabonPanel13.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel13.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel13.Location = new System.Drawing.Point(74, 124);
            this.fabonPanel13.Name = "fabonPanel13";
            this.fabonPanel13.Size = new System.Drawing.Size(217, 45);
            this.fabonPanel13.TabIndex = 16;
            // 
            // HireDateEmployee
            // 
            this.HireDateEmployee.AutoSize = true;
            this.HireDateEmployee.BackColor = System.Drawing.Color.Transparent;
            this.HireDateEmployee.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HireDateEmployee.ForeColor = System.Drawing.Color.White;
            this.HireDateEmployee.Location = new System.Drawing.Point(55, 12);
            this.HireDateEmployee.Name = "HireDateEmployee";
            this.HireDateEmployee.Size = new System.Drawing.Size(103, 19);
            this.HireDateEmployee.TabIndex = 12;
            this.HireDateEmployee.Text = "2024-02-02";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label19.Location = new System.Drawing.Point(617, 91);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(115, 19);
            this.label19.TabIndex = 15;
            this.label19.Text = "Employee ID";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label18.Location = new System.Drawing.Point(370, 91);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(104, 19);
            this.label18.TabIndex = 14;
            this.label18.Text = "Worked for";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label17.Location = new System.Drawing.Point(140, 91);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(89, 19);
            this.label17.TabIndex = 13;
            this.label17.Text = "Hire Date";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Inter Medium", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(326, 15);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(207, 25);
            this.label16.TabIndex = 12;
            this.label16.Text = "Basic Information";
            // 
            // fabonPanel3
            // 
            this.fabonPanel3.BackColor = System.Drawing.Color.White;
            this.fabonPanel3.BorderRadius = 30;
            this.fabonPanel3.Controls.Add(this.fabonPanel11);
            this.fabonPanel3.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel3.GradientAngle = 90F;
            this.fabonPanel3.GradientBottomColor = System.Drawing.Color.Black;
            this.fabonPanel3.GradientTopColor = System.Drawing.Color.Black;
            this.fabonPanel3.Location = new System.Drawing.Point(20, 95);
            this.fabonPanel3.Name = "fabonPanel3";
            this.fabonPanel3.Size = new System.Drawing.Size(873, 243);
            this.fabonPanel3.TabIndex = 5;
            // 
            // fabonPanel11
            // 
            this.fabonPanel11.BackColor = System.Drawing.Color.White;
            this.fabonPanel11.BorderRadius = 30;
            this.fabonPanel11.Controls.Add(this.EmployeeAddress);
            this.fabonPanel11.Controls.Add(this.EmployeeBday);
            this.fabonPanel11.Controls.Add(this.EmployeeEmail);
            this.fabonPanel11.Controls.Add(this.PhoneNumber);
            this.fabonPanel11.Controls.Add(this.EmployeePosition);
            this.fabonPanel11.Controls.Add(this.label15);
            this.fabonPanel11.Controls.Add(this.label14);
            this.fabonPanel11.Controls.Add(this.label13);
            this.fabonPanel11.Controls.Add(this.label12);
            this.fabonPanel11.Controls.Add(this.label11);
            this.fabonPanel11.Controls.Add(this.NameEmployee);
            this.fabonPanel11.Controls.Add(this.pictureBox4);
            this.fabonPanel11.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel11.GradientAngle = 90F;
            this.fabonPanel11.GradientBottomColor = System.Drawing.Color.White;
            this.fabonPanel11.GradientTopColor = System.Drawing.Color.White;
            this.fabonPanel11.Location = new System.Drawing.Point(3, 3);
            this.fabonPanel11.Name = "fabonPanel11";
            this.fabonPanel11.Size = new System.Drawing.Size(867, 238);
            this.fabonPanel11.TabIndex = 4;
            // 
            // EmployeeAddress
            // 
            this.EmployeeAddress.AutoSize = true;
            this.EmployeeAddress.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeAddress.ForeColor = System.Drawing.Color.Black;
            this.EmployeeAddress.Location = new System.Drawing.Point(503, 105);
            this.EmployeeAddress.Name = "EmployeeAddress";
            this.EmployeeAddress.Size = new System.Drawing.Size(55, 15);
            this.EmployeeAddress.TabIndex = 11;
            this.EmployeeAddress.Text = "Position:";
            // 
            // EmployeeBday
            // 
            this.EmployeeBday.AutoSize = true;
            this.EmployeeBday.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeBday.ForeColor = System.Drawing.Color.Black;
            this.EmployeeBday.Location = new System.Drawing.Point(509, 66);
            this.EmployeeBday.Name = "EmployeeBday";
            this.EmployeeBday.Size = new System.Drawing.Size(55, 15);
            this.EmployeeBday.TabIndex = 10;
            this.EmployeeBday.Text = "Position:";
            // 
            // EmployeeEmail
            // 
            this.EmployeeEmail.AutoSize = true;
            this.EmployeeEmail.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeEmail.ForeColor = System.Drawing.Color.Black;
            this.EmployeeEmail.Location = new System.Drawing.Point(240, 145);
            this.EmployeeEmail.Name = "EmployeeEmail";
            this.EmployeeEmail.Size = new System.Drawing.Size(55, 15);
            this.EmployeeEmail.TabIndex = 9;
            this.EmployeeEmail.Text = "Position:";
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.AutoSize = true;
            this.PhoneNumber.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNumber.ForeColor = System.Drawing.Color.Black;
            this.PhoneNumber.Location = new System.Drawing.Point(246, 105);
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.Size = new System.Drawing.Size(55, 15);
            this.PhoneNumber.TabIndex = 8;
            this.PhoneNumber.Text = "Position:";
            // 
            // EmployeePosition
            // 
            this.EmployeePosition.AutoSize = true;
            this.EmployeePosition.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeePosition.ForeColor = System.Drawing.Color.Black;
            this.EmployeePosition.Location = new System.Drawing.Point(255, 66);
            this.EmployeePosition.Name = "EmployeePosition";
            this.EmployeePosition.Size = new System.Drawing.Size(55, 15);
            this.EmployeePosition.TabIndex = 7;
            this.EmployeePosition.Text = "Position:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label15.Location = new System.Drawing.Point(442, 105);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 15);
            this.label15.TabIndex = 6;
            this.label15.Text = "Address:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label14.Location = new System.Drawing.Point(442, 66);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 15);
            this.label14.TabIndex = 5;
            this.label14.Text = "Birthdate:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label13.Location = new System.Drawing.Point(194, 145);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 15);
            this.label13.TabIndex = 4;
            this.label13.Text = "Email:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label12.Location = new System.Drawing.Point(194, 105);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 15);
            this.label12.TabIndex = 3;
            this.label12.Text = "Phone:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label11.Location = new System.Drawing.Point(194, 66);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 15);
            this.label11.TabIndex = 2;
            this.label11.Text = "Position:";
            // 
            // NameEmployee
            // 
            this.NameEmployee.AutoSize = true;
            this.NameEmployee.Font = new System.Drawing.Font("Inter Medium", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameEmployee.Location = new System.Drawing.Point(192, 23);
            this.NameEmployee.Name = "NameEmployee";
            this.NameEmployee.Size = new System.Drawing.Size(134, 25);
            this.NameEmployee.TabIndex = 1;
            this.NameEmployee.Text = "Name Here";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::TimeTrackPay.Properties.Resources.profile_2;
            this.pictureBox4.Location = new System.Drawing.Point(22, 43);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(138, 140);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // ProfileForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(927, 730);
            this.Controls.Add(this.fabonPanel4);
            this.Controls.Add(this.fabonPanel3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ProfileForm";
            this.Text = "ProfileForm";
            this.fabonPanel4.ResumeLayout(false);
            this.fabonPanel12.ResumeLayout(false);
            this.fabonPanel12.PerformLayout();
            this.fabonPanel15.ResumeLayout(false);
            this.fabonPanel15.PerformLayout();
            this.fabonPanel14.ResumeLayout(false);
            this.fabonPanel14.PerformLayout();
            this.fabonPanel13.ResumeLayout(false);
            this.fabonPanel13.PerformLayout();
            this.fabonPanel3.ResumeLayout(false);
            this.fabonPanel11.ResumeLayout(false);
            this.fabonPanel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private roundedRectangle.FabonPanel fabonPanel4;
        private roundedRectangle.FabonPanel fabonPanel12;
        private roundedRectangle.FabonPanel fabonPanel15;
        private System.Windows.Forms.Label IDemployee;
        private roundedRectangle.FabonPanel fabonPanel14;
        private System.Windows.Forms.Label WorkedForEmployee;
        private roundedRectangle.FabonPanel fabonPanel13;
        private System.Windows.Forms.Label HireDateEmployee;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private roundedRectangle.FabonPanel fabonPanel3;
        private roundedRectangle.FabonPanel fabonPanel11;
        private System.Windows.Forms.Label EmployeeAddress;
        private System.Windows.Forms.Label EmployeeBday;
        private System.Windows.Forms.Label EmployeeEmail;
        private System.Windows.Forms.Label PhoneNumber;
        private System.Windows.Forms.Label EmployeePosition;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label NameEmployee;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}