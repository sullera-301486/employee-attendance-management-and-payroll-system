﻿namespace TimeTrackPay
{
    partial class adminAttendanceNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd = new TimeTrackPay.button();
            this.btnCancel = new TimeTrackPay.button();
            this.label5 = new System.Windows.Forms.Label();
            this.EmployeeSalary = new System.Windows.Forms.TextBox();
            this.NewFullName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.NewPosition = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.NewEmployeeid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.fabonPanel1 = new roundedRectangle.FabonPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.NewEmployeeBday = new System.Windows.Forms.TextBox();
            this.NewPhoneNumber = new System.Windows.Forms.TextBox();
            this.NewEmail = new System.Windows.Forms.TextBox();
            this.NewAddress = new System.Windows.Forms.TextBox();
            this.newWorkedfor = new System.Windows.Forms.TextBox();
            this.EmployerPassword = new System.Windows.Forms.TextBox();
            this.NewHireDate = new System.Windows.Forms.TextBox();
            this.N = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.btnAdd.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.btnAdd.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnAdd.BorderRadius = 5;
            this.btnAdd.BorderSize = 0;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(417, 414);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnAdd.Size = new System.Drawing.Size(108, 32);
            this.btnAdd.TabIndex = 38;
            this.btnAdd.Text = "Add";
            this.btnAdd.TextColor = System.Drawing.Color.White;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnCancel.BackgroundColor = System.Drawing.Color.Transparent;
            this.btnCancel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.btnCancel.BorderRadius = 5;
            this.btnCancel.BorderSize = 3;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.btnCancel.Location = new System.Drawing.Point(299, 414);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnCancel.Size = new System.Drawing.Size(108, 32);
            this.btnCancel.TabIndex = 37;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(17, 278);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 20);
            this.label5.TabIndex = 36;
            this.label5.Text = "Employee Salary";
            // 
            // EmployeeSalary
            // 
            this.EmployeeSalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeSalary.Location = new System.Drawing.Point(21, 300);
            this.EmployeeSalary.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.EmployeeSalary.Name = "EmployeeSalary";
            this.EmployeeSalary.Size = new System.Drawing.Size(226, 24);
            this.EmployeeSalary.TabIndex = 35;
            // 
            // NewFullName
            // 
            this.NewFullName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewFullName.Location = new System.Drawing.Point(21, 238);
            this.NewFullName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.NewFullName.Name = "NewFullName";
            this.NewFullName.Size = new System.Drawing.Size(226, 24);
            this.NewFullName.TabIndex = 34;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(18, 216);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 20);
            this.label4.TabIndex = 33;
            this.label4.Text = "FullName";
            // 
            // NewPosition
            // 
            this.NewPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewPosition.Location = new System.Drawing.Point(21, 178);
            this.NewPosition.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.NewPosition.Name = "NewPosition";
            this.NewPosition.Size = new System.Drawing.Size(227, 24);
            this.NewPosition.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(17, 156);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 20);
            this.label3.TabIndex = 30;
            this.label3.Text = "Position";
            // 
            // NewEmployeeid
            // 
            this.NewEmployeeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewEmployeeid.Location = new System.Drawing.Point(21, 120);
            this.NewEmployeeid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.NewEmployeeid.Name = "NewEmployeeid";
            this.NewEmployeeid.Size = new System.Drawing.Size(227, 24);
            this.NewEmployeeid.TabIndex = 29;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(18, 98);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 20);
            this.label2.TabIndex = 28;
            this.label2.Text = "EmployeeID";
            // 
            // fabonPanel1
            // 
            this.fabonPanel1.BackColor = System.Drawing.Color.White;
            this.fabonPanel1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel1.BorderRadius = 15;
            this.fabonPanel1.BorderSize = 0;
            this.fabonPanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel1.GradientAngle = 90F;
            this.fabonPanel1.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel1.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel1.Location = new System.Drawing.Point(8, 64);
            this.fabonPanel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.fabonPanel1.Name = "fabonPanel1";
            this.fabonPanel1.Size = new System.Drawing.Size(542, 8);
            this.fabonPanel1.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.label1.Location = new System.Drawing.Point(16, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 26);
            this.label1.TabIndex = 26;
            this.label1.Text = "New";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TimeTrackPay.Properties.Resources.exitIcon;
            this.pictureBox1.Location = new System.Drawing.Point(580, 11);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(20, 24);
            this.pictureBox1.TabIndex = 32;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // NewEmployeeBday
            // 
            this.NewEmployeeBday.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewEmployeeBday.Location = new System.Drawing.Point(21, 356);
            this.NewEmployeeBday.Margin = new System.Windows.Forms.Padding(2);
            this.NewEmployeeBday.Name = "NewEmployeeBday";
            this.NewEmployeeBday.Size = new System.Drawing.Size(226, 24);
            this.NewEmployeeBday.TabIndex = 39;
            // 
            // NewPhoneNumber
            // 
            this.NewPhoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewPhoneNumber.Location = new System.Drawing.Point(299, 120);
            this.NewPhoneNumber.Margin = new System.Windows.Forms.Padding(2);
            this.NewPhoneNumber.Name = "NewPhoneNumber";
            this.NewPhoneNumber.Size = new System.Drawing.Size(226, 24);
            this.NewPhoneNumber.TabIndex = 40;
            // 
            // NewEmail
            // 
            this.NewEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewEmail.Location = new System.Drawing.Point(299, 178);
            this.NewEmail.Margin = new System.Windows.Forms.Padding(2);
            this.NewEmail.Name = "NewEmail";
            this.NewEmail.Size = new System.Drawing.Size(226, 24);
            this.NewEmail.TabIndex = 41;
            // 
            // NewAddress
            // 
            this.NewAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewAddress.Location = new System.Drawing.Point(299, 238);
            this.NewAddress.Margin = new System.Windows.Forms.Padding(2);
            this.NewAddress.Name = "NewAddress";
            this.NewAddress.Size = new System.Drawing.Size(226, 24);
            this.NewAddress.TabIndex = 42;
            // 
            // newWorkedfor
            // 
            this.newWorkedfor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newWorkedfor.Location = new System.Drawing.Point(299, 300);
            this.newWorkedfor.Margin = new System.Windows.Forms.Padding(2);
            this.newWorkedfor.Name = "newWorkedfor";
            this.newWorkedfor.Size = new System.Drawing.Size(226, 24);
            this.newWorkedfor.TabIndex = 43;
            // 
            // EmployerPassword
            // 
            this.EmployerPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployerPassword.Location = new System.Drawing.Point(299, 356);
            this.EmployerPassword.Margin = new System.Windows.Forms.Padding(2);
            this.EmployerPassword.Name = "EmployerPassword";
            this.EmployerPassword.Size = new System.Drawing.Size(226, 24);
            this.EmployerPassword.TabIndex = 44;
            // 
            // NewHireDate
            // 
            this.NewHireDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewHireDate.Location = new System.Drawing.Point(22, 414);
            this.NewHireDate.Margin = new System.Windows.Forms.Padding(2);
            this.NewHireDate.Name = "NewHireDate";
            this.NewHireDate.Size = new System.Drawing.Size(226, 24);
            this.NewHireDate.TabIndex = 45;
            // 
            // N
            // 
            this.N.AutoSize = true;
            this.N.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N.ForeColor = System.Drawing.Color.Black;
            this.N.Location = new System.Drawing.Point(18, 334);
            this.N.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.N.Name = "N";
            this.N.Size = new System.Drawing.Size(83, 20);
            this.N.TabIndex = 46;
            this.N.Text = "Birthdate";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(17, 392);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 20);
            this.label7.TabIndex = 47;
            this.label7.Text = "Hire Date";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(295, 98);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(127, 20);
            this.label8.TabIndex = 48;
            this.label8.Text = "Phone Number";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(295, 156);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 20);
            this.label9.TabIndex = 49;
            this.label9.Text = "Email";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(295, 216);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 20);
            this.label10.TabIndex = 50;
            this.label10.Text = "Address";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(295, 278);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 20);
            this.label11.TabIndex = 51;
            this.label11.Text = "Worked For";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(295, 334);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(169, 20);
            this.label12.TabIndex = 52;
            this.label12.Text = "Employee Password";
            // 
            // adminAttendanceNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(561, 483);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.N);
            this.Controls.Add(this.NewHireDate);
            this.Controls.Add(this.EmployerPassword);
            this.Controls.Add(this.newWorkedfor);
            this.Controls.Add(this.NewAddress);
            this.Controls.Add(this.NewEmail);
            this.Controls.Add(this.NewPhoneNumber);
            this.Controls.Add(this.NewEmployeeBday);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.EmployeeSalary);
            this.Controls.Add(this.NewFullName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.NewPosition);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.NewEmployeeid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.fabonPanel1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "adminAttendanceNew";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "adminAttendanceNew";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private button btnAdd;
        private button btnCancel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox EmployeeSalary;
        private System.Windows.Forms.TextBox NewFullName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox NewPosition;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox NewEmployeeid;
        private System.Windows.Forms.Label label2;
        private roundedRectangle.FabonPanel fabonPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox NewEmployeeBday;
        private System.Windows.Forms.TextBox NewPhoneNumber;
        private System.Windows.Forms.TextBox NewEmail;
        private System.Windows.Forms.TextBox NewAddress;
        private System.Windows.Forms.TextBox newWorkedfor;
        private System.Windows.Forms.TextBox EmployerPassword;
        private System.Windows.Forms.TextBox NewHireDate;
        private System.Windows.Forms.Label N;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}