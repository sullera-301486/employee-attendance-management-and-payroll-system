﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class DashboardEmployee : Form
    {
        
        public DashboardEmployee()
        {
            InitializeComponent();
        }

        private void DashboardEmployee_Load(object sender, EventArgs e)
        {
            loadform(new EmployeeDashboardForm());
        }

        private void button_Click(object sender, EventArgs e)
        {
            //None

        }

        private void btnAttendance_Click(object sender, EventArgs e)
        {
            btnAttendance.BackColor = Color.FromArgb(82, 85, 76);
            btnPayroll.BackColor = Color.FromArgb(34, 100, 102);
            btnProfile.BackColor = Color.FromArgb(34, 100, 102);
            btnDashboard.BackColor = Color.FromArgb(34, 100, 102);
            btnLeave.BackColor = Color.FromArgb(34, 100, 102);
            loadform(new AttendanceForm());
        }
        private void btnLeave_Click(object sender, EventArgs e)
        {
            btnLeave.BackColor = Color.FromArgb(82, 85, 76);
            btnPayroll.BackColor = Color.FromArgb(34, 100, 102);
            btnProfile.BackColor = Color.FromArgb(34, 100, 102);
            btnDashboard.BackColor = Color.FromArgb(34, 100, 102);
            btnAttendance.BackColor = Color.FromArgb(34, 100, 102);
            LeaveMessageForm L = new LeaveMessageForm();
            L.Show();
        }
        private void btnPayroll_Click(object sender, EventArgs e)
        {
            btnPayroll.BackColor = Color.FromArgb(82, 85, 76);
            btnAttendance.BackColor = Color.FromArgb(34, 100, 102);
            btnProfile.BackColor = Color.FromArgb(34, 100, 102);
            btnDashboard.BackColor = Color.FromArgb(34, 100, 102);
            btnLeave.BackColor = Color.FromArgb(34, 100, 102);
            loadform(new PayrollForm());
        }
        private void btnProfile_Click(object sender, EventArgs e)
        {
            btnProfile.BackColor = Color.FromArgb(82, 85, 76);
            btnPayroll.BackColor = Color.FromArgb(34, 100, 102);
            btnAttendance.BackColor = Color.FromArgb(34, 100, 102);
            btnDashboard.BackColor = Color.FromArgb(34, 100, 102);
            btnLeave.BackColor = Color.FromArgb(34, 100, 102);
            loadform(new ProfileForm());
        }
        private void btnDashboard_Click(object sender, EventArgs e)
        {
            btnDashboard.BackColor = Color.FromArgb(82, 85, 76);
            btnPayroll.BackColor = Color.FromArgb(34, 100, 102);
            btnProfile.BackColor = Color.FromArgb(34, 100, 102);
            btnAttendance.BackColor = Color.FromArgb(34, 100, 102);
            btnLeave.BackColor = Color.FromArgb(34, 100, 102);
            loadform(new EmployeeDashboardForm());
        }

        public void loadform(object Form)
        {
            if (this.MainPanel.Controls.Count > 0)
                this.MainPanel.Controls.RemoveAt(0);
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.MainPanel.Controls.Add(f);
            this.MainPanel.Tag = f;
            f.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
