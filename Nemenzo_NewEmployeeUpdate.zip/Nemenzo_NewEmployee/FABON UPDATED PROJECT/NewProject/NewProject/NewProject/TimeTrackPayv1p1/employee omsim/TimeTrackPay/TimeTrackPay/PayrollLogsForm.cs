﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class PayrollLogsForm : Form
    {
        public PayrollLogsForm()
        {
            InitializeComponent();
            PayrollView();
        }

        public void PayrollView()
        {
            List<PayrollLogsData> pay = new List<PayrollLogsData>();
            pay.Add(new PayrollLogsData("1015", "Franz Louies Deloritos", "4:10 PM", "8:10", "4:10 PM", "4:10 PM"));
            pay.Add(new PayrollLogsData("1016", "Neil Nemenzo", "4:10 PM", "8:10", "4:10 PM", "4:10 PM"));
            pay.Add(new PayrollLogsData("1017", "Charles Macaraig", "4:10 PM", "8:10", "4:10 PM", "4:10 PM"));
            pay.Add(new PayrollLogsData("1018", "Ej Sullera", "4:10 PM", "8:10", "4:10 PM", "4:10 PM"));
            pay.Add(new PayrollLogsData("1019", "Marcus Verzo", "4:10 PM", "8:10", "4:10 PM", "4:10 PM"));
            pay.Add(new PayrollLogsData("1020", "Amer Magangcong", "4:10 PM", "8:10", "4:10 PM", "4:10 PM"));


            foreach (PayrollLogsData d in pay)
            {
                int rowIndex = dataGridView1.Rows.Add();
                DataGridViewRow row = dataGridView1.Rows[rowIndex];
                row.Cells[0].Value = d.EmployeeID;
                row.Cells[1].Value = d.Employee;
                row.Cells[2].Value = d.PaymentData;
                row.Cells[3].Value = d.StartingDate;
                row.Cells[4].Value = d.TotalHours1;
                row.Cells[5].Value = d.GrossPay;
            }
        }

        private void PayrollLogsForm_Load(object sender, EventArgs e)
        {
            AdjustDataGridHeight();
        }
        private void AdjustDataGridHeight()
        {
            var height = dataGridView1.ColumnHeadersHeight;
            foreach (DataGridViewRow dr in dataGridView1.Rows)
            {
                height += dr.Height;
            }
            dataGridView1.Height = height;
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Ensure a valid row is selected
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                // Create an instance of the detail form
                ViewPayrollForm detailForm = new ViewPayrollForm();

                // Pass the data to the detail form
                detailForm.SetData(selectedRow.Cells[0].Value.ToString(),
                    selectedRow.Cells[1].Value.ToString());

                // Show the detail form
                detailForm.ShowDialog();
            }
        }
    }
}
