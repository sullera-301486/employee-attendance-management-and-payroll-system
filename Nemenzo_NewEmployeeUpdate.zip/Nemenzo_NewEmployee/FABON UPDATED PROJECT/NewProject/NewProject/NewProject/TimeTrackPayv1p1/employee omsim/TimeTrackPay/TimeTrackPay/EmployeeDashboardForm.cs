﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class EmployeeDashboardForm : Form
    {
        public EmployeeDashboardForm()
        {
            InitializeComponent();
        }
        public void loadform(Form form)
        {
            foreach (Control control in this.EmployeeDashboard.Controls.OfType<Control>().ToList())
            {
                this.EmployeeDashboard.Controls.Remove(control);
                control.Dispose();
            }

            form.TopLevel = false;
            form.Dock = DockStyle.Fill;
            this.EmployeeDashboard.Controls.Add(form);
            this.EmployeeDashboard.Tag = form;

            form.Show();
        }
        private void btnMoreInfoEmployeePay_Click(object sender, EventArgs e)
        {
            loadform(new PayrollForm());
        }

        private void btnMoreInfoEmployeeAtt_Click(object sender, EventArgs e)
        {
            loadform(new AttendanceForm());
        }
    }
}
