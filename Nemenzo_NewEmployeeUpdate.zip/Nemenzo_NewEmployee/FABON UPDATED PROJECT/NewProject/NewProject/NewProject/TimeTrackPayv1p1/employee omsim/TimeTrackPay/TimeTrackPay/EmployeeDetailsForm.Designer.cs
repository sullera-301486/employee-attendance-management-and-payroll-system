﻿namespace TimeTrackPay
{
    partial class EmployeeDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fabonPanel3 = new roundedRectangle.FabonPanel();
            this.fabonPanel11 = new roundedRectangle.FabonPanel();
            this.EmployeeAddress = new System.Windows.Forms.Label();
            this.EmployeeBday = new System.Windows.Forms.Label();
            this.EmployeeEmail = new System.Windows.Forms.Label();
            this.PhoneNumber = new System.Windows.Forms.Label();
            this.EmployeePosition = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.NameEmployee = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.fabonPanel4 = new roundedRectangle.FabonPanel();
            this.fabonPanel12 = new roundedRectangle.FabonPanel();
            this.fabonPanel15 = new roundedRectangle.FabonPanel();
            this.IDemployee = new System.Windows.Forms.Label();
            this.fabonPanel14 = new roundedRectangle.FabonPanel();
            this.WorkedForEmployee = new System.Windows.Forms.Label();
            this.fabonPanel13 = new roundedRectangle.FabonPanel();
            this.HireDateEmployee = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.fabonPanel1 = new roundedRectangle.FabonPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.fabonPanel5 = new roundedRectangle.FabonPanel();
            this.address = new System.Windows.Forms.Label();
            this.birthdate = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.phone = new System.Windows.Forms.Label();
            this.position = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.UserProfileAdmin = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.fabonPanel6 = new roundedRectangle.FabonPanel();
            this.fabonPanel9 = new roundedRectangle.FabonPanel();
            this.fabonPanel8 = new roundedRectangle.FabonPanel();
            this.workedFor = new System.Windows.Forms.Label();
            this.fabonPanel7 = new roundedRectangle.FabonPanel();
            this.HireDate = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.fabonPanel3.SuspendLayout();
            this.fabonPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.fabonPanel4.SuspendLayout();
            this.fabonPanel12.SuspendLayout();
            this.fabonPanel15.SuspendLayout();
            this.fabonPanel14.SuspendLayout();
            this.fabonPanel13.SuspendLayout();
            this.fabonPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.fabonPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.fabonPanel6.SuspendLayout();
            this.fabonPanel8.SuspendLayout();
            this.fabonPanel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // fabonPanel3
            // 
            this.fabonPanel3.BackColor = System.Drawing.Color.White;
            this.fabonPanel3.BorderRadius = 30;
            this.fabonPanel3.Controls.Add(this.fabonPanel11);
            this.fabonPanel3.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel3.GradientAngle = 90F;
            this.fabonPanel3.GradientBottomColor = System.Drawing.Color.Black;
            this.fabonPanel3.GradientTopColor = System.Drawing.Color.Black;
            this.fabonPanel3.Location = new System.Drawing.Point(20, 64);
            this.fabonPanel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.fabonPanel3.Name = "fabonPanel3";
            this.fabonPanel3.Size = new System.Drawing.Size(1016, 299);
            this.fabonPanel3.TabIndex = 3;
            // 
            // fabonPanel11
            // 
            this.fabonPanel11.BackColor = System.Drawing.Color.White;
            this.fabonPanel11.BorderRadius = 30;
            this.fabonPanel11.Controls.Add(this.EmployeeAddress);
            this.fabonPanel11.Controls.Add(this.EmployeeBday);
            this.fabonPanel11.Controls.Add(this.EmployeeEmail);
            this.fabonPanel11.Controls.Add(this.PhoneNumber);
            this.fabonPanel11.Controls.Add(this.EmployeePosition);
            this.fabonPanel11.Controls.Add(this.label15);
            this.fabonPanel11.Controls.Add(this.label14);
            this.fabonPanel11.Controls.Add(this.label13);
            this.fabonPanel11.Controls.Add(this.label12);
            this.fabonPanel11.Controls.Add(this.label11);
            this.fabonPanel11.Controls.Add(this.NameEmployee);
            this.fabonPanel11.Controls.Add(this.pictureBox4);
            this.fabonPanel11.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel11.GradientAngle = 90F;
            this.fabonPanel11.GradientBottomColor = System.Drawing.Color.White;
            this.fabonPanel11.GradientTopColor = System.Drawing.Color.White;
            this.fabonPanel11.Location = new System.Drawing.Point(4, 4);
            this.fabonPanel11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.fabonPanel11.Name = "fabonPanel11";
            this.fabonPanel11.Size = new System.Drawing.Size(1007, 293);
            this.fabonPanel11.TabIndex = 4;
            // 
            // EmployeeAddress
            // 
            this.EmployeeAddress.AutoSize = true;
            this.EmployeeAddress.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeAddress.ForeColor = System.Drawing.Color.Black;
            this.EmployeeAddress.Location = new System.Drawing.Point(671, 129);
            this.EmployeeAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EmployeeAddress.Name = "EmployeeAddress";
            this.EmployeeAddress.Size = new System.Drawing.Size(55, 15);
            this.EmployeeAddress.TabIndex = 11;
            this.EmployeeAddress.Text = "Position:";
            // 
            // EmployeeBday
            // 
            this.EmployeeBday.AutoSize = true;
            this.EmployeeBday.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeBday.ForeColor = System.Drawing.Color.Black;
            this.EmployeeBday.Location = new System.Drawing.Point(679, 81);
            this.EmployeeBday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EmployeeBday.Name = "EmployeeBday";
            this.EmployeeBday.Size = new System.Drawing.Size(55, 15);
            this.EmployeeBday.TabIndex = 10;
            this.EmployeeBday.Text = "Position:";
            // 
            // EmployeeEmail
            // 
            this.EmployeeEmail.AutoSize = true;
            this.EmployeeEmail.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeEmail.ForeColor = System.Drawing.Color.Black;
            this.EmployeeEmail.Location = new System.Drawing.Point(320, 178);
            this.EmployeeEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EmployeeEmail.Name = "EmployeeEmail";
            this.EmployeeEmail.Size = new System.Drawing.Size(55, 15);
            this.EmployeeEmail.TabIndex = 9;
            this.EmployeeEmail.Text = "Position:";
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.AutoSize = true;
            this.PhoneNumber.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNumber.ForeColor = System.Drawing.Color.Black;
            this.PhoneNumber.Location = new System.Drawing.Point(328, 129);
            this.PhoneNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.Size = new System.Drawing.Size(55, 15);
            this.PhoneNumber.TabIndex = 8;
            this.PhoneNumber.Text = "Position:";
            // 
            // EmployeePosition
            // 
            this.EmployeePosition.AutoSize = true;
            this.EmployeePosition.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeePosition.ForeColor = System.Drawing.Color.Black;
            this.EmployeePosition.Location = new System.Drawing.Point(340, 81);
            this.EmployeePosition.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EmployeePosition.Name = "EmployeePosition";
            this.EmployeePosition.Size = new System.Drawing.Size(55, 15);
            this.EmployeePosition.TabIndex = 7;
            this.EmployeePosition.Text = "Position:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label15.Location = new System.Drawing.Point(589, 129);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 15);
            this.label15.TabIndex = 6;
            this.label15.Text = "Address:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label14.Location = new System.Drawing.Point(589, 81);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 15);
            this.label14.TabIndex = 5;
            this.label14.Text = "Birthdate:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label13.Location = new System.Drawing.Point(259, 178);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 15);
            this.label13.TabIndex = 4;
            this.label13.Text = "Email:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label12.Location = new System.Drawing.Point(259, 129);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 15);
            this.label12.TabIndex = 3;
            this.label12.Text = "Phone:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label11.Location = new System.Drawing.Point(259, 81);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 15);
            this.label11.TabIndex = 2;
            this.label11.Text = "Position:";
            // 
            // NameEmployee
            // 
            this.NameEmployee.AutoSize = true;
            this.NameEmployee.Font = new System.Drawing.Font("Inter Medium", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameEmployee.Location = new System.Drawing.Point(256, 28);
            this.NameEmployee.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.NameEmployee.Name = "NameEmployee";
            this.NameEmployee.Size = new System.Drawing.Size(134, 25);
            this.NameEmployee.TabIndex = 1;
            this.NameEmployee.Text = "Name Here";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::TimeTrackPay.Properties.Resources.profile_2;
            this.pictureBox4.Location = new System.Drawing.Point(29, 53);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(184, 172);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Inter", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(36, 17);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Profile Details";
            // 
            // fabonPanel4
            // 
            this.fabonPanel4.BackColor = System.Drawing.Color.White;
            this.fabonPanel4.BorderRadius = 30;
            this.fabonPanel4.Controls.Add(this.fabonPanel12);
            this.fabonPanel4.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel4.GradientAngle = 90F;
            this.fabonPanel4.GradientBottomColor = System.Drawing.Color.Black;
            this.fabonPanel4.GradientTopColor = System.Drawing.Color.Black;
            this.fabonPanel4.Location = new System.Drawing.Point(20, 402);
            this.fabonPanel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.fabonPanel4.Name = "fabonPanel4";
            this.fabonPanel4.Size = new System.Drawing.Size(1016, 254);
            this.fabonPanel4.TabIndex = 4;
            this.fabonPanel4.Paint += new System.Windows.Forms.PaintEventHandler(this.fabonPanel4_Paint);
            // 
            // fabonPanel12
            // 
            this.fabonPanel12.BackColor = System.Drawing.Color.White;
            this.fabonPanel12.BorderRadius = 30;
            this.fabonPanel12.Controls.Add(this.fabonPanel15);
            this.fabonPanel12.Controls.Add(this.fabonPanel14);
            this.fabonPanel12.Controls.Add(this.fabonPanel13);
            this.fabonPanel12.Controls.Add(this.label19);
            this.fabonPanel12.Controls.Add(this.label18);
            this.fabonPanel12.Controls.Add(this.label17);
            this.fabonPanel12.Controls.Add(this.label16);
            this.fabonPanel12.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel12.GradientAngle = 90F;
            this.fabonPanel12.GradientBottomColor = System.Drawing.Color.White;
            this.fabonPanel12.GradientTopColor = System.Drawing.Color.White;
            this.fabonPanel12.Location = new System.Drawing.Point(4, 4);
            this.fabonPanel12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.fabonPanel12.Name = "fabonPanel12";
            this.fabonPanel12.Size = new System.Drawing.Size(1007, 246);
            this.fabonPanel12.TabIndex = 5;
            // 
            // fabonPanel15
            // 
            this.fabonPanel15.BackColor = System.Drawing.Color.White;
            this.fabonPanel15.BorderRadius = 30;
            this.fabonPanel15.Controls.Add(this.IDemployee);
            this.fabonPanel15.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel15.GradientAngle = 90F;
            this.fabonPanel15.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel15.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel15.Location = new System.Drawing.Point(669, 150);
            this.fabonPanel15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.fabonPanel15.Name = "fabonPanel15";
            this.fabonPanel15.Size = new System.Drawing.Size(289, 55);
            this.fabonPanel15.TabIndex = 17;
            this.fabonPanel15.Paint += new System.Windows.Forms.PaintEventHandler(this.fabonPanel15_Paint);
            // 
            // IDemployee
            // 
            this.IDemployee.AutoSize = true;
            this.IDemployee.BackColor = System.Drawing.Color.Transparent;
            this.IDemployee.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IDemployee.ForeColor = System.Drawing.Color.White;
            this.IDemployee.Location = new System.Drawing.Point(131, 15);
            this.IDemployee.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.IDemployee.Name = "IDemployee";
            this.IDemployee.Size = new System.Drawing.Size(29, 19);
            this.IDemployee.TabIndex = 14;
            this.IDemployee.Text = "24";
            // 
            // fabonPanel14
            // 
            this.fabonPanel14.BackColor = System.Drawing.Color.White;
            this.fabonPanel14.BorderRadius = 30;
            this.fabonPanel14.Controls.Add(this.WorkedForEmployee);
            this.fabonPanel14.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel14.GradientAngle = 90F;
            this.fabonPanel14.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel14.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel14.Location = new System.Drawing.Point(359, 150);
            this.fabonPanel14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.fabonPanel14.Name = "fabonPanel14";
            this.fabonPanel14.Size = new System.Drawing.Size(289, 55);
            this.fabonPanel14.TabIndex = 17;
            // 
            // WorkedForEmployee
            // 
            this.WorkedForEmployee.AutoSize = true;
            this.WorkedForEmployee.BackColor = System.Drawing.Color.Transparent;
            this.WorkedForEmployee.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WorkedForEmployee.ForeColor = System.Drawing.Color.White;
            this.WorkedForEmployee.Location = new System.Drawing.Point(104, 15);
            this.WorkedForEmployee.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.WorkedForEmployee.Name = "WorkedForEmployee";
            this.WorkedForEmployee.Size = new System.Drawing.Size(65, 19);
            this.WorkedForEmployee.TabIndex = 13;
            this.WorkedForEmployee.Text = "2 years";
            this.WorkedForEmployee.Click += new System.EventHandler(this.WorkedForEmployee_Click);
            // 
            // fabonPanel13
            // 
            this.fabonPanel13.BackColor = System.Drawing.Color.White;
            this.fabonPanel13.BorderRadius = 30;
            this.fabonPanel13.Controls.Add(this.HireDateEmployee);
            this.fabonPanel13.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel13.GradientAngle = 90F;
            this.fabonPanel13.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel13.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel13.Location = new System.Drawing.Point(29, 150);
            this.fabonPanel13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.fabonPanel13.Name = "fabonPanel13";
            this.fabonPanel13.Size = new System.Drawing.Size(289, 55);
            this.fabonPanel13.TabIndex = 16;
            // 
            // HireDateEmployee
            // 
            this.HireDateEmployee.AutoSize = true;
            this.HireDateEmployee.BackColor = System.Drawing.Color.Transparent;
            this.HireDateEmployee.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HireDateEmployee.ForeColor = System.Drawing.Color.White;
            this.HireDateEmployee.Location = new System.Drawing.Point(73, 15);
            this.HireDateEmployee.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.HireDateEmployee.Name = "HireDateEmployee";
            this.HireDateEmployee.Size = new System.Drawing.Size(103, 19);
            this.HireDateEmployee.TabIndex = 12;
            this.HireDateEmployee.Text = "2024-02-02";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label19.Location = new System.Drawing.Point(743, 110);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(115, 19);
            this.label19.TabIndex = 15;
            this.label19.Text = "Employee ID";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label18.Location = new System.Drawing.Point(424, 110);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(104, 19);
            this.label18.TabIndex = 14;
            this.label18.Text = "Worked for";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Inter Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label17.Location = new System.Drawing.Point(117, 110);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(89, 19);
            this.label17.TabIndex = 13;
            this.label17.Text = "Hire Date";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Inter Medium", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(340, 23);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(207, 25);
            this.label16.TabIndex = 12;
            this.label16.Text = "Basic Information";
            // 
            // fabonPanel1
            // 
            this.fabonPanel1.BackColor = System.Drawing.Color.White;
            this.fabonPanel1.BorderRadius = 30;
            this.fabonPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fabonPanel1.Controls.Add(this.pictureBox1);
            this.fabonPanel1.Controls.Add(this.textBox1);
            this.fabonPanel1.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel1.GradientAngle = 90F;
            this.fabonPanel1.GradientBottomColor = System.Drawing.Color.White;
            this.fabonPanel1.GradientTopColor = System.Drawing.Color.White;
            this.fabonPanel1.Location = new System.Drawing.Point(2, 2);
            this.fabonPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.fabonPanel1.Name = "fabonPanel1";
            this.fabonPanel1.Size = new System.Drawing.Size(396, 41);
            this.fabonPanel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::TimeTrackPay.Properties.Resources.searchLogo;
            this.pictureBox1.Location = new System.Drawing.Point(358, 5);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(28, 30);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Inter", 14F);
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(125)))), ((int)(((byte)(125)))));
            this.textBox1.Location = new System.Drawing.Point(13, 8);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(339, 23);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "search employee";
            // 
            // fabonPanel5
            // 
            this.fabonPanel5.BackColor = System.Drawing.Color.White;
            this.fabonPanel5.BorderRadius = 30;
            this.fabonPanel5.Controls.Add(this.address);
            this.fabonPanel5.Controls.Add(this.birthdate);
            this.fabonPanel5.Controls.Add(this.email);
            this.fabonPanel5.Controls.Add(this.phone);
            this.fabonPanel5.Controls.Add(this.position);
            this.fabonPanel5.Controls.Add(this.label6);
            this.fabonPanel5.Controls.Add(this.label5);
            this.fabonPanel5.Controls.Add(this.label4);
            this.fabonPanel5.Controls.Add(this.label3);
            this.fabonPanel5.Controls.Add(this.label2);
            this.fabonPanel5.Controls.Add(this.UserProfileAdmin);
            this.fabonPanel5.Controls.Add(this.pictureBox2);
            this.fabonPanel5.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel5.GradientAngle = 90F;
            this.fabonPanel5.GradientBottomColor = System.Drawing.Color.White;
            this.fabonPanel5.GradientTopColor = System.Drawing.Color.White;
            this.fabonPanel5.Location = new System.Drawing.Point(3, 3);
            this.fabonPanel5.Name = "fabonPanel5";
            this.fabonPanel5.Size = new System.Drawing.Size(860, 238);
            this.fabonPanel5.TabIndex = 4;
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address.ForeColor = System.Drawing.Color.Black;
            this.address.Location = new System.Drawing.Point(679, 123);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(71, 19);
            this.address.TabIndex = 11;
            this.address.Text = "Position:";
            // 
            // birthdate
            // 
            this.birthdate.AutoSize = true;
            this.birthdate.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.birthdate.ForeColor = System.Drawing.Color.Black;
            this.birthdate.Location = new System.Drawing.Point(686, 81);
            this.birthdate.Name = "birthdate";
            this.birthdate.Size = new System.Drawing.Size(71, 19);
            this.birthdate.TabIndex = 10;
            this.birthdate.Text = "Position:";
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.Color.Black;
            this.email.Location = new System.Drawing.Point(355, 164);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(71, 19);
            this.email.TabIndex = 9;
            this.email.Text = "Position:";
            // 
            // phone
            // 
            this.phone.AutoSize = true;
            this.phone.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phone.ForeColor = System.Drawing.Color.Black;
            this.phone.Location = new System.Drawing.Point(363, 123);
            this.phone.Name = "phone";
            this.phone.Size = new System.Drawing.Size(71, 19);
            this.phone.TabIndex = 8;
            this.phone.Text = "Position:";
            // 
            // position
            // 
            this.position.AutoSize = true;
            this.position.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.position.ForeColor = System.Drawing.Color.Black;
            this.position.Location = new System.Drawing.Point(375, 81);
            this.position.Name = "position";
            this.position.Size = new System.Drawing.Size(71, 19);
            this.position.TabIndex = 7;
            this.position.Text = "Position:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label6.Location = new System.Drawing.Point(601, 123);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 19);
            this.label6.TabIndex = 6;
            this.label6.Text = "Address:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label5.Location = new System.Drawing.Point(601, 81);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 19);
            this.label5.TabIndex = 5;
            this.label5.Text = "Birthdate:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label4.Location = new System.Drawing.Point(298, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 19);
            this.label4.TabIndex = 4;
            this.label4.Text = "Email:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label3.Location = new System.Drawing.Point(298, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 19);
            this.label3.TabIndex = 3;
            this.label3.Text = "Phone:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label2.Location = new System.Drawing.Point(298, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Position:";
            // 
            // UserProfileAdmin
            // 
            this.UserProfileAdmin.AutoSize = true;
            this.UserProfileAdmin.Font = new System.Drawing.Font("Inter Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserProfileAdmin.Location = new System.Drawing.Point(298, 31);
            this.UserProfileAdmin.Name = "UserProfileAdmin";
            this.UserProfileAdmin.Size = new System.Drawing.Size(120, 23);
            this.UserProfileAdmin.TabIndex = 1;
            this.UserProfileAdmin.Text = "Name Here";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::TimeTrackPay.Properties.Resources.UserProfileLogo;
            this.pictureBox2.Location = new System.Drawing.Point(47, 31);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(182, 172);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // fabonPanel6
            // 
            this.fabonPanel6.BackColor = System.Drawing.Color.White;
            this.fabonPanel6.BorderRadius = 30;
            this.fabonPanel6.Controls.Add(this.fabonPanel9);
            this.fabonPanel6.Controls.Add(this.fabonPanel8);
            this.fabonPanel6.Controls.Add(this.fabonPanel7);
            this.fabonPanel6.Controls.Add(this.label10);
            this.fabonPanel6.Controls.Add(this.label9);
            this.fabonPanel6.Controls.Add(this.label8);
            this.fabonPanel6.Controls.Add(this.label7);
            this.fabonPanel6.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel6.GradientAngle = 90F;
            this.fabonPanel6.GradientBottomColor = System.Drawing.Color.White;
            this.fabonPanel6.GradientTopColor = System.Drawing.Color.White;
            this.fabonPanel6.Location = new System.Drawing.Point(3, 3);
            this.fabonPanel6.Name = "fabonPanel6";
            this.fabonPanel6.Size = new System.Drawing.Size(860, 238);
            this.fabonPanel6.TabIndex = 5;
            // 
            // fabonPanel9
            // 
            this.fabonPanel9.BackColor = System.Drawing.Color.White;
            this.fabonPanel9.BorderRadius = 30;
            this.fabonPanel9.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel9.GradientAngle = 90F;
            this.fabonPanel9.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel9.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel9.Location = new System.Drawing.Point(605, 134);
            this.fabonPanel9.Name = "fabonPanel9";
            this.fabonPanel9.Size = new System.Drawing.Size(219, 36);
            this.fabonPanel9.TabIndex = 16;
            // 
            // fabonPanel8
            // 
            this.fabonPanel8.BackColor = System.Drawing.Color.White;
            this.fabonPanel8.BorderRadius = 30;
            this.fabonPanel8.Controls.Add(this.workedFor);
            this.fabonPanel8.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel8.GradientAngle = 90F;
            this.fabonPanel8.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel8.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel8.Location = new System.Drawing.Point(331, 134);
            this.fabonPanel8.Name = "fabonPanel8";
            this.fabonPanel8.Size = new System.Drawing.Size(219, 36);
            this.fabonPanel8.TabIndex = 16;
            // 
            // workedFor
            // 
            this.workedFor.AutoSize = true;
            this.workedFor.BackColor = System.Drawing.Color.Transparent;
            this.workedFor.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.workedFor.ForeColor = System.Drawing.Color.White;
            this.workedFor.Location = new System.Drawing.Point(57, 8);
            this.workedFor.Name = "workedFor";
            this.workedFor.Size = new System.Drawing.Size(51, 19);
            this.workedFor.TabIndex = 13;
            this.workedFor.Text = "Email:";
            // 
            // fabonPanel7
            // 
            this.fabonPanel7.BackColor = System.Drawing.Color.White;
            this.fabonPanel7.BorderRadius = 30;
            this.fabonPanel7.Controls.Add(this.HireDate);
            this.fabonPanel7.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel7.GradientAngle = 90F;
            this.fabonPanel7.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel7.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.fabonPanel7.Location = new System.Drawing.Point(58, 134);
            this.fabonPanel7.Name = "fabonPanel7";
            this.fabonPanel7.Size = new System.Drawing.Size(219, 36);
            this.fabonPanel7.TabIndex = 15;
            // 
            // HireDate
            // 
            this.HireDate.AutoSize = true;
            this.HireDate.BackColor = System.Drawing.Color.Transparent;
            this.HireDate.Font = new System.Drawing.Font("Inter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HireDate.ForeColor = System.Drawing.Color.White;
            this.HireDate.Location = new System.Drawing.Point(51, 8);
            this.HireDate.Name = "HireDate";
            this.HireDate.Size = new System.Drawing.Size(51, 19);
            this.HireDate.TabIndex = 12;
            this.HireDate.Text = "Email:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Inter", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(646, 91);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(123, 23);
            this.label10.TabIndex = 14;
            this.label10.Text = "Employee ID";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Inter", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(388, 91);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 23);
            this.label9.TabIndex = 13;
            this.label9.Text = "Worked for";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Inter", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(109, 91);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 23);
            this.label8.TabIndex = 12;
            this.label8.Text = "Hire Date";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Inter", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(325, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(247, 33);
            this.label7.TabIndex = 12;
            this.label7.Text = "Basic Information";
            // 
            // EmployeeDetailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(1071, 683);
            this.Controls.Add(this.fabonPanel4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.fabonPanel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "EmployeeDetailsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Profile Details";
            this.Load += new System.EventHandler(this.EmployeeDetailsForm_Load);
            this.fabonPanel3.ResumeLayout(false);
            this.fabonPanel11.ResumeLayout(false);
            this.fabonPanel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.fabonPanel4.ResumeLayout(false);
            this.fabonPanel12.ResumeLayout(false);
            this.fabonPanel12.PerformLayout();
            this.fabonPanel15.ResumeLayout(false);
            this.fabonPanel15.PerformLayout();
            this.fabonPanel14.ResumeLayout(false);
            this.fabonPanel14.PerformLayout();
            this.fabonPanel13.ResumeLayout(false);
            this.fabonPanel13.PerformLayout();
            this.fabonPanel1.ResumeLayout(false);
            this.fabonPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.fabonPanel5.ResumeLayout(false);
            this.fabonPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.fabonPanel6.ResumeLayout(false);
            this.fabonPanel6.PerformLayout();
            this.fabonPanel8.ResumeLayout(false);
            this.fabonPanel8.PerformLayout();
            this.fabonPanel7.ResumeLayout(false);
            this.fabonPanel7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private roundedRectangle.FabonPanel fabonPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox1;
        private roundedRectangle.FabonPanel fabonPanel3;
        private System.Windows.Forms.Label label1;
        private roundedRectangle.FabonPanel fabonPanel4;
        private roundedRectangle.FabonPanel fabonPanel5;
        private roundedRectangle.FabonPanel fabonPanel6;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label UserProfileAdmin;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.Label birthdate;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label phone;
        private System.Windows.Forms.Label position;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private roundedRectangle.FabonPanel fabonPanel9;
        private roundedRectangle.FabonPanel fabonPanel8;
        private roundedRectangle.FabonPanel fabonPanel7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label EmployeeID;
        private System.Windows.Forms.Label workedFor;
        private System.Windows.Forms.Label HireDate;
        private roundedRectangle.FabonPanel fabonPanel11;
        private roundedRectangle.FabonPanel fabonPanel12;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label NameEmployee;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label EmployeeAddress;
        private System.Windows.Forms.Label EmployeeBday;
        private System.Windows.Forms.Label EmployeeEmail;
        private System.Windows.Forms.Label PhoneNumber;
        private System.Windows.Forms.Label EmployeePosition;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private roundedRectangle.FabonPanel fabonPanel13;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private roundedRectangle.FabonPanel fabonPanel15;
        private System.Windows.Forms.Label IDemployee;
        private roundedRectangle.FabonPanel fabonPanel14;
        private System.Windows.Forms.Label WorkedForEmployee;
        private System.Windows.Forms.Label HireDateEmployee;
    }
}