﻿namespace TimeTrackPay
{
    partial class AttendanceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnRequestLeave = new roundedRectangle.FabonPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dbEmployeeDataSet3 = new TimeTrackPay.dbEmployeeDataSet3();
            this.attendanceEmployeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.attendanceEmployeeTableAdapter = new TimeTrackPay.dbEmployeeDataSet3TableAdapters.AttendanceEmployeeTableAdapter();
            this.attendanceIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timeINDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timeOutDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalHoursDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isLateDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.totalDaysDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.onTimeDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.btnRequestLeave.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbEmployeeDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceEmployeeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Attendance";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.label6.Location = new System.Drawing.Point(15, 48);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(353, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "Access Your Comprehensive Attendance History";
            // 
            // btnRequestLeave
            // 
            this.btnRequestLeave.BackColor = System.Drawing.Color.White;
            this.btnRequestLeave.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnRequestLeave.BorderRadius = 50;
            this.btnRequestLeave.BorderSize = 0;
            this.btnRequestLeave.Controls.Add(this.label2);
            this.btnRequestLeave.ForeColor = System.Drawing.Color.Black;
            this.btnRequestLeave.GradientAngle = 90F;
            this.btnRequestLeave.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.btnRequestLeave.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(192)))));
            this.btnRequestLeave.Location = new System.Drawing.Point(673, 39);
            this.btnRequestLeave.Name = "btnRequestLeave";
            this.btnRequestLeave.Size = new System.Drawing.Size(218, 40);
            this.btnRequestLeave.TabIndex = 9;
            this.btnRequestLeave.Paint += new System.Windows.Forms.PaintEventHandler(this.btnRequestLeave_Paint);
            this.btnRequestLeave.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnRequestLeave_MouseClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(40, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "Request Leave";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.attendanceIDDataGridViewTextBoxColumn,
            this.employeeIDDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn,
            this.timeINDataGridViewTextBoxColumn,
            this.timeOutDataGridViewTextBoxColumn,
            this.totalHoursDataGridViewTextBoxColumn,
            this.isLateDataGridViewCheckBoxColumn,
            this.totalDaysDataGridViewTextBoxColumn,
            this.onTimeDataGridViewCheckBoxColumn});
            this.dataGridView1.DataSource = this.attendanceEmployeeBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(-5, 141);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(923, 455);
            this.dataGridView1.TabIndex = 10;
            // 
            // dbEmployeeDataSet3
            // 
            this.dbEmployeeDataSet3.DataSetName = "dbEmployeeDataSet3";
            this.dbEmployeeDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // attendanceEmployeeBindingSource
            // 
            this.attendanceEmployeeBindingSource.DataMember = "AttendanceEmployee";
            this.attendanceEmployeeBindingSource.DataSource = this.dbEmployeeDataSet3;
            // 
            // attendanceEmployeeTableAdapter
            // 
            this.attendanceEmployeeTableAdapter.ClearBeforeFill = true;
            // 
            // attendanceIDDataGridViewTextBoxColumn
            // 
            this.attendanceIDDataGridViewTextBoxColumn.DataPropertyName = "AttendanceID";
            this.attendanceIDDataGridViewTextBoxColumn.HeaderText = "AttendanceID";
            this.attendanceIDDataGridViewTextBoxColumn.Name = "attendanceIDDataGridViewTextBoxColumn";
            this.attendanceIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            // 
            // timeINDataGridViewTextBoxColumn
            // 
            this.timeINDataGridViewTextBoxColumn.DataPropertyName = "TimeIN";
            this.timeINDataGridViewTextBoxColumn.HeaderText = "TimeIN";
            this.timeINDataGridViewTextBoxColumn.Name = "timeINDataGridViewTextBoxColumn";
            // 
            // timeOutDataGridViewTextBoxColumn
            // 
            this.timeOutDataGridViewTextBoxColumn.DataPropertyName = "TimeOut";
            this.timeOutDataGridViewTextBoxColumn.HeaderText = "TimeOut";
            this.timeOutDataGridViewTextBoxColumn.Name = "timeOutDataGridViewTextBoxColumn";
            // 
            // totalHoursDataGridViewTextBoxColumn
            // 
            this.totalHoursDataGridViewTextBoxColumn.DataPropertyName = "TotalHours";
            this.totalHoursDataGridViewTextBoxColumn.HeaderText = "TotalHours";
            this.totalHoursDataGridViewTextBoxColumn.Name = "totalHoursDataGridViewTextBoxColumn";
            // 
            // isLateDataGridViewCheckBoxColumn
            // 
            this.isLateDataGridViewCheckBoxColumn.DataPropertyName = "IsLate";
            this.isLateDataGridViewCheckBoxColumn.HeaderText = "IsLate";
            this.isLateDataGridViewCheckBoxColumn.Name = "isLateDataGridViewCheckBoxColumn";
            // 
            // totalDaysDataGridViewTextBoxColumn
            // 
            this.totalDaysDataGridViewTextBoxColumn.DataPropertyName = "TotalDays";
            this.totalDaysDataGridViewTextBoxColumn.HeaderText = "TotalDays";
            this.totalDaysDataGridViewTextBoxColumn.Name = "totalDaysDataGridViewTextBoxColumn";
            // 
            // onTimeDataGridViewCheckBoxColumn
            // 
            this.onTimeDataGridViewCheckBoxColumn.DataPropertyName = "OnTime";
            this.onTimeDataGridViewCheckBoxColumn.HeaderText = "OnTime";
            this.onTimeDataGridViewCheckBoxColumn.Name = "onTimeDataGridViewCheckBoxColumn";
            // 
            // AttendanceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(930, 730);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnRequestLeave);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AttendanceForm";
            this.Text = "AttendanceForm";

            this.btnRequestLeave.ResumeLayout(false);
            this.btnRequestLeave.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbEmployeeDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceEmployeeBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private roundedRectangle.FabonPanel btnRequestLeave;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private dbEmployeeDataSet3 dbEmployeeDataSet3;
        private System.Windows.Forms.BindingSource attendanceEmployeeBindingSource;
        private dbEmployeeDataSet3TableAdapters.AttendanceEmployeeTableAdapter attendanceEmployeeTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn attendanceIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeINDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeOutDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalHoursDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isLateDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalDaysDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn onTimeDataGridViewCheckBoxColumn;
    }
}