﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class EmployeeDetailsForm : Form
    {
        private string employeeId;

        public EmployeeDetailsForm(string employeeId)
        {
            InitializeComponent();
            this.employeeId = employeeId;
            LoadEmployeeDetails();
        }

        private void LoadEmployeeDetails()
        {
            string connectionString = "Server=LAPTOP-DLKIA2TF\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Query to fetch employee data
                    string query = "SELECT EmployeeID, FullName, position, email, phone_number, address, birthdate, hire_date, worked_for FROM Employee WHERE EmployeeID = @EmployeeID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@EmployeeID", employeeId);

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // Display employee details in the form
                        UserProfileAdmin.Text = $"{reader["FullName"]}";
                        position.Text = reader["position"].ToString();
                        email.Text = reader["email"].ToString();
                        phone.Text = reader["phone_number"].ToString();
                        address.Text = reader["address"].ToString();
                        birthdate.Text = reader["birthdate"].ToString();
                        HireDate.Text = reader["hire_date"].ToString();
                        workedFor.Text = reader["worked_for"].ToString();
                        
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }
    
        private void EmployeeDetailsForm_Load(object sender, EventArgs e)
        {

        }

        private void fabonPanel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void fabonPanel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
