﻿namespace TimeTrackPay
{
    partial class DashboardAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.fabonPanel6 = new roundedRectangle.FabonPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.fabonPanel2 = new roundedRectangle.FabonPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.fabonPanel3 = new roundedRectangle.FabonPanel();
            this.btnMoreInfoAdminAttendance = new TimeTrackPay.button();
            this.fabonPanel5 = new roundedRectangle.FabonPanel();
            this.btnMoreInfoPayrollRecords = new TimeTrackPay.button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.fabonPanel7 = new roundedRectangle.FabonPanel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.fabonPanel4 = new roundedRectangle.FabonPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.fabonPanel1 = new roundedRectangle.FabonPanel();
            this.fabonPanel8 = new roundedRectangle.FabonPanel();
            this.fabonPanel11 = new roundedRectangle.FabonPanel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.button3 = new TimeTrackPay.button();
            this.fabonPanel10 = new roundedRectangle.FabonPanel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.button2 = new TimeTrackPay.button();
            this.fabonPanel9 = new roundedRectangle.FabonPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.button1 = new TimeTrackPay.button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.fabonPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.fabonPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.fabonPanel3.SuspendLayout();
            this.fabonPanel5.SuspendLayout();
            this.fabonPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.fabonPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.fabonPanel1.SuspendLayout();
            this.fabonPanel8.SuspendLayout();
            this.fabonPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.fabonPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.fabonPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.label3.Location = new System.Drawing.Point(212, 215);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(142, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "DELORITOS,";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(176, 117);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 31);
            this.label2.TabIndex = 3;
            this.label2.Text = "Attendance";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(176, 55);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "View all";
            // 
            // fabonPanel6
            // 
            this.fabonPanel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.fabonPanel6.BorderRadius = 30;
            this.fabonPanel6.Controls.Add(this.pictureBox1);
            this.fabonPanel6.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel6.GradientAngle = 90F;
            this.fabonPanel6.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel6.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel6.Location = new System.Drawing.Point(40, 32);
            this.fabonPanel6.Margin = new System.Windows.Forms.Padding(4);
            this.fabonPanel6.Name = "fabonPanel6";
            this.fabonPanel6.Size = new System.Drawing.Size(119, 116);
            this.fabonPanel6.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.pictureBox1.Image = global::TimeTrackPay.Properties.Resources.AttendanceLogoMed;
            this.pictureBox1.Location = new System.Drawing.Point(23, 21);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(80, 70);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // fabonPanel2
            // 
            this.fabonPanel2.BackColor = System.Drawing.Color.White;
            this.fabonPanel2.BorderRadius = 70;
            this.fabonPanel2.Controls.Add(this.label7);
            this.fabonPanel2.Controls.Add(this.label4);
            this.fabonPanel2.Controls.Add(this.pictureBox2);
            this.fabonPanel2.Controls.Add(this.label3);
            this.fabonPanel2.Controls.Add(this.label2);
            this.fabonPanel2.Controls.Add(this.label1);
            this.fabonPanel2.Controls.Add(this.fabonPanel6);
            this.fabonPanel2.Controls.Add(this.fabonPanel3);
            this.fabonPanel2.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel2.GradientAngle = 90F;
            this.fabonPanel2.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.fabonPanel2.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.fabonPanel2.Location = new System.Drawing.Point(23, 126);
            this.fabonPanel2.Margin = new System.Windows.Forms.Padding(4);
            this.fabonPanel2.Name = "fabonPanel2";
            this.fabonPanel2.Size = new System.Drawing.Size(443, 382);
            this.fabonPanel2.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(176, 86);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(142, 31);
            this.label7.TabIndex = 7;
            this.label7.Text = "Employee";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.label4.Location = new System.Drawing.Point(212, 239);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(165, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "Franz Louies C.";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.pictureBox2.Image = global::TimeTrackPay.Properties.Resources.UserLogo;
            this.pictureBox2.Location = new System.Drawing.Point(40, 177);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.pictureBox2.Size = new System.Drawing.Size(137, 117);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // fabonPanel3
            // 
            this.fabonPanel3.BackColor = System.Drawing.Color.White;
            this.fabonPanel3.BorderRadius = 0;
            this.fabonPanel3.Controls.Add(this.btnMoreInfoAdminAttendance);
            this.fabonPanel3.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel3.GradientAngle = 90F;
            this.fabonPanel3.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel3.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel3.Location = new System.Drawing.Point(0, 302);
            this.fabonPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.fabonPanel3.Name = "fabonPanel3";
            this.fabonPanel3.Size = new System.Drawing.Size(443, 80);
            this.fabonPanel3.TabIndex = 0;
            // 
            // btnMoreInfoAdminAttendance
            // 
            this.btnMoreInfoAdminAttendance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.btnMoreInfoAdminAttendance.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.btnMoreInfoAdminAttendance.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnMoreInfoAdminAttendance.BorderRadius = 0;
            this.btnMoreInfoAdminAttendance.BorderSize = 0;
            this.btnMoreInfoAdminAttendance.FlatAppearance.BorderSize = 0;
            this.btnMoreInfoAdminAttendance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMoreInfoAdminAttendance.ForeColor = System.Drawing.Color.White;
            this.btnMoreInfoAdminAttendance.Image = global::TimeTrackPay.Properties.Resources.infoButton;
            this.btnMoreInfoAdminAttendance.Location = new System.Drawing.Point(0, 0);
            this.btnMoreInfoAdminAttendance.Margin = new System.Windows.Forms.Padding(4);
            this.btnMoreInfoAdminAttendance.Name = "btnMoreInfoAdminAttendance";
            this.btnMoreInfoAdminAttendance.Size = new System.Drawing.Size(443, 80);
            this.btnMoreInfoAdminAttendance.TabIndex = 0;
            this.btnMoreInfoAdminAttendance.TextColor = System.Drawing.Color.White;
            this.btnMoreInfoAdminAttendance.UseVisualStyleBackColor = false;
            // 
            // fabonPanel5
            // 
            this.fabonPanel5.BackColor = System.Drawing.Color.White;
            this.fabonPanel5.BorderRadius = 0;
            this.fabonPanel5.Controls.Add(this.btnMoreInfoPayrollRecords);
            this.fabonPanel5.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel5.GradientAngle = 90F;
            this.fabonPanel5.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel5.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel5.Location = new System.Drawing.Point(0, 302);
            this.fabonPanel5.Margin = new System.Windows.Forms.Padding(4);
            this.fabonPanel5.Name = "fabonPanel5";
            this.fabonPanel5.Size = new System.Drawing.Size(443, 80);
            this.fabonPanel5.TabIndex = 0;
            // 
            // btnMoreInfoPayrollRecords
            // 
            this.btnMoreInfoPayrollRecords.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.btnMoreInfoPayrollRecords.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.btnMoreInfoPayrollRecords.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnMoreInfoPayrollRecords.BorderRadius = 0;
            this.btnMoreInfoPayrollRecords.BorderSize = 0;
            this.btnMoreInfoPayrollRecords.FlatAppearance.BorderSize = 0;
            this.btnMoreInfoPayrollRecords.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMoreInfoPayrollRecords.ForeColor = System.Drawing.Color.White;
            this.btnMoreInfoPayrollRecords.Image = global::TimeTrackPay.Properties.Resources.infoButton;
            this.btnMoreInfoPayrollRecords.Location = new System.Drawing.Point(0, 0);
            this.btnMoreInfoPayrollRecords.Margin = new System.Windows.Forms.Padding(4);
            this.btnMoreInfoPayrollRecords.Name = "btnMoreInfoPayrollRecords";
            this.btnMoreInfoPayrollRecords.Size = new System.Drawing.Size(443, 80);
            this.btnMoreInfoPayrollRecords.TabIndex = 1;
            this.btnMoreInfoPayrollRecords.TextColor = System.Drawing.Color.White;
            this.btnMoreInfoPayrollRecords.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(179, 117);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(123, 31);
            this.label9.TabIndex = 7;
            this.label9.Text = "Records";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(179, 86);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(215, 31);
            this.label8.TabIndex = 7;
            this.label8.Text = "Manage Payroll";
            // 
            // fabonPanel7
            // 
            this.fabonPanel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.fabonPanel7.BorderRadius = 30;
            this.fabonPanel7.Controls.Add(this.pictureBox4);
            this.fabonPanel7.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel7.GradientAngle = 90F;
            this.fabonPanel7.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel7.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.fabonPanel7.Location = new System.Drawing.Point(40, 32);
            this.fabonPanel7.Margin = new System.Windows.Forms.Padding(4);
            this.fabonPanel7.Name = "fabonPanel7";
            this.fabonPanel7.Size = new System.Drawing.Size(119, 116);
            this.fabonPanel7.TabIndex = 2;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(148)))), ((int)(((byte)(152)))));
            this.pictureBox4.Image = global::TimeTrackPay.Properties.Resources.PayrollLogoBig;
            this.pictureBox4.Location = new System.Drawing.Point(25, 21);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(85, 70);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Inter", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(16, 6);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(230, 49);
            this.label5.TabIndex = 10;
            this.label5.Text = "Dashboard";
            // 
            // fabonPanel4
            // 
            this.fabonPanel4.BackColor = System.Drawing.Color.White;
            this.fabonPanel4.BorderRadius = 70;
            this.fabonPanel4.Controls.Add(this.label10);
            this.fabonPanel4.Controls.Add(this.label9);
            this.fabonPanel4.Controls.Add(this.label8);
            this.fabonPanel4.Controls.Add(this.fabonPanel7);
            this.fabonPanel4.Controls.Add(this.pictureBox3);
            this.fabonPanel4.Controls.Add(this.fabonPanel5);
            this.fabonPanel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.fabonPanel4.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel4.GradientAngle = 90F;
            this.fabonPanel4.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.fabonPanel4.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.fabonPanel4.Location = new System.Drawing.Point(537, 126);
            this.fabonPanel4.Margin = new System.Windows.Forms.Padding(4);
            this.fabonPanel4.Name = "fabonPanel4";
            this.fabonPanel4.Size = new System.Drawing.Size(443, 382);
            this.fabonPanel4.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(179, 59);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(165, 31);
            this.label10.TabIndex = 8;
            this.label10.Text = "Access and";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.pictureBox3.Image = global::TimeTrackPay.Properties.Resources.HistoryLogo;
            this.pictureBox3.Location = new System.Drawing.Point(25, 177);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.pictureBox3.Size = new System.Drawing.Size(133, 117);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(100)))), ((int)(((byte)(102)))));
            this.label6.Location = new System.Drawing.Point(23, 54);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(665, 24);
            this.label6.TabIndex = 11;
            this.label6.Text = "Welcome to Employee Attendance Manangement and Payroll System";
            // 
            // fabonPanel1
            // 
            this.fabonPanel1.BackColor = System.Drawing.Color.White;
            this.fabonPanel1.BorderRadius = 30;
            this.fabonPanel1.Controls.Add(this.fabonPanel8);
            this.fabonPanel1.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel1.GradientAngle = 90F;
            this.fabonPanel1.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(197)))), ((int)(((byte)(197)))));
            this.fabonPanel1.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(197)))), ((int)(((byte)(197)))));
            this.fabonPanel1.Location = new System.Drawing.Point(23, 530);
            this.fabonPanel1.Name = "fabonPanel1";
            this.fabonPanel1.Size = new System.Drawing.Size(1144, 265);
            this.fabonPanel1.TabIndex = 12;
            // 
            // fabonPanel8
            // 
            this.fabonPanel8.BackColor = System.Drawing.Color.White;
            this.fabonPanel8.BorderRadius = 30;
            this.fabonPanel8.Controls.Add(this.fabonPanel11);
            this.fabonPanel8.Controls.Add(this.fabonPanel10);
            this.fabonPanel8.Controls.Add(this.fabonPanel9);
            this.fabonPanel8.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel8.GradientAngle = 90F;
            this.fabonPanel8.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(250)))), ((int)(((byte)(249)))));
            this.fabonPanel8.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(250)))), ((int)(((byte)(249)))));
            this.fabonPanel8.Location = new System.Drawing.Point(3, 3);
            this.fabonPanel8.Name = "fabonPanel8";
            this.fabonPanel8.Size = new System.Drawing.Size(1138, 259);
            this.fabonPanel8.TabIndex = 0;
            // 
            // fabonPanel11
            // 
            this.fabonPanel11.BackColor = System.Drawing.Color.White;
            this.fabonPanel11.BorderRadius = 30;
            this.fabonPanel11.Controls.Add(this.label16);
            this.fabonPanel11.Controls.Add(this.label13);
            this.fabonPanel11.Controls.Add(this.pictureBox7);
            this.fabonPanel11.Controls.Add(this.button3);
            this.fabonPanel11.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel11.GradientAngle = 90F;
            this.fabonPanel11.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(83)))), ((int)(((byte)(83)))));
            this.fabonPanel11.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(83)))), ((int)(((byte)(83)))));
            this.fabonPanel11.Location = new System.Drawing.Point(766, 33);
            this.fabonPanel11.Name = "fabonPanel11";
            this.fabonPanel11.Size = new System.Drawing.Size(350, 200);
            this.fabonPanel11.TabIndex = 2;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox7.Image = global::TimeTrackPay.Properties.Resources.LateLogo;
            this.pictureBox7.Location = new System.Drawing.Point(152, 27);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(238, 105);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 3;
            this.pictureBox7.TabStop = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.button3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.button3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(83)))), ((int)(((byte)(83)))));
            this.button3.BorderRadius = 0;
            this.button3.BorderSize = 0;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Image = global::TimeTrackPay.Properties.Resources.infoButton;
            this.button3.Location = new System.Drawing.Point(0, 147);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(350, 53);
            this.button3.TabIndex = 2;
            this.button3.TextColor = System.Drawing.Color.White;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // fabonPanel10
            // 
            this.fabonPanel10.BackColor = System.Drawing.Color.White;
            this.fabonPanel10.BorderRadius = 30;
            this.fabonPanel10.Controls.Add(this.label15);
            this.fabonPanel10.Controls.Add(this.label12);
            this.fabonPanel10.Controls.Add(this.pictureBox6);
            this.fabonPanel10.Controls.Add(this.button2);
            this.fabonPanel10.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel10.GradientAngle = 90F;
            this.fabonPanel10.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.fabonPanel10.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.fabonPanel10.Location = new System.Drawing.Point(390, 33);
            this.fabonPanel10.Name = "fabonPanel10";
            this.fabonPanel10.Size = new System.Drawing.Size(350, 200);
            this.fabonPanel10.TabIndex = 1;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.Image = global::TimeTrackPay.Properties.Resources.ProfileLogoDashboard;
            this.pictureBox6.Location = new System.Drawing.Point(215, 27);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(106, 105);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 2;
            this.pictureBox6.TabStop = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(156)))), ((int)(((byte)(159)))));
            this.button2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(156)))), ((int)(((byte)(159)))));
            this.button2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(187)))), ((int)(((byte)(191)))));
            this.button2.BorderRadius = 0;
            this.button2.BorderSize = 0;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Image = global::TimeTrackPay.Properties.Resources.infoButton;
            this.button2.Location = new System.Drawing.Point(3, 146);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(350, 53);
            this.button2.TabIndex = 1;
            this.button2.TextColor = System.Drawing.Color.White;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // fabonPanel9
            // 
            this.fabonPanel9.BackColor = System.Drawing.Color.White;
            this.fabonPanel9.BorderRadius = 30;
            this.fabonPanel9.Controls.Add(this.label14);
            this.fabonPanel9.Controls.Add(this.label11);
            this.fabonPanel9.Controls.Add(this.pictureBox5);
            this.fabonPanel9.Controls.Add(this.button1);
            this.fabonPanel9.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel9.GradientAngle = 90F;
            this.fabonPanel9.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(180)))), ((int)(((byte)(130)))));
            this.fabonPanel9.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(180)))), ((int)(((byte)(130)))));
            this.fabonPanel9.Location = new System.Drawing.Point(14, 33);
            this.fabonPanel9.Name = "fabonPanel9";
            this.fabonPanel9.Size = new System.Drawing.Size(350, 200);
            this.fabonPanel9.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Inter", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(46, 108);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(131, 21);
            this.label11.TabIndex = 2;
            this.label11.Text = "On time today";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = global::TimeTrackPay.Properties.Resources.ClockLogo;
            this.pictureBox5.Location = new System.Drawing.Point(220, 27);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(94, 108);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(141)))), ((int)(((byte)(104)))));
            this.button1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(141)))), ((int)(((byte)(104)))));
            this.button1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(180)))), ((int)(((byte)(130)))));
            this.button1.BorderRadius = 0;
            this.button1.BorderSize = 0;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = global::TimeTrackPay.Properties.Resources.infoButton;
            this.button1.Location = new System.Drawing.Point(0, 147);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(350, 53);
            this.button1.TabIndex = 0;
            this.button1.TextColor = System.Drawing.Color.White;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Inter", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(35, 108);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(150, 21);
            this.label12.TabIndex = 3;
            this.label12.Text = "Total Employees";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Inter", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(45, 108);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(101, 21);
            this.label13.TabIndex = 4;
            this.label13.Text = "Late today";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Inter", 36F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(60, 27);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(103, 72);
            this.label14.TabIndex = 3;
            this.label14.Text = "77";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Inter", 36F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(58, 27);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(110, 72);
            this.label15.TabIndex = 4;
            this.label15.Text = "89";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Inter", 36F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(45, 27);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(97, 72);
            this.label16.TabIndex = 5;
            this.label16.Text = "12";
            // 
            // DashboardAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(1222, 851);
            this.Controls.Add(this.fabonPanel1);
            this.Controls.Add(this.fabonPanel2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.fabonPanel4);
            this.Controls.Add(this.label6);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DashboardAdmin";
            this.Text = "DashboardAdmin";
            this.fabonPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.fabonPanel2.ResumeLayout(false);
            this.fabonPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.fabonPanel3.ResumeLayout(false);
            this.fabonPanel5.ResumeLayout(false);
            this.fabonPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.fabonPanel4.ResumeLayout(false);
            this.fabonPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.fabonPanel1.ResumeLayout(false);
            this.fabonPanel8.ResumeLayout(false);
            this.fabonPanel11.ResumeLayout(false);
            this.fabonPanel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.fabonPanel10.ResumeLayout(false);
            this.fabonPanel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.fabonPanel9.ResumeLayout(false);
            this.fabonPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private button btnMoreInfoAdminAttendance;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private roundedRectangle.FabonPanel fabonPanel6;
        private roundedRectangle.FabonPanel fabonPanel2;
        private roundedRectangle.FabonPanel fabonPanel3;
        private button btnMoreInfoPayrollRecords;
        private System.Windows.Forms.PictureBox pictureBox3;
        private roundedRectangle.FabonPanel fabonPanel5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private roundedRectangle.FabonPanel fabonPanel7;
        private System.Windows.Forms.Label label5;
        private roundedRectangle.FabonPanel fabonPanel4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label4;
        private roundedRectangle.FabonPanel fabonPanel1;
        private roundedRectangle.FabonPanel fabonPanel8;
        private roundedRectangle.FabonPanel fabonPanel11;
        private button button3;
        private roundedRectangle.FabonPanel fabonPanel10;
        private button button2;
        private roundedRectangle.FabonPanel fabonPanel9;
        private button button1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
    }
}