﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class LoginInfo : Form
    {
        LoginPage loginPage;
        DashboardEmployee dashboardEmployee;
        public LoginInfo()
        {
            InitializeComponent();
        }

        public static string user;

        Bitmap buttonLargeEventEnter = Properties.Resources.LoginButtonLargeHover;
        Bitmap buttonLargeEventLeave = Properties.Resources.LoginButtonLarge;

        private void label2_Click(object sender, EventArgs e)
        {
            if (loginPage == null)
            {
                loginPage = new LoginPage();   //Create LoginPage
                loginPage.FormClosed += loginPage_FormClosed;  //Add eventhandler to cleanup
            }

            loginPage.Show(this);  //Show Form 
            Hide();
        }

        void loginPage_FormClosed(object sender, FormClosedEventArgs e)
        {
            loginPage = null;  //If form is closed make sure reference is set to null
            Hide();
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.Image = buttonLargeEventEnter;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.Image = buttonLargeEventLeave;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = !textBox2.UseSystemPasswordChar;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Missing Information!!");
                return;
            }

            try
            {
                using (SqlConnection Con = new SqlConnection(@"Server=LAPTOP-PVCP8MJI\SQLEXPRESS; Database=dbEmployee; Integrated Security = True"))
                {
                    Con.Open();

                    // Try to authenticate as Admin
                    string query = "SELECT AdminID FROM Admin WHERE AdminID=@AdminID AND AdminPassword=@Password";
                    SqlDataAdapter sdaAdmin = new SqlDataAdapter(query, Con);
                    sdaAdmin.SelectCommand.Parameters.AddWithValue("@AdminID", textBox1.Text);
                    sdaAdmin.SelectCommand.Parameters.AddWithValue("@Password", textBox2.Text);
                    DataTable dtAdmin = new DataTable();
                    sdaAdmin.Fill(dtAdmin);

                    if (dtAdmin.Rows.Count == 1)
                    {
                        user = textBox1.Text;
                        int adminID = Convert.ToInt32(dtAdmin.Rows[0]["AdminID"]);
                        FormAdmin adminDashboard = new FormAdmin(adminID);  // Create dashboard for admin
                        adminDashboard.Show();
                        this.Hide();
                    }
                    else
                    {
                        // Try to authenticate as Employee if Admin fails
                        query = "SELECT EmployeeID FROM Employee WHERE EmployeeID=@EmployeeID AND EmployeePassword=@Password";
                        SqlDataAdapter sdaEmployee = new SqlDataAdapter(query, Con);
                        sdaEmployee.SelectCommand.Parameters.AddWithValue("@EmployeeID", textBox1.Text);
                        sdaEmployee.SelectCommand.Parameters.AddWithValue("@Password", textBox2.Text);
                        DataTable dtEmployee = new DataTable();
                        sdaEmployee.Fill(dtEmployee);

                        if (dtEmployee.Rows.Count == 1)
                        {
                            user = textBox1.Text;
                            string employeeIdString = dtEmployee.Rows[0]["EmployeeID"].ToString();

                            int employeeID;
                            if (int.TryParse(employeeIdString, out employeeID))
                            {
                                // Insert or update attendance record
                                InsertOrUpdateAttendanceRecord(employeeID);

                                DashboardEmployee f2 = new DashboardEmployee(employeeID);  // Create dashboard for employee
                                f2.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("Employee ID is not in the correct format.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Wrong UserName or Password!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void InsertOrUpdateAttendanceRecord(int employeeID)
        {
            DateTime now = DateTime.Now;
            bool onTime = now.TimeOfDay < new TimeSpan(7, 0, 0);
            double totalHours = 0;

            // Fetch existing TimeIN if it exists
            string fetchTimeInQuery = "SELECT TimeIN FROM AttendanceEmployee WHERE EmployeeID = @EmployeeID AND Date = @Date";
            string fetchTimeOutQuery = "SELECT TimeOut FROM AttendanceEmployee WHERE EmployeeID = @EmployeeID AND Date = @Date";

            using (SqlConnection Con = new SqlConnection(@"Server=LAPTOP-PVCP8MJI\SQLEXPRESS; Database=dbEmployee; Integrated Security=True"))
            {
                TimeSpan? timeIn = null;
                TimeSpan? timeOut = null;

                try
                {
                    Con.Open();

                    using (SqlCommand fetchCommand = new SqlCommand(fetchTimeInQuery, Con))
                    {
                        fetchCommand.Parameters.AddWithValue("@EmployeeID", employeeID);
                        fetchCommand.Parameters.AddWithValue("@Date", now.Date);
                        object result = fetchCommand.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            timeIn = (TimeSpan)result;
                        }
                    }

                    using (SqlCommand fetchCommand = new SqlCommand(fetchTimeOutQuery, Con))
                    {
                        fetchCommand.Parameters.AddWithValue("@EmployeeID", employeeID);
                        fetchCommand.Parameters.AddWithValue("@Date", now.Date);
                        object result = fetchCommand.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            timeOut = (TimeSpan)result;
                        }
                    }

                    if (timeIn.HasValue && timeOut.HasValue)
                    {
                        totalHours = (timeOut.Value - timeIn.Value).TotalHours;
                    }

                    string query = "IF EXISTS (SELECT 1 FROM AttendanceEmployee WHERE EmployeeID = @EmployeeID AND Date = @Date) " +
                                   "UPDATE AttendanceEmployee SET TimeIN = @TimeIN, OnTime = @OnTime, IsLate = @IsLate, TotalHours = @TotalHours WHERE EmployeeID = @EmployeeID AND Date = @Date " +
                                   "ELSE " +
                                   "INSERT INTO AttendanceEmployee (EmployeeID, Date, TimeIN, OnTime, IsLate, TotalHours) VALUES (@EmployeeID, @Date, @TimeIN, @OnTime, @IsLate, @TotalHours)";

                    using (SqlCommand command = new SqlCommand(query, Con))
                    {
                        command.Parameters.AddWithValue("@EmployeeID", employeeID);
                        command.Parameters.AddWithValue("@Date", now.Date);
                        command.Parameters.AddWithValue("@TimeIN", now.TimeOfDay);
                        command.Parameters.AddWithValue("@OnTime", onTime ? 1 : 0);
                        command.Parameters.AddWithValue("@IsLate", onTime ? 0 : 1);
                        command.Parameters.AddWithValue("@TotalHours", totalHours);

                        command.ExecuteNonQuery();
                        MessageBox.Show("Attendance record inserted/updated successfully."); // Success message
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while inserting/updating attendance record: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
        }
    }
}
