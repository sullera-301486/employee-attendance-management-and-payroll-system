﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class adminAttendanceNew : Form
    {
        string connectionString = "Server=LAPTOP-PVCP8MJI\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";
        public adminAttendanceNew()
        {
            InitializeComponent();
            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddEmployee();
            Close();
            
        }





        private void AddEmployee()
        {
            using (SqlConnection Con = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Employee (EmployeeID, Position, FullName, EmployeePassword, Birthdate, Hire_Date, Phone_Number, Email, Address, Worked_For, EmployeeSalary) VALUES (@EmployeeID, @Position, @FullName, @EmployeePassword, @Birthdate, @Hire_Date, @Phone_Number, @Email, @Address, @Worked_For, @EmployeeSalary)";

                using (SqlCommand command = new SqlCommand(query, Con))
                {
                    // Assuming you have TextBoxes for each field on your form
                    command.Parameters.AddWithValue("@EmployeeID", NewEmployeeid.Text);
                    command.Parameters.AddWithValue("@Position", NewPosition.Text);
                    command.Parameters.AddWithValue("@FullName", NewFullName.Text);
                    command.Parameters.AddWithValue("@EmployeePassword", EmployerPassword.Text);
                    command.Parameters.AddWithValue("@Birthdate", DateTime.Parse(NewEmployeeBday.Text)); // Ensure date format is correct
                    command.Parameters.AddWithValue("@Hire_Date", DateTime.Parse(NewHireDate.Text)); // Ensure date format is correct
                    command.Parameters.AddWithValue("@Phone_Number", NewPhoneNumber.Text);
                    command.Parameters.AddWithValue("@Email", NewEmail.Text);
                    command.Parameters.AddWithValue("@Address", NewAddress.Text);
                    command.Parameters.AddWithValue("@Worked_For", newWorkedfor.Text);
                    command.Parameters.AddWithValue("@EmployeeSalary", decimal.Parse(EmployeeSalary.Text)); // Ensure salary is a decimal

                    try
                    {
                        Con.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Employee added successfully."); // Success message
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred while adding the employee: " + ex.Message);
                    }
                }
            }
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            Close();
        }
    }
}
