﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class EmployeeDetailsForm : Form
    {
        private string employeeId;

        public EmployeeDetailsForm(string employeeId)
        {
            InitializeComponent();
            this.employeeId = employeeId;
            LoadEmployeeDetails();
        }

        private void LoadEmployeeDetails()
        {
            string connectionString = "Server=LAPTOP-PVCP8MJI\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Query to fetch employee data
                    string query = "SELECT EmployeeID, FullName, position, email, phone_number, address, birthdate, hire_date, worked_for FROM Employee WHERE EmployeeID = @EmployeeID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@EmployeeID", employeeId);

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // Display employee details in the form
                        NameEmployee.Text = $"{reader["FullName"]}";
                        EmployeePosition.Text = reader["position"].ToString();
                        EmployeeEmail.Text = reader["email"].ToString();
                        PhoneNumber.Text = reader["phone_number"].ToString();
                        EmployeeAddress.Text = reader["address"].ToString();
                        EmployeeBday.Text = reader["birthdate"].ToString();
                        HireDateEmployee.Text = reader["hire_date"].ToString();
                        WorkedForEmployee.Text = reader["worked_for"].ToString();
                        IDemployee.Text = reader["EmployeeID"].ToString();

                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }
    
        private void EmployeeDetailsForm_Load(object sender, EventArgs e)
        {

        }

        private void fabonPanel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void fabonPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void WorkedForEmployee_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void fabonPanel15_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
