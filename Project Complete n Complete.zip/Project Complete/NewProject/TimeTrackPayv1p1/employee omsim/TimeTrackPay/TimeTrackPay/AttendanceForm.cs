﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class AttendanceForm : Form
    {
        private int employeeID;
        string connectionString = "Server=DESKTOP-JMR591K\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";
        private SqlConnection Con;
        private SqlCommand Cmd;

        public AttendanceForm(int id)
        {
            employeeID = id;
            InitializeComponent();
            Con = new SqlConnection(connectionString);
            FILLDGV();
        }

        private void AttendanceForm_Load(object sender, EventArgs e)
        {

        }

        private void FillComboSearchCode()
        {

        }

        private void FILLDGV()
        {

            Con.Open();
            string query = "SELECT * FROM AttendanceEmployee WHERE EmployeeID = @EmployeeID";
            using (Cmd = new SqlCommand(query, Con))
            {
                // Add the employeeID parameter to the query
                Cmd.Parameters.AddWithValue("@EmployeeID", employeeID);

                // Use SqlDataAdapter to execute the query
                SqlDataAdapter da = new SqlDataAdapter(Cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Bind the result to the DataGridView
                dataGridView1.DataSource = dt;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            leaveRequest leaveRequest = new leaveRequest(employeeID);
            leaveRequest.Show();
        }

        private void btnRequestLeave_Paint(object sender, PaintEventArgs e)
        {
        }

        private void btnRequestLeave_MouseClick(object sender, MouseEventArgs e)
        {
            leaveRequest leaveRequest = new leaveRequest(employeeID);
            leaveRequest.Show();
        }

        private void label8_Click(object sender, EventArgs e)
        {
        }





    }
}
