﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class NewPayForm : Form
    {
        public NewPayForm()
        {
            InitializeComponent();
        }

        private void NewPayForm_Load(object sender, EventArgs e)
        {
        }

        private void PhilDeduc_Click(object sender, EventArgs e)
        {
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
        }

        private void compute_Click_1(object sender, EventArgs e)
        {
            try
            {
                decimal basicSalary = decimal.Parse(textBox4.Text);

                decimal sssdeduc = basicSalary * 0.045m;
                decimal pagibigdeduc = basicSalary * 0.015m;
                decimal philHdeduc = basicSalary * 0.015m;
                decimal incomeTaxdeduc = basicSalary * 0.025m;

                decimal totalDeduc = sssdeduc + pagibigdeduc + philHdeduc + incomeTaxdeduc;
                decimal netPay = basicSalary - totalDeduc;

                // Display the results
                SSSDeduc.Text = sssdeduc.ToString("F2");
                PagibigDeduc.Text = pagibigdeduc.ToString("F2");
                PhilDeduc.Text = philHdeduc.ToString("F2");
                income.Text = incomeTaxdeduc.ToString("F2");
                totalDeduction.Text = totalDeduc.ToString("F2");
                NetPay.Text = netPay.ToString("F2");
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid number for Basic Salary.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "Server=DESKTOP-JMR591K\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";
            string query = "INSERT INTO Payroll (EmployeeID, AdminID, SSSDeduction, PhilHealthDeduction, PagIbigDeduction, TotalDeduction, Netpay, Payperiod, IncomeTax) " +
                           "VALUES (@EmployeeID, @AdminID, @SSSDeduction, @PhilHealthDeduction, @PagIbigDeduction,@TotalDeduc, @Netpay, @Payperiod, @IncomeTax)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@EmployeeID", textboxemployeeid.Text);
                cmd.Parameters.AddWithValue("@AdminID", textBoxAdminid.Text);
                cmd.Parameters.AddWithValue("@SSSDeduction", SSSDeduc.Text);
                cmd.Parameters.AddWithValue("@PhilHealthDeduction", PhilDeduc.Text);
                cmd.Parameters.AddWithValue("@PagIbigDeduction", PagibigDeduc.Text);
                cmd.Parameters.AddWithValue("@Netpay", NetPay.Text);
                cmd.Parameters.AddWithValue("@Payperiod", textBoxPayriod.Text);
                cmd.Parameters.AddWithValue("@IncomeTax", income.Text);
                cmd.Parameters.AddWithValue("@TotalDeduc", totalDeduction.Text);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record inserted successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void textBoxPayriod_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBoxAdminid_TextChanged(object sender, EventArgs e)
        {
        }

        private void textboxemployeeid_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
