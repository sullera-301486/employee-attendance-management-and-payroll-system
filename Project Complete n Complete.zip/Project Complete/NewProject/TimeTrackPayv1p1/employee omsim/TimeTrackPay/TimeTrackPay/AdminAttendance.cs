﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using roundedRectangle;
using System.Xml;
using System.Security.Policy;

namespace TimeTrackPay
{
    public partial class AdminAttendance : Form
    {
        private Panel employeePanel;

        public AdminAttendance()
        {
            InitializeComponent();

            employeePanel = new Panel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true // Allow scrolling if there are many profiles
            };
            this.Controls.Add(employeePanel);
            FILLDGV();
        }

        private void AdminAttendance_Load(object sender, EventArgs e)
        {
            LoadEmployeeProfiles();
            cbMonth.Items.AddRange(new string[]
            {
                "January","February","March","April","May","June","July","August","September",
                "October","November","December"
            });
            cbMonth.SelectedIndexChanged += MonthAttendance_SelectedIndexChanged;
            cbYear.Items.AddRange(new string[] { "2022", "2023", "2024" });
            LoadEmployeeProfiles();
        }

        private void MonthAttendance_SelectedIndexChanged(object sender, EventArgs e)
        {
            MonthAttendance.Text = cbMonth.SelectedItem.ToString();
        }

        private void LoadEmployeeProfiles()
        {
            // Set the connection string to your database
            string connectionString = "Server=DESKTOP-JMR591K\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Query to fetch employee data
                    string query = "SELECT EmployeeID, FullName, Position FROM Employee";
                    SqlCommand command = new SqlCommand(query, connection);

                    SqlDataReader reader = command.ExecuteReader();
                    int panelX = 10; // Start position X for the first panel
                    int panelY = 140; // Start position Y for the first row
                    int panelWidth = 200;
                    int panelHeight = 200;
                    int padding = 20;

                    int maxProfilesPerRow = 4; // Number of profiles per row
                    int profileCountInRow = 0; // Keep track of the number of profiles in the current row
                    employeePanel.Controls.Clear(); // Clear existing controls in the employee panel

                    while (reader.Read())
                    {
                        string employeeId = reader["EmployeeID"].ToString();

                        // Create and add the background panel first, ensuring it's behind everything
                        FabonPanel backgroundPanel = new FabonPanel
                        {
                            Size = new Size(panelWidth + 5, panelHeight + 5), // Increase the size to create a border effect
                            Location = new Point(panelX, panelY), // Slightly adjust the position to center the employee profile panel within it
                            BackColor = Color.Black, // Background color for the border effect
                           
                            GradientBottomColor = Color.Black,
                            GradientTopColor = Color.Black,
                        };

                        // Clone the profile template panel
                        FabonPanel employeeProfilePanel = new FabonPanel
                        {
                            Size = new Size(panelWidth, panelHeight),
                            Location = new Point(panelX + 3, panelY + 3),
                            
                            GradientBottomColor = Color.White,
                            GradientTopColor = Color.White,
                        };

                        // Set the employee name label
                        Label AttendanceNameInPanel = new Label
                        {
                            Text = $"{reader["FullName"]}",
                            Location = new Point(10, 115),
                            Size = new Size(179,19),
                            BackColor = Color.Transparent,
                            TextAlign = ContentAlignment.MiddleCenter,
                        };
                        AttendanceNameInPanel.Font = new Font("Inter", 12, FontStyle.Bold);
                        employeeProfilePanel.Controls.Add(AttendanceNameInPanel);

                        // Set the profile picture
                        PictureBox ProfileForUsers = new PictureBox
                        {
                            Image = Properties.Resources.UserProfileLogo, // Set a default image or use a condition for different images
                            SizeMode = PictureBoxSizeMode.StretchImage,
                            Size = new Size(100, 100),
                            Location = new Point(50, 5),
                            BackColor = Color.Transparent,
                        };
                        employeeProfilePanel.Controls.Add(ProfileForUsers);

                        // Create a "View Profile" button
                        button viewProfileButton = new button
                        {
                            Text = "View Profile",
                            Size = new Size(panelWidth - 20, 30),
                            Location = new Point(10, panelHeight - 40),
                            BorderRadius = 12,
                            BackColor = Color.White,
                            BorderSize = 2,
                            TextColor = Color.Black,
                            BorderColor = Color.Black,
                        };

                        // Attach click event handler to the button
                        viewProfileButton.Click += (sender, e) =>
                        {
                            ShowEmployeeDetails(employeeId);
                        };

                        employeeProfilePanel.Controls.Add(viewProfileButton);
                        employeeProfilePanel.Controls.Add(ProfileForUsers);
                        employeeProfilePanel.Controls.Add(AttendanceNameInPanel);
                        employeeProfilePanel.Controls.Add(viewProfileButton);
                        

                        // Add the employee profile panel to employeePanel
                        employeePanel.Controls.Add(employeeProfilePanel);
                        employeePanel.Controls.Add(backgroundPanel);

                        // Update position for the next profile panel
                        panelX += panelWidth + padding; // Move to the right

                        // If 4 profiles have been added in the current row, move to the next row
                        profileCountInRow++;
                        if (profileCountInRow >= maxProfilesPerRow)
                        {
                           
                            
                            profileCountInRow = 0; // Reset the profile count for the new row
                        }
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }

        // This method will open a new form with the employee's details
        private void ShowEmployeeDetails(string employeeId)
        {
            EmployeeDetailsForm detailsForm = new EmployeeDetailsForm(employeeId);
            detailsForm.Show();
        }

        private void viewProfileButton_Click(object sender, EventArgs e)
        {
            // Handle button click here if necessary
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            adminAttendanceEdit attendanceEdit = new adminAttendanceEdit();
            attendanceEdit.Show();
        }

        private void FILLDGV()
        {
            string connectionString = "Server=DESKTOP-JMR591K\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";
            SqlConnection Con = new SqlConnection(connectionString);
            SqlCommand Cmd = new SqlCommand();
            Con.Open();
            string query = "SELECT * FROM AttendanceEmployee";
            using (Cmd = new SqlCommand(query, Con))
            {
                // Use SqlDataAdapter to execute the query
                SqlDataAdapter da = new SqlDataAdapter(Cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Bind the result to the DataGridView
                dataGridView1.DataSource = dt;
            }
        }

        private void searchBar()
        {
            string connectionString = "Server=DESKTOP-JMR591K\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";

            // Open a connection and use a parameterized query to prevent SQL injection
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    // Retrieve the text to search
                    string searcher = textBox1.Text.Trim();

                    // Use a parameterized query to prevent SQL injection
                    string query = "SELECT * FROM Employee WHERE FullName LIKE @searchTerm";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        // Add parameter to the query
                        cmd.Parameters.AddWithValue("@searchTerm", searcher + "%");

                        // Execute the query
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if any records were returned
                            if (reader.Read())
                            {
                                string empName = reader["FullName"].ToString();
                                string empId = reader["EmployeeID"].ToString();
                                string query2 = "SELECT * FROM AttendanceEmployee WHERE EmployeeID = " + empId;
                                reader.Close();
                                using (SqlCommand cmd2 = new SqlCommand(query2, con))
                                {
                                    // Use SqlDataAdapter to execute the query
                                    SqlDataAdapter da = new SqlDataAdapter(cmd2);
                                    DataTable dt = new DataTable();
                                    da.Fill(dt);

                                    // Bind the result to the DataGridView
                                    dataGridView1.DataSource = dt;
                                }
                            }
                        }
                    }

                    
                }
                catch (Exception ex)
                {
                    // Handle potential errors
                    MessageBox.Show($"An error occurred: {ex.Message}");
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            searchBar();
        }
    }
}
