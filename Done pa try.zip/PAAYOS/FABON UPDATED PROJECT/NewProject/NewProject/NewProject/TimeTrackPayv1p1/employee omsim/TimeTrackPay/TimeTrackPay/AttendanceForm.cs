﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class AttendanceForm : Form
    {
        public AttendanceForm()
        {
            InitializeComponent();
        }

        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            leaveRequest leaveRequest = new leaveRequest();
            leaveRequest.Show();
        }

        private void btnRequestLeave_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void AttendanceForm_Load(object sender, EventArgs e)
        {
  
        }
        

        private void btnRequestLeave_MouseClick(object sender, MouseEventArgs e)
        {
            leaveRequest leaveRequest = new leaveRequest();
            leaveRequest.Show();
        }
    }
}
