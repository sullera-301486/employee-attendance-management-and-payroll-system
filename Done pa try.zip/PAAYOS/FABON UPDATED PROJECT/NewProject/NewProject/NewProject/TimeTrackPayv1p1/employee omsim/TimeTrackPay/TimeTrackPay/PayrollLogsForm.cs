﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class PayrollLogsForm : Form
    {
        public PayrollLogsForm()
        {
            InitializeComponent();
        }

       

        private void PayrollLogsForm_Load(object sender, EventArgs e)
        {

        }
        


        private void fabonPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
