﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class PayrollForm : Form
    {
        private int employeeID;
        string connectionString = "Server=LAPTOP-DLKIA2TF\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";
        private SqlConnection Con;
        public PayrollForm(int id)
        {
            InitializeComponent();
            employeeID = id;
            Con = new SqlConnection(connectionString);
            LoadEmployeeData();
        }

        private void PayrollForm_Load(object sender, EventArgs e)
        {
          
        }

        private void LoadEmployeeData()
        {
            string query = "SELECT FullName, EmployeeID FROM Employee WHERE EmployeeID = @EmployeeID";

            using (SqlCommand command = new SqlCommand(query, Con))
            {
                command.Parameters.AddWithValue("@EmployeeID", employeeID);

                try
                {
                    Con.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        // Display fetched data in the labels
                        EmployeeName.Text = reader["FullName"].ToString();
                        label8.Text = reader["EmployeeID"].ToString();

                        // Debugging Information
                        MessageBox.Show("FullName: " + reader["FullName"].ToString());
                        MessageBox.Show("EmployeeID: " + reader["EmployeeID"].ToString());
                    }
                    else
                    {
                        MessageBox.Show("Employee not found.");
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

        
    }
}
