﻿namespace TimeTrackPay
{
    partial class PayrollLogsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fabonPanel1 = new roundedRectangle.FabonPanel();
            this.SuspendLayout();
            // 
            // fabonPanel1
            // 
            this.fabonPanel1.BackColor = System.Drawing.Color.White;
            this.fabonPanel1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel1.BorderRadius = 30;
            this.fabonPanel1.BorderSize = 0;
            this.fabonPanel1.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel1.GradientAngle = 90F;
            this.fabonPanel1.GradientBottomColor = System.Drawing.Color.Gray;
            this.fabonPanel1.GradientTopColor = System.Drawing.Color.Gray;
            this.fabonPanel1.Location = new System.Drawing.Point(15, 13);
            this.fabonPanel1.Name = "fabonPanel1";
            this.fabonPanel1.Size = new System.Drawing.Size(840, 434);
            this.fabonPanel1.TabIndex = 2;
            this.fabonPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.fabonPanel1_Paint);
            // 
            // PayrollLogsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(871, 460);
            this.Controls.Add(this.fabonPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "PayrollLogsForm";
            this.Text = "PayrollLogsForm";
            this.Load += new System.EventHandler(this.PayrollLogsForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private roundedRectangle.FabonPanel fabonPanel1;
    }
}