﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class leaveRequest : Form
    {
        public leaveRequest()
        {
            InitializeComponent();
        }

        private void btnRequest_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(startDate.Text) || string.IsNullOrEmpty(endDate.Text) || string.IsNullOrEmpty(cbLeaveType.Text))
            {
                MessageBox.Show("Please select a date and leave type.");
            }
            else
            {
                requestSubmitted reqSubmitted = new requestSubmitted();
                reqSubmitted.Show();
                this.Close();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void LeaveRequest_Load(object sender, EventArgs e)
        {
            string[] leaveType = { "Vacation Leave", "Sick Leave", "Maternal Leave", "Bereavement Leave" };
            foreach (string type in leaveType)
            {
                cbLeaveType.Items.Add(type);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
