﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class PayrollLogsForm : Form
    {
        public PayrollLogsForm()
        {
            InitializeComponent();
          
        }

        public void PayrollView()
        {
            List<PayrollLogsData> pay = new List<PayrollLogsData>();
            pay.Add(new PayrollLogsData("2001", "Franz Louies Deloritos", "4:10 PM", "8:10", "4:10 PM", "4:10 PM"));
            pay.Add(new PayrollLogsData("1016", "Neil Nemenzo", "4:10 PM", "8:10", "4:10 PM", "4:10 PM"));
            pay.Add(new PayrollLogsData("1017", "Charles Macaraig", "4:10 PM", "8:10", "4:10 PM", "4:10 PM"));
            pay.Add(new PayrollLogsData("1018", "Ej Sullera", "4:10 PM", "8:10", "4:10 PM", "4:10 PM"));
            pay.Add(new PayrollLogsData("1019", "Marcus Verzo", "4:10 PM", "8:10", "4:10 PM", "4:10 PM"));
            pay.Add(new PayrollLogsData("1020", "Amer Magangcong", "4:10 PM", "8:10", "4:10 PM", "4:10 PM"));

            foreach (PayrollLogsData d in pay)
            {
                // Handle PayrollLogsData without DataGridView
                // You might want to add the logic to display data here
            }
        }

        private void PayrollLogsForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dbEmployeeDataSet6.Payroll' table. You can move, or remove it, as needed.
            this.payrollTableAdapter.Fill(this.dbEmployeeDataSet6.Payroll);
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            // No DataGridView handling required
        }
    }
}
