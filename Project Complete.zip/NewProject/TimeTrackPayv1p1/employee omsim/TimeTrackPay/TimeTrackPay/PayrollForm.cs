﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class PayrollForm : Form
    {
        private int employeeID;
        string connectionString = "Server=DESKTOP-JMR591K\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";
        private SqlConnection Con;
        public PayrollForm(int id)
        {
            InitializeComponent();
            employeeID = id;
            Con = new SqlConnection(connectionString);
            LoadEmployeeData();
            FILLDGV();
        }

        private void PayrollForm_Load(object sender, EventArgs e)
        {
            try
            {
                Con.Open();
                string query2 = ("SELECT *" +
                    " FROM Payroll WHERE EmployeeID = @EmployeeID");
                using (SqlCommand Cmd = new SqlCommand(query2, Con))
                {
                    // Add the employeeID parameter to the query
                    Cmd.Parameters.AddWithValue("@EmployeeID", employeeID);

                    // Use SqlDataAdapter to execute the query
                    SqlDataAdapter da = new SqlDataAdapter(Cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dataGridView1.AutoGenerateColumns = false;
                    dataGridView1.Columns.Clear();

                    dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        DataPropertyName = "EmployeeID",
                        HeaderText = "EmployeeID"
                    });



                    dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        DataPropertyName = "IncomeTax",
                        HeaderText = "Income Tax"
                    });

                    dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        DataPropertyName = "SSSDeduction",
                        HeaderText = "SSSDeduction"
                    });

                    dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        DataPropertyName = "PhilHealthDeduction",
                        HeaderText = "PhilHealthDeduction"
                    });

                    dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        DataPropertyName = "PagIbigDeduction",
                        HeaderText = "PagIbigDeduction"
                    });

                    dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        DataPropertyName = "TotalDeduction",
                        HeaderText = "TotalDeduction"
                    });

                    dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        DataPropertyName = "NetPay",
                        HeaderText = "NetPay"
                    });

                    // Bind the result to the DataGridView
                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }

        private void AdjustDataGridHeights()
        {
            var height = dataGridView1.ColumnHeadersHeight;
            foreach (DataGridViewRow dr in dataGridView1.Rows)
            {
                height += dr.Height;
            }
            dataGridView1.Height = height;
        }

        private void LoadEmployeeData()
        {

        }

        private void FILLDGV()
        {
            string query = "SELECT FullName, EmployeeID FROM Employee WHERE EmployeeID = @EmployeeID";

            using (SqlCommand command = new SqlCommand(query, Con))
            {
                command.Parameters.AddWithValue("@EmployeeID", employeeID);

                try
                {
                    Con.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        // Display fetched data in the labels
                        EmployeeName.Text = reader["FullName"].ToString();
                        label8.Text = reader["EmployeeID"].ToString();


                    }
                    else
                    {
                        MessageBox.Show("Employee not found.");
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
    }
}
