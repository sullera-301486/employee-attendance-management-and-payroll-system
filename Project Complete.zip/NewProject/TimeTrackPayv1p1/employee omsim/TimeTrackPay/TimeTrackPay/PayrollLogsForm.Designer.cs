﻿namespace TimeTrackPay
{
    partial class PayrollLogsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.fabonPanel1 = new roundedRectangle.FabonPanel();
            this.fabonPanel3 = new roundedRectangle.FabonPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.payrollIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adminIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sSSDeductionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.philHealthDeductionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pagIbigDeductionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalDeductionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.netPayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.payPeriodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.incomeTaxDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.payrollBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dbEmployeeDataSet6 = new TimeTrackPay.dbEmployeeDataSet6();
            this.payrollTableAdapter = new TimeTrackPay.dbEmployeeDataSet6TableAdapters.PayrollTableAdapter();
            this.fabonPanel1.SuspendLayout();
            this.fabonPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.payrollBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbEmployeeDataSet6)).BeginInit();
            this.SuspendLayout();
            // 
            // fabonPanel1
            // 
            this.fabonPanel1.BackColor = System.Drawing.Color.White;
            this.fabonPanel1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel1.BorderRadius = 30;
            this.fabonPanel1.BorderSize = 0;
            this.fabonPanel1.Controls.Add(this.fabonPanel3);
            this.fabonPanel1.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel1.GradientAngle = 90F;
            this.fabonPanel1.GradientBottomColor = System.Drawing.Color.Gray;
            this.fabonPanel1.GradientTopColor = System.Drawing.Color.Gray;
            this.fabonPanel1.Location = new System.Drawing.Point(15, 13);
            this.fabonPanel1.Name = "fabonPanel1";
            this.fabonPanel1.Size = new System.Drawing.Size(840, 434);
            this.fabonPanel1.TabIndex = 2;
            // 
            // fabonPanel3
            // 
            this.fabonPanel3.BackColor = System.Drawing.Color.White;
            this.fabonPanel3.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.fabonPanel3.BorderRadius = 30;
            this.fabonPanel3.BorderSize = 0;
            this.fabonPanel3.Controls.Add(this.dataGridView1);
            this.fabonPanel3.ForeColor = System.Drawing.Color.Black;
            this.fabonPanel3.GradientAngle = 90F;
            this.fabonPanel3.GradientBottomColor = System.Drawing.Color.White;
            this.fabonPanel3.GradientTopColor = System.Drawing.Color.White;
            this.fabonPanel3.Location = new System.Drawing.Point(3, 3);
            this.fabonPanel3.Name = "fabonPanel3";
            this.fabonPanel3.Size = new System.Drawing.Size(834, 428);
            this.fabonPanel3.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.payrollIDDataGridViewTextBoxColumn,
            this.employeeIDDataGridViewTextBoxColumn,
            this.adminIDDataGridViewTextBoxColumn,
            this.sSSDeductionDataGridViewTextBoxColumn,
            this.philHealthDeductionDataGridViewTextBoxColumn,
            this.pagIbigDeductionDataGridViewTextBoxColumn,
            this.totalDeductionDataGridViewTextBoxColumn,
            this.netPayDataGridViewTextBoxColumn,
            this.payPeriodDataGridViewTextBoxColumn,
            this.incomeTaxDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.payrollBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(18, 36);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(799, 352);
            this.dataGridView1.TabIndex = 0;
            // 
            // payrollIDDataGridViewTextBoxColumn
            // 
            this.payrollIDDataGridViewTextBoxColumn.DataPropertyName = "PayrollID";
            this.payrollIDDataGridViewTextBoxColumn.HeaderText = "PayrollID";
            this.payrollIDDataGridViewTextBoxColumn.Name = "payrollIDDataGridViewTextBoxColumn";
            this.payrollIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            this.employeeIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // adminIDDataGridViewTextBoxColumn
            // 
            this.adminIDDataGridViewTextBoxColumn.DataPropertyName = "AdminID";
            this.adminIDDataGridViewTextBoxColumn.HeaderText = "AdminID";
            this.adminIDDataGridViewTextBoxColumn.Name = "adminIDDataGridViewTextBoxColumn";
            this.adminIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sSSDeductionDataGridViewTextBoxColumn
            // 
            this.sSSDeductionDataGridViewTextBoxColumn.DataPropertyName = "SSSDeduction";
            this.sSSDeductionDataGridViewTextBoxColumn.HeaderText = "SSSDeduction";
            this.sSSDeductionDataGridViewTextBoxColumn.Name = "sSSDeductionDataGridViewTextBoxColumn";
            this.sSSDeductionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // philHealthDeductionDataGridViewTextBoxColumn
            // 
            this.philHealthDeductionDataGridViewTextBoxColumn.DataPropertyName = "PhilHealthDeduction";
            this.philHealthDeductionDataGridViewTextBoxColumn.HeaderText = "PhilHealthDeduction";
            this.philHealthDeductionDataGridViewTextBoxColumn.Name = "philHealthDeductionDataGridViewTextBoxColumn";
            this.philHealthDeductionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pagIbigDeductionDataGridViewTextBoxColumn
            // 
            this.pagIbigDeductionDataGridViewTextBoxColumn.DataPropertyName = "PagIbigDeduction";
            this.pagIbigDeductionDataGridViewTextBoxColumn.HeaderText = "PagIbigDeduction";
            this.pagIbigDeductionDataGridViewTextBoxColumn.Name = "pagIbigDeductionDataGridViewTextBoxColumn";
            this.pagIbigDeductionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // totalDeductionDataGridViewTextBoxColumn
            // 
            this.totalDeductionDataGridViewTextBoxColumn.DataPropertyName = "TotalDeduction";
            this.totalDeductionDataGridViewTextBoxColumn.HeaderText = "TotalDeduction";
            this.totalDeductionDataGridViewTextBoxColumn.Name = "totalDeductionDataGridViewTextBoxColumn";
            this.totalDeductionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // netPayDataGridViewTextBoxColumn
            // 
            this.netPayDataGridViewTextBoxColumn.DataPropertyName = "NetPay";
            this.netPayDataGridViewTextBoxColumn.HeaderText = "NetPay";
            this.netPayDataGridViewTextBoxColumn.Name = "netPayDataGridViewTextBoxColumn";
            this.netPayDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // payPeriodDataGridViewTextBoxColumn
            // 
            this.payPeriodDataGridViewTextBoxColumn.DataPropertyName = "PayPeriod";
            this.payPeriodDataGridViewTextBoxColumn.HeaderText = "PayPeriod";
            this.payPeriodDataGridViewTextBoxColumn.Name = "payPeriodDataGridViewTextBoxColumn";
            this.payPeriodDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // incomeTaxDataGridViewTextBoxColumn
            // 
            this.incomeTaxDataGridViewTextBoxColumn.DataPropertyName = "IncomeTax";
            this.incomeTaxDataGridViewTextBoxColumn.HeaderText = "IncomeTax";
            this.incomeTaxDataGridViewTextBoxColumn.Name = "incomeTaxDataGridViewTextBoxColumn";
            this.incomeTaxDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // payrollBindingSource
            // 
            this.payrollBindingSource.DataMember = "Payroll";
            this.payrollBindingSource.DataSource = this.dbEmployeeDataSet6;
            // 
            // dbEmployeeDataSet6
            // 
            this.dbEmployeeDataSet6.DataSetName = "dbEmployeeDataSet6";
            this.dbEmployeeDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // payrollTableAdapter
            // 
            this.payrollTableAdapter.ClearBeforeFill = true;
            // 
            // PayrollLogsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(871, 460);
            this.Controls.Add(this.fabonPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "PayrollLogsForm";
            this.Text = "PayrollLogsForm";
            this.Load += new System.EventHandler(this.PayrollLogsForm_Load);
            this.fabonPanel1.ResumeLayout(false);
            this.fabonPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.payrollBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbEmployeeDataSet6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private roundedRectangle.FabonPanel fabonPanel1;
        private roundedRectangle.FabonPanel fabonPanel3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private dbEmployeeDataSet6 dbEmployeeDataSet6;
        private System.Windows.Forms.BindingSource payrollBindingSource;
        private dbEmployeeDataSet6TableAdapters.PayrollTableAdapter payrollTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn payrollIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adminIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sSSDeductionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn philHealthDeductionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pagIbigDeductionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalDeductionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn netPayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn payPeriodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn incomeTaxDataGridViewTextBoxColumn;
    }
}