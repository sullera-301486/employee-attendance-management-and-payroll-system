﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace TimeTrackPay
{
    public partial class leaveRequest : Form
    {
        private int employeeID;
        string connectionString = "Server=LAPTOP-PVCP8MJI\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";
        public leaveRequest(int id)
        {
            InitializeComponent();
            employeeID = id;
        }

        private void btnRequest_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(startDate.Text) || string.IsNullOrEmpty(endDate.Text) || string.IsNullOrEmpty(cbLeaveType.Text))
            {
                MessageBox.Show("Please select a date and leave type.");
                return;
            }

            try
            {
                using (SqlConnection Con = new SqlConnection(connectionString))
                {
                    Con.Open();
                    string query = "INSERT INTO LeaveRequests (EmployeeID, LeaveType, StartDate, EndDate, Status) VALUES (@EmployeeID, @LeaveType, @StartDate, @EndDate, @Status)";

                    using (SqlCommand command = new SqlCommand(query, Con))
                    {
                        command.Parameters.AddWithValue("@EmployeeID", employeeID);
                        command.Parameters.AddWithValue("@LeaveType", cbLeaveType.Text);
                        command.Parameters.AddWithValue("@StartDate", startDate.Value);
                        command.Parameters.AddWithValue("@EndDate", endDate.Value);
                        command.Parameters.AddWithValue("@Status", "Pending");

                        command.ExecuteNonQuery();
                    }

                    MessageBox.Show("Leave request submitted successfully.");
                    requestSubmitted reqSubmitted = new requestSubmitted();
                    reqSubmitted.Show();
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while submitting the leave request: " + ex.Message);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void LeaveRequest_Load(object sender, EventArgs e)
        {
            string[] leaveType = { "Vacation Leave", "Sick Leave", "Maternal Leave", "Bereavement Leave" };
            foreach (string type in leaveType)
            {
                cbLeaveType.Items.Add(type);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
