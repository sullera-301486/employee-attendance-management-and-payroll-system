﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace TimeTrackPay
{
    public partial class LeaveRequestApproval : Form
    {
        string connectionString = "Server=LAPTOP-PVCP8MJI\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";
        public LeaveRequestApproval()
        {
            InitializeComponent();
            notifLeave();
        }
        public void notifData(string name)
        {
            // Set the data to the labels or text boxes
            label3.Text = name;
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection Conn = new SqlConnection(connectionString);
            string queryA = "UPDATE LeaveRequests SET Status = 'Approved' WHERE LeaveID = 1";
            using (SqlCommand Comm = new SqlCommand(queryA, Conn))
            {
                Conn.Open();
                int rowsAffected = Comm.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Leave has been approved."); // Success message
                }
            }
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection Conn = new SqlConnection(connectionString);
            string queryA = "UPDATE LeaveRequests SET Status = 'Denied' WHERE LeaveID = 1";
            using (SqlCommand Comm = new SqlCommand(queryA, Conn))
            {
                Conn.Open();
                int rowsAffected = Comm.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Leave has been denied."); // Success message
                }
            }
            this.Close();
        }

        private void notifLeave()
        {

            SqlConnection Con = new SqlConnection(connectionString);
            string query = "SELECT * FROM LeaveRequests WHERE LeaveID = 1";
            using (SqlCommand command = new SqlCommand(query, Con))
            {

                try
                {
                    Con.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        DateTime date1 = reader["StartDate"] != DBNull.Value ? Convert.ToDateTime(reader["StartDate"]) : DateTime.MinValue;
                        DateTime date2 = reader["EndDate"] != DBNull.Value ? Convert.ToDateTime(reader["EndDate"]) : DateTime.MinValue;
                        date1 = Convert.ToDateTime(reader["StartDate"]);
                        date2 = Convert.ToDateTime(reader["EndDate"]);
                        TimeSpan difference = date2 - date1;
                        int daysDifference = difference.Days + 1;
                        // Display fetched data in the labels
                        label5.Text = reader["LeaveType"].ToString();
                        label7.Text = $"{date1.ToString("MM/dd/yyyy")} - {date2.ToString("MM/dd/yyyy")}";
                        label9.Text = daysDifference.ToString();
                        label11.Text = DateTime.Today.ToShortDateString();

                    }
                    else
                    {
                        MessageBox.Show("Employee not found.");
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }
    }
}
