﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class DashboardAdmin : Form
    {
        public DashboardAdmin()
        {
            InitializeComponent();
            LoadTotalEmployees();
            LoadLateEmployees(); // Add this line to call the new method
            LoadNotLateEmployees();
        }

        string connectionString = "Server=LAPTOP-PVCP8MJI\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void btnMoreInfoAdminAttendance_Click(object sender, EventArgs e)
        {
            loadform(new AdminAttendance());
        }

        public void loadform(Form form)
        {
            foreach (Control control in this.DashboardPanel.Controls.OfType<Control>().ToList())
            {
                this.DashboardPanel.Controls.Remove(control);
                control.Dispose();
            }

            form.TopLevel = false;
            form.Dock = DockStyle.Fill;
            this.DashboardPanel.Controls.Add(form);
            this.DashboardPanel.Tag = form;

            form.Show();
        }

        private void btnMoreInfoPayrollRecords_Click(object sender, EventArgs e)
        {
            loadform(new PayrollAdmin());
        }

        private void btnMoreInfoAdminAttendance_Click_1(object sender, EventArgs e)
        {
            loadform(new AdminAttendance());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            loadform(new AdminAttendance());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            loadform(new AdminAttendance());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loadform(new AdminAttendance());
        }

        private void LoadTotalEmployees()
        {
            string query = "SELECT COUNT(*) FROM Employee";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    int totalEmployees = (int)command.ExecuteScalar();
                    // Display total number of employees in the label
                    totalEmployeeLabel.Text = totalEmployees.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        private void LoadLateEmployees()
        {
            string query = "SELECT COUNT(isLate) AS LateCount FROM AttendanceEmployee WHERE isLate = 1";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    int lateCount = (int)command.ExecuteScalar();
                    // Display result in label16
                    label16.Text = lateCount.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }
        private void LoadNotLateEmployees()
        {
            string query = "SELECT COUNT(isLate) AS NotLateCount FROM AttendanceEmployee WHERE isLate = 0";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    int notLateCount = (int)command.ExecuteScalar();
                    // Display result in label16
                    label14.Text = notLateCount.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

    }
}
