﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class NotificationEmployee : Form
    {
        string connectionString = "Server=LAPTOP-PVCP8MJI\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";
        private int employeeID;
        public NotificationEmployee(int id)
        {
            InitializeComponent();
            this.employeeID = id;
            detailsLoad();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

            this.Close();
        }

        private void detailsLoad()
        {
            string query = "SELECT * FROM LeaveRequests WHERE EmployeeID = @EmployeeID";
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@EmployeeID", employeeID);
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    // Display employee details in the form
                    DateTime date1 = reader["StartDate"] != DBNull.Value ? Convert.ToDateTime(reader["StartDate"]) : DateTime.MinValue;
                    DateTime date2 = reader["EndDate"] != DBNull.Value ? Convert.ToDateTime(reader["EndDate"]) : DateTime.MinValue;
                    date1 = Convert.ToDateTime(reader["StartDate"]);
                    date2 = Convert.ToDateTime(reader["EndDate"]);
                    label2.Text = $"Leave date: {date1.ToString("MM/dd/yyyy")} - {date2.ToString("MM/dd/yyyy")}";
                    label3.Text = "Leave Request Status: " + reader["Status"].ToString();

                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred" + ex.Message);
            }
            }
    }
}
