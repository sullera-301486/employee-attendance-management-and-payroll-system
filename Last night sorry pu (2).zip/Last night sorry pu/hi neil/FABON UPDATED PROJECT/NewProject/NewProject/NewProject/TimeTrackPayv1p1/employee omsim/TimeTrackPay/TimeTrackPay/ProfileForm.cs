﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTrackPay
{
    public partial class ProfileForm : Form
    {
        private int employeeID;
        string connectionString = "Server=LAPTOP-PVCP8MJI\\SQLEXPRESS;Database=dbEmployee;Integrated Security=True;";
        private SqlConnection Con;
        public ProfileForm(int id)
        {
            InitializeComponent();
            employeeID = id;
            Con = new SqlConnection(connectionString); // Initialize the connection
            LoadEmployeeData(); // Call LoadEmployeeData method when the form loads

        }

        private void LoadEmployeeData()
        {
            string query = "SELECT FullName, EmployeeID, phone_number, Position, birthdate, address, hire_date, worked_for, email FROM Employee WHERE EmployeeID = @EmployeeID";

            using (SqlCommand command = new SqlCommand(query, Con))
            {
                command.Parameters.AddWithValue("@EmployeeID", employeeID);

                try
                {
                    Con.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        DateTime dateWork = reader["hire_date"] != DBNull.Value ? Convert.ToDateTime(reader["hire_date"]) : DateTime.MinValue;
                        DateTime dateBirth = reader["birthdate"] != DBNull.Value ? Convert.ToDateTime(reader["birthdate"]) : DateTime.MinValue;
                        // Display fetched data in the labels
                        NameEmployee.Text = reader["FullName"].ToString();
                        PhoneNumber.Text = reader["phone_number"].ToString();
                        EmployeeBirthday.Text = $"{dateBirth.ToString("MM/dd/yyyy")}";
                        HireDateEmployee.Text = $"{dateWork.ToString("MM/dd/yyyy")}";
                        EmployeeAddress.Text = reader["address"].ToString();
                        EmployeeEmail.Text = reader["email"].ToString();
                        EmployeePosition.Text = reader["Position"].ToString();
                        IDemployee.Text = reader["EmployeeID"].ToString();
                        WorkedForEmployee.Text = reader["worked_for"].ToString();

                    }
                    else
                    {
                        MessageBox.Show("Employee not found.");
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
        }



        private void label20_Click(object sender, EventArgs e)
        {

        }
    }
}
