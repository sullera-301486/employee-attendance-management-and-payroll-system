﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeTrackPay
{
    internal class NotificationData
    {
        public string Name { get; set; }

        public NotificationData(string name)
        {
            this.Name = name;
        }
    }
}
